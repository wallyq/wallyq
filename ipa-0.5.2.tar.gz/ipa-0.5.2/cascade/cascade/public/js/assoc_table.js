
function assoc_query_to_ip(ip)
{
    reset_assoc_form();
    YAHOO.util.Dom.get("address").value = ip;
    assoc_form.dt.page = 0;
    assoc_form.dt.record_count=0;
    assoc_form.do_query(null, ip, null, null, null);
}


function format_assoc_url(cell, record, column, data) {
    cell.innerHTML='<a href="javascript:assoc_query_to_ip(\'' + data + '\');">' + data + '</a>';
}


function loadAssocTable()
{
    var assoc_table, myDataSource, myEditDataSource, paths=[], stime=null,
    etime=null, address=null, label=null;
    var editable = false;

    assoc_form = {
        dt: null,
        fields: ["catalog","t_begin","t_end","range", "begin", "end", "label","value","content"],
        columns: [
            {key:"catalog", label:"Catalog", sortable:true, resizeable: true},
            {key:"t_begin", label:"Begin", sortable:true, resizeable: true, formatter: formatDate},
            {key:"t_end", label:"End", sortable:true, resizeable: true, formatter: formatDate},
            {key:"range", label:"Range", sortable:true, resizeable: true, formatter: format_assoc_url},
            {key:"label", label:"Label", sortable:true, resizeable: true},
            {key:"value", label:"Value", sortable:true, resizeable: true}
        ],
        init: function() {
            this.ds  = new YAHOO.util.DataSource("browse/associations?",
                                                 {
                                                     responseType: YAHOO.util.DataSource.TYPE_JSON,
                                                     connMethodPost: true,
                                                     connXhrMode: "queueRequests",
                                                     responseSchema: {
                                                         resultsList: "records",
                                                         fields: this.fields,
                                                         metaFields: { 
	                                                         totalRecords: "totalRecords"
	                                                     }
                                                     }
                                                 });

            this.dt = new YAHOO.widget.EndlessDataTable("associations", this.columns,
                                                        this.ds,
                                                        {initialLoad: true,
                                                         draggableColumns: true,
                                                         dynamicData: true, 
                                                         MSG_EMPTY: "No data.  Please select one or more filters.",
                                                         MSG_LOADING: "Loading...",
                                                         height: "500px",
                                                         resultsPerPage: 100,
                                                         generateRequest: this.requestBuilder,
                                                         sortedBy: {
                                                             key: "catalog",
                                                             dir: YAHOO.widget.DataTable.CLASS_ASC
                                                         }
                                                        });

            this.dt.subscribe("rowMouseoverEvent", this.dt.onEventHighlightRow);
	        this.dt.subscribe("rowMouseoutEvent", this.dt.onEventUnhighlightRow); 
            this.dt.subscribe("rowClickEvent",
                                    function(ev) {
                                        var target = YAHOO.util.Event.getTarget(ev);
                                        // Unselect row
                                        if (this.isSelected(target)) {
                                            this.unselectRow(target);
                                        }
                                        // Select row
                                        else {
                                            this.selectRow(target);
                                        }
                                    }
                                   );
            // Notes detail
            var onAssocTableDblclick = function(ev) {
                notespanel.hide();
                var target = YAHOO.util.Event.getTarget(ev);
                var range = this.getRecord(target).getData('range');
                notes_form.dt.range = range;
                notes_form.dt.page = 0;
                notes_form.update(true, true);
	            //this.dt.subscribe("rowClickEvent", this.dt.onEventSelectRow); 
                return true;
            };

            this.dt.subscribe("rowDblclickEvent",onAssocTableDblclick);


	        var tt = new YAHOO.widget.Tooltip("assocToolTip");
	        var showTimer,hideTimer;

	        this.dt.on('cellMouseoverEvent', function (oArgs) {
                var record, description, xy;
		        if (showTimer) {
			        window.clearTimeout(showTimer);
			        showTimer = 0;
		        }

		        var target = oArgs.target;
		        var column = this.getColumn(target);
                if (!column) return;
		        record = this.getRecord(target);
		        if (column.key == 'range') {
			        description = record.getData('begin') + " - " + record.getData('end');
		        }
                else if (column.key == 't_begin') {
                    if (record.getData('t_begin').substr(0,4) != "0001")
				        description = record.getData('t_begin');
                    else
                        description = "dataset has no begin time";
                }
                else if (column.key == 't_end') {
                    if (record.getData('t_end').substr(0,4) != "9999")
				        description = record.getData('t_end');
                    else
                        description = "dataset has no end time";
                }
                else {
                    description = null;
                }

                if (description)
                {
			        var xy = [parseInt(oArgs.event.clientX,10) + 10 ,parseInt(oArgs.event.clientY,10) + 10 ];
			        showTimer = window.setTimeout(function() {
				        tt.setBody(description);
				        tt.cfg.setProperty('xy',xy);
				        tt.show();
				        hideTimer = window.setTimeout(function() {
					        tt.hide();
				        },5000);
			        },500);
                }
	        });

            this.dt.on('dataReturnEvent', this.updateEditTable, this.dt);
            this.dt.on('postRenderEvent', this.updateEditTable, this.dt);
            this.dt.on('columnReorderEvent', this.updateEditTable, this.dt);
            this.dt.on('columnResizeEvent', this.updateEditTable, this.dt);

        },
        updateEditTable: function (event, dt) {
            var xy, x, y;
            if (!dt) 
                return;

            var thr = dt.getThLinerEl(dt.getColumn('range'));
            var thl = dt.getThLinerEl(dt.getColumn('label'));
            var thv = dt.getThLinerEl(dt.getColumn('value'));
            var rx = YAHOO.util.Dom.getX(thr);
            var lx = YAHOO.util.Dom.getX(thl);
            var vx = YAHOO.util.Dom.getX(thv);

            var lastrow = dt.getLastTrEl();
            if (lastrow)
                y = YAHOO.util.Dom.getY(dt.getMsgTbodyEl()) + dt.getMsgTbodyEl().height + lastrow.height;
            else
                y = YAHOO.util.Dom.getY(dt.getMsgTbodyEl()) + dt.getMsgTbodyEl().height;
            
            var af = YAHOO.util.Dom.get('assocfields');
            var re = YAHOO.util.Selector.query('#range', af, true);
            var le = YAHOO.util.Selector.query('#label', af, true);
            var ve = YAHOO.util.Selector.query('#value', af, true);
            YAHOO.util.Dom.setStyle(re, 'width', thr.offsetWidth - 6 + "px");
            YAHOO.util.Dom.setStyle(le, 'width', thl.offsetWidth - 6 + "px");
            YAHOO.util.Dom.setStyle(ve, 'width', thv.offsetWidth - 6 + "px");
            YAHOO.util.Dom.setXY(re, [rx, y]);
            YAHOO.util.Dom.setXY(le, [lx, y]);
            YAHOO.util.Dom.setXY(ve, [vx, y]);
        },
        requestBuilder: function (oState, dt) {
    	    var page, results, sort, dir;
    	    oState = oState || {pagination: null, sortedBy: null};
    	    sort = (oState.sortedBy) ? oState.sortedBy.key : null;
    	    dir = (oState.sortedBy && oState.sortedBy.dir === YAHOO.widget.DataTable.CLASS_DESC) ? "desc" : "asc";

            if (sort != dt.last_sort || dir != dt.last_dir)
            {
                dt.page = 0;
                dt.row_count = 0;
            }

            dt.last_sort = sort;
            dt.last_dir = dir;
    	    return  "&page=" 	+ dt.page +
                "&results=" 	+ dt.get('resultsPerPage') +
    		    "&sort=" 	+ sort +
    		    "&dir=" 	+ dir +
    	        ( ((dt.paths != null) && (dt.paths.length > 0))
                  ? "&paths=" + encodeURIComponent(YAHOO.lang.JSON.stringify(dt.paths)) : "") +
    	        ( dt.stime ? "&t_begin=" + encodeURIComponent(YAHOO.lang.JSON.stringify(dt.stime)) : "") +
    	        ( dt.etime ? "&t_end=" + encodeURIComponent(YAHOO.lang.JSON.stringify(dt.etime)) : "") +
                ( dt.address ? "&address=" + encodeURIComponent(dt.address) : "") +
                ( dt.label ? "&label=" + encodeURIComponent(dt.label) : "");
        },
        do_query: function(paths, address, label, stime, etime) {
            if (!paths && !address && !label && !stime && !etime)
            {
                alert('Please select one or more filter criteria.');
                return;
            }

            this.disable_edit();
            this.dt.paths = paths;
            this.dt.address = address;
            this.dt.label = label;
            this.dt.stime = stime;
            this.dt.etime = etime;

            header = YAHOO.util.Dom.get("assocheader");
            header.innerHTML = "Association query results";

            var oState = this.dt.getState(), request;
            this.update(true);
        },
        update: function (reset) {
            var oState = this.dt.getState(),
            request,
            oCallback;

    	    /* If the column sort direction needs to be updated, that may be done here.
    	       It is beyond the scope of this example, but the DataTable::sortColumn() method
    	       has code that can be used with some modification. */

            if(reset)
            {
                this.dt.set( "sortedBy", "catalog" );
                oState = this.dt.getState();
                this.dt.row_count = 0;
                this.dt.page = 0;
    		    oCallback = {
    			    success : this.dt.onDataReturnReplaceRows,
    			    failure : this.dt.onDataReturnReplaceRows,
                    argument : oState,
    			    scope : this.dt
    		    };
            }
            else
            {
    		    oCallback = {
    			    success : this.dt.onDataReturnAppendRows,
    			    failure : this.dt.onDataReturnAppendRows,
                    argument : oState,
    			    scope : this.dt
    		    };
            }

    	    // Generate a query string
            request = this.dt.get("generateRequest")(oState, this.dt);
    	    // Fire off a request for new data.
    	    this.dt.getDataSource().sendRequest(request, oCallback);
        },
        disable_edit: function() {
            YAHOO.util.Dom.setStyle(YAHOO.util.Dom.get('assocedit'), 'display', 'none');
        },
        enable_edit: function() {
            YAHOO.util.Dom.setStyle(YAHOO.util.Dom.get('assocedit'), 'display', 'inline');
        },
        add_assoc: function (range, label, value)
        {
            if (! range) return false;
            var sUrl = "browse/add_assoc?dsid=" + this.dt.ds_id
                + "&range=" + range
                + (label ? "&label=" + label : "")
                + (value ? "&value=" + value : "")
            
            var callback = {
                success: function(oResponse){
                    var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
                    if (res)
                        assoc_form.update(true);
                    else
                        alert("Failed to add association");                    
                },
                failure: function(oResponse){
                    alert("Failed to add association");
                },
                timeout:30000
            }
            YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);   
        }

    }
    assoc_form.init();

}

YAHOO.util.Event.on('btnAddAssoc','click', function() {
    var af = YAHOO.util.Dom.get('assocfields');
    var range = YAHOO.util.Selector.query('#range', af, true).value;
    var label = YAHOO.util.Selector.query('#label', af, true).value;
    var value = YAHOO.util.Selector.query('#value', af, true).value;
    
    assoc_form.add_assoc(range, label, value);
});

YAHOO.util.Event.on('btnClearAssoc','click',function() {
    var af = YAHOO.util.Dom.get('assocfields');
    YAHOO.util.Selector.query('#range', af, true).value = null;
    YAHOO.util.Selector.query('#label', af, true).value = null;
    YAHOO.util.Selector.query('#value', af, true).value = null;
});
