var oCurrentTextNode = null;

function loadCatalogTree()
{

    // Extend YUI DataTable which is missing a selectAllRows method
    YAHOO.lang.augmentObject(
        YAHOO.widget.DataTable.prototype, {

            _selectAllTrEls : function() {
                var selectedRowsEven = YAHOO.util.Dom.getElementsByClassName(
                    YAHOO.widget.DataTable.CLASS_EVEN, "tr",this._elTbody);
                YAHOO.util.Dom.addClass( selectedRowsEven ,
                                         YAHOO.widget.DataTable.CLASS_SELECTED);

                var selectedRowsOdd = YAHOO.util.Dom.getElementsByClassName(
                    YAHOO.widget.DataTable.CLASS_ODD, "tr",this._elTbody);
                YAHOO.util.Dom.addClass( selectedRowsOdd,
                                         YAHOO.widget.DataTable.CLASS_SELECTED);
            },

            /* Selects all rows. * * @method selectAllRows */
            selectAllRows : function() {
                // Remove all rows from tracker
                var tracker = this._aSelections || [];
                for(var j=tracker.length- 1; j>-1; j--) {
                    if(YAHOO.lang.isString( tracker[j] )){
                        tracker.splice( j,1);
                    }
                }
                // Update tracker
                this._aSelections = tracker;
                // Update UI
                this._selectAllTrEls();
                // Get all highlighted rows and make yahoo aware they are selected
                var selectedRowsEven = YAHOO.util.Dom.getElementsByClassName(
                    YAHOO.widget.DataTable.CLASS_SELECTED, "tr",this._elTbody);
                for (i=0;i<selectedRowsEven.length; i++){
                    this.selectRow(i);
                }
            }
        });
    // End YUI Datatable extension

    (function() {
        function updateTimeRange(val) {
            switch(val)
            {
            case 'all':
                YAHOO.util.Dom.setStyle('start-date', 'display', 'none');
                YAHOO.util.Dom.setStyle('start-time', 'display', 'none');
                YAHOO.util.Dom.setStyle('timeand', 'display', 'none');
                YAHOO.util.Dom.setStyle('end-date', 'display', 'none');
                YAHOO.util.Dom.setStyle('end-time', 'display', 'none');
                break;
            case 'at':
                YAHOO.util.Dom.setStyle('start-date', 'display', 'inline');
                YAHOO.util.Dom.setStyle('start-time', 'display', 'inline');
                YAHOO.util.Dom.setStyle('timeand', 'display', 'none');
                YAHOO.util.Dom.setStyle('end-date', 'display', 'none');
                YAHOO.util.Dom.setStyle('end-time', 'display', 'none');
                break;
            case 'before':
                YAHOO.util.Dom.setStyle('start-date', 'display', 'none');
                YAHOO.util.Dom.setStyle('start-time', 'display', 'none');
                YAHOO.util.Dom.setStyle('timeand', 'display', 'none');
                YAHOO.util.Dom.setStyle('end-date', 'display', 'inline');
                YAHOO.util.Dom.setStyle('end-time', 'display', 'inline');
                break;
            case 'after':
                YAHOO.util.Dom.setStyle('start-date', 'display', 'inline');
                YAHOO.util.Dom.setStyle('start-time', 'display', 'inline');
                YAHOO.util.Dom.setStyle('timeand', 'display', 'none');
                YAHOO.util.Dom.setStyle('end-date', 'display', 'none');
                YAHOO.util.Dom.setStyle('end-time', 'display', 'none');
                break;
            case 'between':
                YAHOO.util.Dom.setStyle('start-date', 'display', 'inline');
                YAHOO.util.Dom.setStyle('start-time', 'display', 'inline');
                YAHOO.util.Dom.setStyle('timeand', 'display', 'inline');
                YAHOO.util.Dom.setStyle('end-date', 'display', 'inline');
                YAHOO.util.Dom.setStyle('end-time', 'display', 'inline');
                break;
            }
        }
        function timeRangeSetup() {
            YAHOO.util.Event.on('timerangeroup','click',function(e) {
                target = YAHOO.util.Event.getTarget(e);
                daterangetype = target.value;
                updateTimeRange(daterangetype);
            })
            
            updateTimeRange("all");
        }
        timeRangeSetup();
    })();

    function fixTree(ipanode)
    {
        if (ipanode.type == 'root' || ipanode.type == 'catalog') {
            var catclass = "catalognode";
            ipanode.type = IPACatalogNode;

            if (ipanode.children.length > 0)
            {
                for (var i=0; i < ipanode.children.length; i++)
                {
                    fixTree(ipanode.children[i]);
                }
            }
        }
        else if (ipanode.type == 'dataset_group') {
            ipanode.type = IPADatasetNode;
        }
    }

    function fixTree2(ipanode)
    {
        ipanode.multiExpand = false;
        if (ipanode instanceof IPADatasetNode)
        {
            //ipanode.setDynamicLoad(loadNodeData);

            ipanode.html = '<span class="datasetnode"'
                + 'title="Double-click to view a list of datasets in this catalog">&nbsp;' 
                + ipanode.count + ((ipanode.count > 1) ? ' datasets' : ' dataset') 
                + '<br><span class="datasetdates">from ' + ipanode.begin + ' to ' + ipanode.end
                + '<br>(double-click to view)</span></span>';
            ipanode.isLeaf = false;
            //ipanode.hasIcon = true;
            ipanode.opened = false;
            ipanode.renderHidden = true;
            //ipanode.enableHighlight = true; // maybe?
        }
        else
        {
            if (YAHOO.util.Dom.hasClass(ipanode.getEl(), "home"))
            {
                ipanode.expanded = true;
            }
            if (ipanode.children.length > 0)
            {
                for (var i=0; i < ipanode.children.length; i++)
                {
                    fixTree2(ipanode.children[i]);
                }
            }
        }
    }


    // Creating the tree
    function buildTree() {


        function viewDatasets(args) {

            function showDataTable(node)
            {
                var xy = YAHOO.util.Dom.getXY(node.getElId());

                var d = document.getElementById('dstable');
                while(d.firstChild) { d.removeChild(d.firstChild); }; // remove previous DataTables
                d.appendChild(node.dt._elContainer);
                dspanel.moveTo(xy[0]+100, xy[1]+40);
			    dspanel.show();
            }

            function deleteDataset(dataset_id)
            {
                function handleSuccess(oResponse)
                {
                    var status = YAHOO.lang.JSON.parse(oResponse.responseText).status;
                    var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
                    if (status)
                    {
                        alert("Dataset was deleted.");
                    }
                    else
                    {
                        alert(res);
                    }
                }
                function handleFailure(oResponse)
                {
                    alert("failed to delete dataset");
                }
                var callback = { success: handleSuccess, failure: handleFailure };

                var sUrl = "browse/delete_dataset?dataset_id=" + dataset_id;
                YAHOO.util.Connect.asyncRequest('POST', sUrl, callback);                        
            }


            if (args.node)
                node = args.node;
            else
                node = oCurrentTextNode;

            var catpath;
            if (node instanceof IPACatalogNode)
            {
                catpath = node.name;
            }
            else if(node instanceof IPADatasetNode)
            {
                catpath = node.parent.name;
            }

            var depth = parseInt(node.depth);
            var paths = [];
            paths.push(catpath + '/');

            node.dtdiv = document.createElement('div');

            var sUrl = "browse/datasets?expr=" + YAHOO.lang.JSON.stringify(paths);

            var callback = {
                success: function(oResponse){
                    var oResults = YAHOO.lang.JSON.parse(oResponse.responseText).result;

                    var myColumnDefs = [
                        {key:"id", label:"ID", hidden:true},
                        {key:"t_begin", label:"Begin", sortable:true, resizeable: false, formatter: formatDate, width:140},
                        {key:"t_end", label:"End", sortable:true, resizeable: false, formatter: formatDate, width:140},
                        {key:"assoc_count", label:"Assocs", sortable:true, resizeable: false},
                        {key:"ip_count", label:"IPs", sortable:true},
                    ];
		            var myDataSource = new YAHOO.util.LocalDataSource(oResults);

					// this tells the datasource that the content generator will return an array
					myDataSource.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
					myDataSource.responseSchema = {
                        fields: ["id","t_begin","t_end","assoc_count","ip_count"]
					};
                    
                    var myDataTable = new YAHOO.widget.ScrollingDataTable(
                        node.dtdiv, myColumnDefs, myDataSource,
                        {caption: "Click to select datasets to include in your "
                         + "query, or double-click any dataset to query all "
                         + "records for that dataset."
                        });
                    myDataTable.subscribe("rowMouseoverEvent", myDataTable.onEventHighlightRow); 
	                myDataTable.subscribe("rowMouseoutEvent", myDataTable.onEventUnhighlightRow); 

                    var onContextMenuClick = function(p_sType, p_aArgs, p_myDataTable) {
                        var task = p_aArgs[1];
                        if(task) {
                            // Extract which TR element triggered the context menu
                            var elRow = this.contextEventTarget;
                            elRow = p_myDataTable.getTrEl(elRow);

                            if(elRow) {
                                switch(task.index) {
                                case 0:     // Delete row upon confirmation
                                    var oRecord = p_myDataTable.getRecord(elRow);
                                    if(confirm("Are you sure you want to delete this dataset?"))
                                    {
                                        deleteDataset(oRecord.getData("id"));
                                        p_myDataTable.deleteRow(elRow);
                                    }
                                }
                            }
                        }
                    };

                    var myContextMenu = new YAHOO.widget.ContextMenu("dscontextmenu",
                                                                     {trigger:myDataTable.getTbodyEl()});
                    myContextMenu.clearContent();
                    myContextMenu.addItem("Delete dataset");
                    // Render the ContextMenu instance to the parent container of the DataTable
                    myContextMenu.render(node.dtdiv);
                    myContextMenu.clickEvent.subscribe(onContextMenuClick, myDataTable);


                    var onDataTableClick = function(ev) {
                        var target = YAHOO.util.Event.getTarget(ev);
                        var cnode = myDataTable.containingNode;
                        if (myDataTable.isSelected(target)) {
                            myDataTable.unselectRow(target);
                        }
                        else {
                            myDataTable.selectRow(target);
                        }
                        if (myDataTable.getSelectedRows().length == 0)
                        {
                            //console.dir(myDataTable.containingNode);
                            cnode.unhighlight();
                        }
                        else if (myDataTable.getSelectedRows().length == myDataTable.getRecordSet().getLength())
                        {
                            cnode.highlight();
                        }
                        else
                        {
                            cnode.highlightState = 2;
                            YAHOO.util.Dom.removeClass(cnode.getEl().children[0], "ygtv-highlight0");
                            YAHOO.util.Dom.removeClass(cnode.getEl().children[0], "ygtv-highlight1");
                            YAHOO.util.Dom.addClass(cnode.getEl().children[0], "ygtv-highlight2");
                            for (var i=cnode.depth-1; i >= 0; i--)
                            {
                                var anc = cnode.getAncestor(i);
                                anc.highlightState = 2;
                                anc.refresh();
                            }
                            node.refresh();
                        }
                        return false;

                    };

                    var onDataTableDblclick = function(ev) {
                        var catname = myDataTable.containingNode.getAncestor().name
                        var target = YAHOO.util.Event.getTarget(ev);
                        var dsid = this.getRecord(target).getData('id');
                        var stime = this.getRecord(target).getData('t_begin');
                        var etime = this.getRecord(target).getData('t_end');
                        var paths = [];
                        paths.push(catpath + '/' + dsid);
                        assoc_form.dt.ds_id = dsid;
                        assoc_form.enable_edit();
                        assoc_form.dt.paths = paths;
                        var oState = assoc_form.dt.getState(), request;
                        request = assoc_form.dt.get("generateRequest")(oState, assoc_form.dt);
                        assoc_form.update(true);
                        header = YAHOO.util.Dom.get("assocheader");
                        header.innerHTML = "Associations for " + catname + ": " + stime + " - " + etime;
                        dspanel.hide();
                    };

                    myDataTable.subscribe("rowClickEvent",onDataTableClick);
                    myDataTable.subscribe("rowDblclickEvent",onDataTableDblclick);
                    myDataTable.containingNode = node;
                    node.dt = myDataTable;
                    dspanel.setHeader("Dataset Browser for " + catpath);
                    if (node.highlightState == 1)
                    {
                        node.dt.selectAllRows();
                    }
                    node.setNodesProperty("highlightState", 1);
                    node.fireEvent('highlightEvent',node);
                    showDataTable(node);
                    return true;

                },
                failure: function(oResponse){
                    alert("loadNodeData failed");
                },
                argument:{
                    "node": node
                },
                timeout:15000
            }

            if (!node.dt)
            {
                YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);
            }
            else
            {
                showDataTable(node);
            }
        }

        //var sUrl = "catalogs_tree";
        var sUrl = "browse/datasets_tree";
        var callback = {
            success: function(oResponse){
                var oResults = YAHOO.lang.JSON.parse(oResponse.responseText).result;
                fixTree(oResults);
                tree = new YAHOO.widget.TreeView("catalogs", oResults);
                root = tree.getRoot().children[0];
                root.name = "[All IPA Catalogs]";
                root.catid = -1;
                root.type = "root";
                root.cattype = 1;
                root.multiExpand = false;
                root.editable = true;
                fixTree2(tree.getRoot());
                root.expanded = true;
                
                //alert(tree.getRoot().children[0].children[0].label);
                //alert(tree.getRoot().children[0].children[0].catid);

                tree.draw();
		        tree.setNodesProperty('propagateHighlightUp',true);
		        tree.setNodesProperty('propagateHighlightDown',true);
		        //tree.subscribe('clickEvent',tree.onEventToggleHighlight);

                tree.subscribe("expand", function(node) {
                    // if(node.label) console.log("expand: " + node.label);
                    // if(node.html) console.log("expand: " + node.html);
                    if(node instanceof IPADatasetNode)
                    {
                        // console.log("expanding dataset");
                        node.dt.setStyle('display', 'inline');;
                    }
                    return true;
                });

                tree.subscribe("collapse", function(node) {
                    // if(node.label) console.log("collapse: " + node.label);
                    // if(node.html) console.log("collapse: " + node.html);
                    if(node instanceof IPADatasetNode)
                    {
                        node.dt.setStyle('display', 'none');;
                    }
                    return true;
                });

                tree.subscribe("dblClickEvent", viewDatasets, this);

                tree.subscribe("clickEvent", function(args) {
                    // console.log("clickEvent");
                    var node = args.node;
                    var event = args.event;

			        if (node.hasChildren()) {
                        // console.log("onTreeClick() hasChildren");
                        node.toggleHighlight();
                        return false;
                    }
			        if (event.target.className.indexOf('ygtvcell') != -1 ) {
                        // console.log("onTreeClick() checkbox");
                        node.toggleHighlight();
                        if (node.highlightState == 1)
                        {
                            node.dt.selectAllRows();
                        }
                        else
                        {
                            node.dt.unselectAllRows();
                            
                        }
                        return false;
                    };
                });

                // tree.subscribe("clickEvent", function(oArgs) {
				//  	YAHOO.util.Event.preventDefault(oArgs.event);
				//     loadNodeData(oArgs);
                //     return false;
                // });
                

                tree.selectedNodes = function()
                {
                    var hi = []
			        var hi1 = tree.getNodesByProperty('highlightState',1);
                    var hi2 = tree.getNodesByProperty('highlightState',2);
                    if (!hi1 && !hi2) return null;
                    hi = hi.concat(hi1, hi2);
                    
                    if (!hi) return null;
                    var paths = [];
			        for (var i = 0; i < hi.length; i++) {
                        node = hi[i];
                        if (node instanceof IPACatalogNode && node.highlightState == 1)
                        {
                            paths.push(node.name) + "/";
                        }
                        else if (node instanceof IPADatasetNode)
                        {
                            dt = node.dt;
                            // console.log('parent name: ' + node.parent.name);
                            if (!dt)
                                continue;
                            for (var j=0; j < dt.getSelectedRows().length; j++)
                            {
                                rowid = dt.getSelectedRows()[j];
                                var record = dt.getRecord(rowid);
                                // console.dir(record);
                                //dsids.push(record.getData('id'));
                                paths.push(node.parent.name + "/" + record.getData('id'));
                            }
                        }
			        }
                    return paths;
                }

                function refreshNode() {
                    // console.log("refreshing " + oCurrentTextNode.name);
                    tree.getRoot().refresh();
                }

                function populateParentList()
                {
                    function handleSuccess(oResponse)
                    {
                        var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
                        //console.dir(res);
                        if (res)
                        {
                            var selectedid = -1;
                            var catlist = '';
                            for (var i=0; i < res.length; i++ )
                            {
                                catlist += '<option value="'
                                    + res[i].id + '"'
                                    + '>'
                                    + res[i].name + '</option>'
                            }
                            YAHOO.util.Dom.get("catparent").innerHTML = catlist;
                        }                                
                    }
                    function handleFailure(oResponse)
                    {
                        alert("failed to get catalog tree");
                    }
                    var callback = { success: handleSuccess, failure: handleFailure };

                    var sUrl = "browse/catalogs?ids=" + oCurrentTextNode.catid;
                    YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);
                }

                function nodeProperties()
                {
                    function checkFormFields()
                    {
                        var options = YAHOO.util.Dom.getChildren(YAHOO.util.Dom.get("catparent"));
                        var namefield = YAHOO.util.Dom.get("catpropname");
                        var descfield = YAHOO.util.Dom.get("catpropdesc");
                        if ( namefield.value == oCurrentTextNode.suffix &&
                             descfield.value == oCurrentTextNode.description)
                        {
                            catpropertiesdialog.getButtons()[0].set("disabled", true);
                        }
                        else
                        {
                            catpropertiesdialog.getButtons()[0].set("disabled", false);
                        }

                        if (namefield.value == "")
                        {
                            for (i=0; i < options.length; i++)
                            {
                                var option = options[i];
                                var old = option.innerHTML;
                                option.innerHTML = old.slice(0, old.lastIndexOf('.') + 1) + oCurrentTextNode.suffix;
                            }
                        }
                        else
                        {
                            for (i=0; i < options.length; i++)
                            {
                                var option = options[i];
                                var old = option.innerHTML;
                                option.innerHTML = old.slice(0, old.lastIndexOf('.') + 1) + namefield.value;
                            }
                        }
                    }
                    function handleParentID()
                    {
                        YAHOO.util.Dom.get("catparent").value = this.value;
                        if (oCurrentTextNode.parent_id == this.value)
                        {
                            catpropertiesdialog.getButtons()[0].set("disabled", true);
                        }
                        else
                        {
                            catpropertiesdialog.getButtons()[0].set("disabled", false);
                        }
                    }

 
                    YAHOO.util.Dom.get("catparentdiv").innerHTML = '<select name="catparent" id="catparent" size="10"></select>';
                    YAHOO.util.Dom.get("catparent").value = oCurrentTextNode.parent_id;
                    populateParentList();
                    YAHOO.util.Dom.get("catpropname").value = oCurrentTextNode.suffix;
                    YAHOO.util.Dom.get("catpropdesc").value = oCurrentTextNode.description;
                    YAHOO.util.Dom.get("catpropid").value = oCurrentTextNode.catid;
                    YAHOO.util.Dom.get("catowner").value = oCurrentTextNode.creator;
                    var xy = YAHOO.util.Dom.getXY(oCurrentTextNode.getContentEl());
                    catpropertiesdialog.moveTo(xy[0]+100, xy[1]+40);
                    YAHOO.util.Event.addListener(YAHOO.util.Dom.get("catpropname"), "change", checkFormFields);
                    YAHOO.util.Event.addListener(YAHOO.util.Dom.get("catpropdesc"), "change", checkFormFields);
                    YAHOO.util.Event.addListener(YAHOO.util.Dom.get("catpropname"), "keyup", checkFormFields);
                    YAHOO.util.Event.addListener(YAHOO.util.Dom.get("catpropdesc"), "keyup", checkFormFields);
                    YAHOO.util.Event.addListener(YAHOO.util.Dom.get("catparent"), "change", checkFormFields);
                    catpropertiesdialog.show();
                }

                function addCatalog()
                {

                    // console.dir(oCurrentTextNode);
                    var parent = oCurrentTextNode.catid;
                    var type = oCurrentTextNode.cattype;
                    if (!parent)
                    {
                        return false;
                    }

                    if (oCurrentTextNode instanceof IPACatalogNode && oCurrentTextNode.depth > 0)
                    {
                        YAHOO.util.Dom.get("parent").innerHTML =
                            YAHOO.util.Dom.get("prefix").value =
                            oCurrentTextNode.name + '.';
                    }
                    else
                    {
                        YAHOO.util.Dom.get("parent").innerHTML =
                            YAHOO.util.Dom.get("prefix").value = "";
                    }
                    YAHOO.util.Dom.get("parent").value = parent;
                    YAHOO.util.Dom.get("cattype").value = type;
                    var xy = YAHOO.util.Dom.getXY(oCurrentTextNode.getContentEl());
                    catdialog.moveTo(xy[0]+100, xy[1]+40);
                    catdialog.show();
                }

                function addDataset() {
                    var xy = YAHOO.util.Dom.getXY(oCurrentTextNode.getContentEl());
                    YAHOO.util.Dom.get("ds-catname").value = oCurrentTextNode.name;
                    YAHOO.util.Dom.get("ds-catid").value = oCurrentTextNode.catid;
                    YAHOO.util.Dom.get("ds-start").checked = null;
                    YAHOO.util.Dom.get("ds-start-date").value = null;
                    YAHOO.util.Dom.get("ds-start-time").value = null;
                    YAHOO.util.Dom.get("ds-start-text").innerHTML = "None";
                    YAHOO.util.Dom.setStyle('ds-start-date', 'display', 'none');
                    YAHOO.util.Dom.setStyle('ds-start-time', 'display', 'none');
                    YAHOO.util.Dom.setStyle('ds-end-date', 'display', 'none');
                    YAHOO.util.Dom.setStyle('ds-end-time', 'display', 'none');
                    YAHOO.util.Dom.get("ds-end").checked = null;
                    YAHOO.util.Dom.get("ds-end-date").value = null;
                    YAHOO.util.Dom.get("ds-end-time").value = null;
                    YAHOO.util.Dom.get("ds-end-text").innerHTML = "None";
                    YAHOO.util.Dom.get("ds-start").focus();
                    dsdialog.moveTo(xy[0]+100, xy[1]+40);
                    dsdialog.show();
                }

                function linkCatalog() {

                    function populateChildList()
                    {
                        function handleSuccess(oResponse)
                        {
                            var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
                            if (res)
                            {
                                var selectedid = -1;
                                var catlist;
                                for (var i=0; i < res.length; i++ )
                                {
                                    catlist += '<option value="'
                                        + res[i].id + '"'
                                        + '>'
                                        + res[i].name + '</option>'
                                }
                                YAHOO.util.Dom.get("linkcatchild").innerHTML = catlist;
                            }                                
                        }
                        function handleFailure(oResponse)
                        {
                            alert("failed to get catalog tree");
                        }
                        var callback = { success: handleSuccess, failure: handleFailure };

                        var sUrl = "browse/catalogs";
                        YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);
                    }

                    var parent = oCurrentTextNode.catid;
                    if (!parent)
                    {
                        return false;
                    }
                    YAHOO.util.Dom.get("linkcatparent").value = parent;
                    YAHOO.util.Dom.get("linkchilddiv").innerHTML =
                        '<select name="linkcatchild" id="linkcatchild" size="10"></select>';
                    populateChildList();
                    var xy = YAHOO.util.Dom.getXY(oCurrentTextNode.getContentEl());
                    linkcatdialog.moveTo(xy[0]+100, xy[1]+40);
                    linkcatdialog.show();
                }

                function unlinkCatalog() {
                    if (! oCurrentTextNode.editable)
                    {
                        alert("You don't have permission to unlink this catalog.");
                        return false;
                    }

                    var parent = oCurrentTextNode.parent;
                    if (! parent)
                        return false;

                    var parent_id = parent.catid;
                    var child_id = oCurrentTextNode.catid;

                    if (! (parent_id && child_id))
                        return false;

                    function handleSuccess(oResponse)
                    {
                        var status = YAHOO.lang.JSON.parse(oResponse.responseText).status;
                        var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
                        if (status)
                        {
                            buildTree();
                        }
                        else
                        {
                            alert(res);
                        }
                    }
                    function handleFailure(oResponse)
                    {
                        alert("failed to unlink catalog");
                    }

                    var callback = { success: handleSuccess, failure: handleFailure };

                    var sUrl = "browse/unlink_catalog?linkcatchild=" + child_id
                        + "&linkcatparent=" + parent_id;
                    YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);
                }

                function deleteCatalog() {
                    if (! oCurrentTextNode.editable)
                    {
                        alert("You don't have permission to delete this catalog.");
                        return false;
                    }
                    YAHOO.util.Dom.get("catid").value = oCurrentTextNode.catid;
                    var xy = YAHOO.util.Dom.getXY(oCurrentTextNode.getContentEl());
                    delcatdialog.moveTo(xy[0]+100, xy[1]+40);
                    delcatdialog.show();
                }

                function onTriggerContextMenu(p_oEvent) {
                    var oTarget = this.contextEventTarget;

                    var dsitems =[ { text: "View datasets", onclick: { fn: viewDatasets } }];

                    oCurrentTextNode = tree.getNodeByElement(oTarget);
//                    if (oCurrentTextNode instanceof IPACatalogNode && oCurrentTextNode.depth > 0)
                    if (oCurrentTextNode instanceof IPACatalogNode || oCurrentTextNode instanceof YAHOO.widget.RootNode)
                    {
                        this.clearContent();
                        if (oCurrentTextNode.editable)
                        {
                            this.addItem({ text: "Add a catalog", onclick: { fn: addCatalog }});
                            this.addItem({ text: "Add a dataset", onclick: { fn: addDataset }});
                            this.addItem({ text: "Create a catalog link ", onclick: { fn: linkCatalog } });
                            if (oCurrentTextNode.parent)
                                this.addItem({ text: "Unlink this catalog ", onclick: { fn: unlinkCatalog } });
                            this.addItem({ text: "Delete this catalog", onclick: { fn: deleteCatalog } });
                            
                        }
                        this.addItem({ text: "View datasets", onclick: { fn: viewDatasets }});
                        this.addItem({ text: "Properties", onclick: { fn: nodeProperties } });
                        this.render();
                    }
                    else if (oCurrentTextNode instanceof IPADatasetNode)
                    {
                        this.clearContent();
                        this.addItems(dsitems);
                        this.render();
                    }
                    else
                    {
                        this.cancel();
                    }
                    if (!oCurrentTextNode)
                    {
                        // Cancel the display of the ContextMenu instance.
                        this.cancel();
                    }

                }

                var oContextMenu = new YAHOO.widget.ContextMenu(
                    "treecontextmenu",
                    {
                        trigger: "catalogs"
                    }
                );

                function onContextMenuFocus()
                {
                    var focusedel = YAHOO.util.Dom.getFirstChild(oCurrentTextNode.getEl());
                    YAHOO.util.Dom.addClass(focusedel, "contextfocus");
                }
                function onContextMenuBlur()
                {
                    var focusedel = YAHOO.util.Dom.getFirstChild(oCurrentTextNode.getEl());
                    YAHOO.util.Dom.removeClass(focusedel, "contextfocus");
                }
                oContextMenu.subscribe("focus", onContextMenuFocus);
                oContextMenu.subscribe("blur", onContextMenuBlur);
                oContextMenu.subscribe("triggerContextMenu", onTriggerContextMenu);
                oContextMenu.render(document.body);
            },
            timeout:15000
        }
        
        YAHOO.util.Connect.asyncRequest('GET', sUrl, callback);

        /*
          Subscribe to the "contextmenu" event for the element(s)
          specified as the "trigger" for the ContextMenu instance.
        */

        function tree_onClickEvent (p_oEvent, p_args)
        {
            p_oEvent.node.toggleHighlight();
            return false;
        }
        

    }

    buildTree();

    // Set up the "add catalog" dialog 
    (function () {
        function handleSubmit()
        {
            this.submit();
        }

        function handleCancel()
        {
            this.cancel();
        }

        function handleSuccess(oResponse)
        {
            var status = YAHOO.lang.JSON.parse(oResponse.responseText).status;
            var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
            if (status)
            {
                res.editable = true;
                var newnode = new IPACatalogNode(res, oCurrentTextNode);
                buildTree();
            }
            else
            {
                alert(res);
            }
            catdialog.hide();
        }
        function handleFailure(oResponse)
        {
            alert("Failed to add catalog");
            catdialog.hide();
        }

        YAHOO.util.Dom.removeClass("catdialog", "yui-pe-content");
        
	    catdialog = new YAHOO.widget.Dialog("catdialog", 
							                { width : "40em",
							                  fixedcenter : true,
							                  visible : false, 
							                  constraintoviewport : true,
							                  buttons : [ { text:"Add", handler:handleSubmit, isDefault:true },
								                          { text:"Cancel", handler:handleCancel } ]
							                });

	    catdialog.validate = function() {
		    var data = this.getData();
		    if (data.catname == "" || data.catdesc == "") {
			    alert("Please enter a catalog name and description.");
			    return false;
		    } else {
			    return true;
		    }
	    };

        function reset_form() {
            YAHOO.util.Dom.get("catform").reset();
        }

        catdialog.submitEvent.subscribe(reset_form);
        catdialog.cancelEvent.subscribe(reset_form);

	    catdialog.callback = { success: handleSuccess,
						       failure: handleFailure };
	    
        catdialog.center();
	    catdialog.render();
    })();


    // Set up the "link to catalog" dialog 
    (function () {
        function handleSubmit()
        {
            this.submit();
        }

        function handleCancel()
        {
            this.cancel();
        }

        function handleSuccess(oResponse)
        {
            var status = YAHOO.lang.JSON.parse(oResponse.responseText).status;
            var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
            if (status)
            {
                buildTree();
            }
            else
            {
                alert(res);
            }
            linkcatdialog.hide();
        }
        function handleFailure(oResponse)
        {
            alert("Failed to add catalog");
            catdialog.hide();
        }

        YAHOO.util.Dom.removeClass("linkcatdialog", "yui-pe-content");
        
	    linkcatdialog = new YAHOO.widget.Dialog("linkcatdialog", 
							                    { width : "30em",
							                      fixedcenter : true,
							                      visible : false, 
							                      constraintoviewport : true,
							                      buttons : [ { text:"Add", handler:handleSubmit, isDefault:true },
								                              { text:"Cancel", handler:handleCancel } ]
							                    });

	    linkcatdialog.validate = function() {
		    var data = this.getData();
		    if (data.parent == "" || data.child == "") {
			    alert("Please enter a catalog name and description.");
			    return false;
		    } else {
			    return true;
		    }
	    };

        function reset_form() {
            YAHOO.util.Dom.get("linkcatform").reset();
        }

        linkcatdialog.submitEvent.subscribe(reset_form);
        linkcatdialog.cancelEvent.subscribe(reset_form);


	    linkcatdialog.callback = { success: handleSuccess,
						           failure: handleFailure };
	    
        linkcatdialog.center();
	    linkcatdialog.render();
    })();

    // Set up the "delete catalog" dialog
    (function () {
        function handleSubmit()
        {
            this.submit();
        }

        function handleCancel()
        {
            this.cancel();
        }

        function handleSuccess(oResponse)
        {
            var res = YAHOO.lang.JSON.parse(oResponse.responseText);
            if (res)
            {

                parent = oCurrentTextNode.parent;
                tree.removeNode(oCurrentTextNode);
                parent.refresh();
            }
            else
            {
                alert("Failed to delete catalog.");
            }
            delcatdialog.hide();
        }

        function handleFailure(oResponse)
        {
            alert("Failed to delete catalog");
            delcatdialog.hide();
        }

        YAHOO.util.Dom.removeClass("delcatdialog", "yui-pe-content");
        
	    delcatdialog = new YAHOO.widget.Dialog
        ("delcatdialog", 
		 { width : "30em",
		   fixedcenter : true,
		   visible : false, 
           modal: true,
		   constraintoviewport : true,
		   buttons : [ { text:"Yes", handler:handleSubmit, isDefault:true },
					   { text:"No", handler:handleCancel } ]
		 });
        
	    delcatdialog.callback = { success: handleSuccess,
						          failure: handleFailure };
	    delcatdialog.center();
	    delcatdialog.render();
    })();

    // Set up the "catalog properties" dialog
    (function () {
        function handleSubmit()
        {
            this.submit();
        }

        function handleCancel()
        {
            this.cancel();
        }

        function handleSuccess(oResponse)
        {
            var status = YAHOO.lang.JSON.parse(oResponse.responseText).status;
            var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;

            if (status)
            {
                buildTree();
            }
            else
            {
                alert("Failed to update catalog: " + res);
            }
            catpropertiesdialog.hide();
        }

        function handleFailure(oResponse)
        {
            alert("Failed to update catalog");
            catpropertiesdialog.hide();
        }

        YAHOO.util.Dom.removeClass("catpropertiesdialog", "yui-pe-content");
        
	    catpropertiesdialog = new YAHOO.widget.Dialog
        ("catpropertiesdialog", 
		 { width : "40em",
	       fixedcenter : true,
	       visible : false,
           modal: true,
	       constraintoviewport : true,
		   buttons : [ { text:"Save", handler:handleSubmit, isDefault:true },
					   { text:"Cancel", handler:handleCancel } ]
		 });


        function reset_form() {
            YAHOO.util.Dom.get("catpropertiesform").reset();
        }

        catpropertiesdialog.submitEvent.subscribe(reset_form);
        catpropertiesdialog.cancelEvent.subscribe(reset_form);

        
	    catpropertiesdialog.callback = { success: handleSuccess,
						                 failure: handleFailure };
	    catpropertiesdialog.center();
	    catpropertiesdialog.render();
        catpropertiesdialog.getButtons()[0].set("disabled", true);
    })();



    // Set up the "add dataset" dialog 
    (function () {
        function handleSubmit()
        {
            this.submit();
            YAHOO.util.Dom.get("dsform").reset();
        }

        function handleCancel()
        {
            this.cancel();
            YAHOO.util.Dom.get("dsform").reset();
        }

        function handleSuccess(oResponse)
        {
            var status = YAHOO.lang.JSON.parse(oResponse.responseText).status;
            var res = YAHOO.lang.JSON.parse(oResponse.responseText).result;
            if (status)
            {
                res.editable = true;
                if (oCurrentTextNode.children[0] instanceof IPADatasetNode)
                {
                    tree.removeNode(oCurrentTextNode.children[0]);
                }

                var newnode = new IPADatasetNode(res, null);
                newnode.appendTo(oCurrentTextNode);
                fixTree2(newnode);
                newnode.parent.refresh();
                dsdialog.hide();
            }
            else
            {
                alert(res);
            }

        }
        function handleFailure(oResponse)
        {
            alert("Failed to add dataset");
            dsdialog.hide();
        }

        YAHOO.util.Dom.removeClass("dsdialog", "yui-pe-content");
        
	    dsdialog = new YAHOO.widget.Dialog("dsdialog", 
							                { width : "30em",
							                  fixedcenter : true,
							                  visible : false, 
							                  constraintoviewport : true,
							                  buttons : [ { text:"Add", handler:handleSubmit, isDefault:true },
								                          { text:"Cancel", handler:handleCancel } ]
							                });

	    dsdialog.validate = function() {
            return true
	    };

	    dsdialog.callback = { success: handleSuccess,
						       failure: handleFailure };

        dsdialog.center();
	    dsdialog.render();
    })();



}

function do_assoc_query() {
    dspanel.hide();
    var paths = tree.selectedNodes();
    //var time = YAHOO.util.Dom.get("time").value;
    var address = YAHOO.util.Dom.get("address").value;
    var label = YAHOO.util.Dom.get("querylabel").value;
    var stime, etime;
    //var dt = assoc_table.myDataTable;

    switch(window.daterangetype)
    {
    case "at":
        stime = YAHOO.util.Dom.get("start-date").value + ':' + YAHOO.util.Dom.get("start-time").value;
        etime = null;
        break;
    case "before":
        stime = "-infinity";
        etime = YAHOO.util.Dom.get("end-date").value  + ':' + YAHOO.util.Dom.get("end-time").value;
        break;
    case "after":
        stime = YAHOO.util.Dom.get("start-date").value + ':' + YAHOO.util.Dom.get("start-time").value;
        etime = "infinity";
        break;
    case "between":
        stime = YAHOO.util.Dom.get("start-date").value + ':' + YAHOO.util.Dom.get("start-time").value;
        etime = YAHOO.util.Dom.get("end-date").value + ':' + YAHOO.util.Dom.get("end-time").value;
        break;
    default:
        stime = null;
        etime = null;
        break;
    }

    assoc_form.do_query(paths, address, label, stime, etime);
}

function do_assoc_query2() {
    dspanel.hide();
    assoc_form.disableEdit();
    selected = tree.selectedNodes();
    //var time = YAHOO.util.Dom.get("time").value;
    var address = YAHOO.util.Dom.get("address").value;
    var label = YAHOO.util.Dom.get("querylabel").value;
    var stime, etime;
    var dt = assoc_table.myDataTable;

    switch(window.daterangetype)
    {
    case "at":
        stime = YAHOO.util.Dom.get("start-date").value + ':' + YAHOO.util.Dom.get("start-time").value;
        etime = null;
        break;
    case "before":
        stime = "-infinity";
        etime = YAHOO.util.Dom.get("end-date").value  + ':' + YAHOO.util.Dom.get("end-time").value;
        break;
    case "after":
        stime = YAHOO.util.Dom.get("start-date").value + ':' + YAHOO.util.Dom.get("start-time").value;
        etime = "infinity";
        break;
    case "between":
        stime = YAHOO.util.Dom.get("start-date").value + ':' + YAHOO.util.Dom.get("start-time").value;
        etime = YAHOO.util.Dom.get("end-date").value + ':' + YAHOO.util.Dom.get("end-time").value;
        break;
    default:
        stime = null;
        etime = null;
        break;
    }

    assoc_table.address = address;
    assoc_table.label = label;
    assoc_table.stime = stime;
    assoc_table.etime = etime;

    header = YAHOO.util.Dom.get("assocheader");
    header.innerHTML = "Association query results";

    if (!selected && !address && !label && !stime && !etime)
    {
        alert('Please select one or more filter criteria.');
        return;
    }

    if (selected)
    {
        assoc_table.paths = selected;
        var oState = dt.getState(), request;
        //request = dt.get("generateRequest")(oState, dt);
        assoc_table.updateDataTable(true);
    }
    else
    {
        assoc_table.paths = null;
        var oState = dt.getState(), request;
        //request = dt.get("generateRequest")(oState, dt);
        assoc_table.updateDataTable(true);
    }
}

YAHOO.util.Event.on('btnShowAssoc','click', do_assoc_query);

function reset_assoc_form()
{
    function resetnode(node)
    {
        node.unhighlight();

        if (node instanceof IPADatasetNode)
        {
            if (node.dt)
            {
                node.dt.destroy();
                node.dt = null;
            }
        }

        for (var i=0; i < node.children.length; i++)
        {
            resetnode(node.children[i]);
        }

    }

    dspanel.hide();

    resetnode(tree.getRoot());
    YAHOO.util.Selector.query('#start-date', null, true).value = null;
    YAHOO.util.Selector.query('#start-time', null, true).value = null;
    YAHOO.util.Selector.query('#end-date', null, true).value = null;
    YAHOO.util.Selector.query('#end-time', null, true).value = null;
    YAHOO.util.Dom.setStyle('start-date', 'display', 'none');
    YAHOO.util.Dom.setStyle('start-time', 'display', 'none');
    YAHOO.util.Dom.setStyle('timeand', 'display', 'none');
    YAHOO.util.Dom.setStyle('end-date', 'display', 'none');
    YAHOO.util.Dom.setStyle('end-time', 'display', 'none');
}

YAHOO.util.Event.on('btnResetAssocForm','click', reset_assoc_form);
