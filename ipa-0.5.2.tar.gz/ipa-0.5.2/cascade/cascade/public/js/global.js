var tree;
var daterangetype;
var dspanel;
var layout;
//var assoc_table;
var assoc_form;
var notes_form;

if (!window.console)
{
    var names = ["log", "debug", "info", "warn", "error", "assert", "dir", "dirxml",
                 "group", "groupEnd", "time", "timeEnd", "count", "trace", "profile", "profileEnd"];

    window.console = {};
    for (var i = 0; i < names.length; ++i)
        window.console[names[i]] = function() {}
}
else
{
    console.log("Logging enabled");
}

function formatDate(cell, record, column, date) {
    if (date.substr(0,4) == "0001")
    {
        cell.innerHTML = "-&infin;";
    }
    else if (date.substr(0,4) == "9999")
    {
        cell.innerHTML = "&infin;";
    }
    else
    {
        d = Date.parse(date).toString('yyyy/MM/dd:HH');
        if (date.substr(11,8) != "00:00:00")
            cell.innerHTML = d + "&hellip;";
        else
            cell.innerHTML = d;
    }
}


function formatDateShort(cell, record, column, date) {
    cell.innerHTML = date.substr(0,19);
}


IPACatalogNode = function(oData, oParent, expanded) {
    IPACatalogNode.superclass.constructor.call(this, oData, oParent, expanded);
    var catclass = "catalognode";
    this.description = oData.title;
    
    if (oData.expanded)
    {
        this.expanded = true;
    }

    if (oData.editable) {
        catclass += " editable";
    }

    if (oData.home) {
        catclass += " home";
    }

    this.html = '<span class="' + catclass + '" title="' + 
        (oData.title ? oData.title : oData.name) + '">' + oData.name +
        (oData.title ? '<span class="catdesc">' +  oData.title + '</span>' : '') +
        '</span>';
};

YAHOO.lang.extend(IPACatalogNode, YAHOO.widget.HTMLNode, {
    name: null,
    description: null,
    catid: null,
    parent_id: null,
    prefix: null,
    suffix: null,
    creator: null,
    creator_uid: null,
    editable: false,
    cattype: null
});

IPADatasetNode = function(oData, oParent, expanded) {
    IPADatasetNode.superclass.constructor.call(this, oData, oParent, expanded);
};
YAHOO.lang.extend(IPADatasetNode, YAHOO.widget.HTMLNode, {
    dsid: null,
    count: null,
    begin: null,
    end: null,
    type: null,
    opened: false
});
