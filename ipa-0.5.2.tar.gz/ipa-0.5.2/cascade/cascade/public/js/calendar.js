var cal1;
var over_cal = false;
function loadCals() {
    //    cal1 = new YAHOO.widget.Calendar("cal1","cal1Container");
    cal1 = new YAHOO.WHII.widget.MultiLayerCalendar("cal1Container", { title: 'Date Select'});
    cal1.cfg.setProperty('navigator', true);
    cal1.cfg.setProperty('tabindex', '-1');    
    cal1.selectEvent.subscribe(getDate, cal1, true);
    cal1.renderEvent.subscribe(setupListeners, cal1, true);
    var pickers =  YAHOO.util.Selector.query('.date-picker'); 
    for( i in pickers){
        YAHOO.util.Event.addListener(pickers[i], 'focus', showCal);
        YAHOO.util.Event.addListener(pickers[i], 'blur', hideCal);
    }
    cal1.render();
}
function setupListeners() {
    YAHOO.util.Event.addListener('cal1Container', 'mouseover', overCal);
    YAHOO.util.Event.addListener('cal1Container', 'mouseout', outCal);
}
function getDate() {
    var calDate = this.getSelectedDates()[0];
    //    var month = calDate.getMonth() + 1;
    //    calDate = calDate.getFullYear() + '/' + month + '/' + calDate.getDate();
    calDate = Date.parse(calDate.getFullYear() + '/' + (calDate.getMonth() + 1) + '/' + calDate.getDate()).toString('yyyy/MM/dd');
    YAHOO.util.Selector.query('.activeCal')[0].value = calDate;
    over_cal = false;
    hideCal();
}
function showCal(e, targ) {
    var xy = YAHOO.util.Dom.getXY(this);
    var el = new YAHOO.util.Element(this); 
    el.addClass('activeCal');
    var date = this.value;
    if (date) {
        var caldate = Date.parse(date).toString('MM/dd/yyyy');
        cal1.cfg.setProperty('selected', caldate);
        cal1.cfg.setProperty('pagedate', new Date(caldate), true);
    }
    YAHOO.util.Dom.setStyle('cal1Container', 'display', 'block');
    xy[1] = xy[1] + 20;
    YAHOO.util.Dom.setXY('cal1Container', xy);
    cal1.render();
}
function hideCal() {
    if (!over_cal) {
        var els = new YAHOO.util.Selector.query('input.activeCal');
        YAHOO.util.Dom.removeClass(els, 'activeCal');
        YAHOO.util.Dom.setStyle('cal1Container', 'display', 'none');
    }
}
function overCal() {
    over_cal = true;
}
function outCal() {
    over_cal = false;
}
YAHOO.util.Event.addListener(window, 'load', loadCals);
