(function(){

    var Dom = YAHOO.util.Dom,
	Event = YAHOO.util.Event,
	Lang = YAHOO.lang,
	DT = YAHOO.widget.ScrollingDataTable;

    var EndlessDataTable = function(elContainer,aColumnDefs,oDataSource,oConfigs) {

        EndlessDataTable.superclass.constructor.call(this, elContainer,aColumnDefs,oDataSource,oConfigs); 

    };
	
	YAHOO.widget.EndlessDataTable = EndlessDataTable;

	// Copy over DataTable constants and other static members
	Lang.augmentObject(EndlessDataTable, DT);
	
    Lang.extend( 
        EndlessDataTable,
        DT, 
        {
			/**
			 * Initialize internal event listeners
			 *
			 * @method _initEvents
			 * @private
			 */
            page: 0,
            row_count: 0,
            record_count: 0,
            updating: false,
			_initEvents: function () {
                // console.log("initEvents");
				EndlessDataTable.superclass._initEvents.call(this);
                var dt = this;
                //this.on( 'postRenderEvent', this.restoreExpandedRows );			
				//this.on( 'cellClickEvent', this.onEventToggleRowExpansion );
                
                YAHOO.util.Event.on(this.getBdContainerEl(), 'scroll',function (ev) {
                    //console.log("scroll");
                    var scrollTop = YAHOO.util.Event.getTarget(ev).scrollTop;
			        var tbodyHeight = YAHOO.util.Dom.getRegion(dt.getTbodyEl()).height;
			        var bdContainerHeight = YAHOO.util.Dom.getRegion(dt.getBdContainerEl()).height;

			        if ( !dt.updating &&
                         (scrollTop - (dt.footer.offsetHeight / 2) > (tbodyHeight - bdContainerHeight)
                         )
                         && dt.row_count < dt.record_count) {
                        dt.updating = true;
                        dt.page++;
				        dt.footer.innerHTML = "loading...";
				        dt.updateAppendingRows();
			        }
                });

               
	            this.on('dataReturnEvent', function(oArgs) {
                    this.row_count += oArgs.response.results.length;
                    this.updating = false;
                    // console.log("dataReturnEvent: " + this.row_count);
                });

	            this.on('columnSortEvent', function(oArgs) {
                    // console.log('columnSortEvent');
                    this.row_count = this.record_count = this.page = 0;
                });

		        this.on('initEvent', function () {
                    // console.log('initEvent');
                    if (! dt.footer)
                    {
			            var tfoot = this.getTableEl().appendChild(document.createElement('tfoot')),
			            tr = tfoot.appendChild(document.createElement('tr'));
			            dt.footer = tr.appendChild(document.createElement('td'));
                    }
                    YAHOO.util.Dom.setStyle(dt.footer, "display", "table-cell");
                    YAHOO.util.Dom.setAttribute(dt.footer, "colspan", "0");
                    YAHOO.util.Dom.setStyle(dt.footer, "height", "6em");
                    YAHOO.util.Dom.setStyle(dt.footer, "text-align", "center");
                    YAHOO.util.Dom.setStyle(dt.footer, "vertical-align", "top");
                    YAHOO.util.Dom.setStyle(dt.footer, "background", "transparent");
                    YAHOO.util.Dom.setStyle(dt.footer, "filter", "none");
			        dt.footer.innerHTML = "";
                    YAHOO.util.Event.on(dt.footer, 'click', function () {
                        dt.updating = true;
                        dt.page++;
				        dt.updateAppendingRows();
                    });

		        });

		        this.on('postRenderEvent', function () {
                    // console.log('postRenderEvent');
                    // console.log("rows: " + this.row_count);
                    // console.log("recs: " + this.record_count);
                    
                    if (this.record_count){ 
                        YAHOO.util.Dom.setStyle(dt.footer, "display", "table-cell");
                        var remaining = this.record_count - this.row_count;
                        if (remaining > 0)
                        {
                            YAHOO.util.Dom.setStyle(dt.footer, "height", "6em");
                            YAHOO.util.Dom.setStyle(dt.footer, "background", "#426FD9");
                            YAHOO.util.Dom.setStyle(dt.footer, "filter", "progid:DXImageTransform.Microsoft.gradient(startColorstr='#EDF5FF', endColorstr='#426FD9')");
                            YAHOO.util.Dom.setStyle(dt.footer, "background", "-webkit-gradient(linear, left top, left bottom, from(#EDF5FF), to(#426FD9))");
                            YAHOO.util.Dom.setStyle(dt.footer, "background", "-moz-linear-gradient(top,  #EDF5FF, #426FD9)");
				            dt.footer.innerHTML = remaining + " more";
                        }
                        else
                        {
                            YAHOO.util.Dom.setStyle(dt.footer, "height", "3em");
				            dt.footer.innerHTML = "End of results";
                            YAHOO.util.Event.removeListener(dt.footer, 'click');
                        }
                    }
                    else
                    {
                        YAHOO.util.Dom.setStyle(dt.footer, "display", "none");
                    }
		        });

			},
            updateAppendingRows: function() {
                // console.log('updateAppendingRows');
                var oState = this.getState(),
                request,
                oCallback;
    		    oCallback = {
    			    success : this.onDataReturnAppendRows,
    			    failure : this.onDataReturnAppendRows,
                    argument : oState,
    			    scope : this
    		    };
                request = this.get("generateRequest")(oState, this);
    	        this.getDataSource().sendRequest(request, oCallback);
            },
            initAttributes : function( oConfigs ) {

                oConfigs = oConfigs || {};

                EndlessDataTable.superclass.initAttributes.call( this, oConfigs );
                this.setAttributeConfig('resultsPerPage', {
                    value: null,
                    validator: function( value ) {
                        return Lang.isNumber( value );
                    },
                    method: function (value) {
                        this.set('initialRequest',  "page=0&results=" + value);
                    }
                });
            },


            
            handleDataReturnPayload: function(oRequest, oResponse, oPayload) {
	            this.record_count = oPayload.totalRecords = oResponse.meta.totalRecords; 
                // console.log("handleDataReturnPayload:" + this.record_count);
	            return oPayload; 
	        },

			/**
			 * Loops through all Record instances in the RecordSet
			 * @method forAllRecords
			 * @param fn {Function} Reference to a function that will be called once for ever record.  
			 *                      fn will receive a Record instance and the index for the record as its arguments.
			 *                      fn may return false to break out of the loop.
			 * @param scope {Object} (optional) Scope to execute fn in.  It defaults to the DataTable instance.
			 *
			 */
			forAllRecords: function (fn, scope) {
				if (!Lang.isFunction(fn)) {return;}
				scope = scope || this;
				for (var recs = this._oRecordSet._records, l = recs.length, i = 0; i < l; i++) {
					if (fn.call(scope, recs[i], i) === false) {return;}
				}
			}
		}
	);

})();
