function note_query_to_ip(ip)
{
    reset_notes_form();
    YAHOO.util.Dom.get("address").value = ip;
    notes_form.do_query(ip, null);
}


function format_note_url(cell, record, column, data) {
    if  (YAHOO.util.Dom.get("textsearch"))
    {
        cell.innerHTML='<a href="javascript:note_query_to_ip(\'' + data + '\');">' + data + '</a>';
    }
    else
    {
        cell.innerHTML='<a href="javascript:void(0)">' + data + '</a>';
    }

}

function reset_notes_form() {
    var nf = YAHOO.util.Dom.get('notesfields');
    YAHOO.util.Selector.query('#addrop', nf, true).value = "overlaps";
    YAHOO.util.Selector.query('#range', nf, true).value = null;
    YAHOO.util.Selector.query('#notecontents', nf, true).value = null;
}


function do_notes_query()
{
    var addrop = YAHOO.util.Dom.get("addrop").value;
    var range = YAHOO.util.Dom.get("address").value;
    var textsearch = YAHOO.util.Dom.get("textsearch").value;
    notes_form.dt.page = 0;
    notes_form.do_query(addrop, range, textsearch);
}

function loadNotesTable(rows, editable)
{
    var myDataSource, myEditDataSource, paths=[], stime=null,
    etime=null, address=null, label=null;

    notes_form = {
        dt: null,
        fields: ["range","creator_username","creator_displayname","ctime","contents"],
        columns: [
            {key:"ctime", label:"Time", sortable:true, resizeable: true, formatter: formatDateShort},
            {key:"creator_username", label:"Author", sortable:true, resizeable: true},
            {key:"range", label:"Range", sortable:true, resizeable: true, formatter: format_note_url},
            {key:"contents", label:"Note", sortable:false, width: 200, minWidth: 200, maxAutoWidth: 400, resizeable: true},
        ],

        init: function() {
            this.ds  = new YAHOO.util.DataSource("notes/notes",
                                                 {
                                                     responseType: YAHOO.util.DataSource.TYPE_JSON,
                                                     connMethodPost: true,
                                                     connXhrMode: "queueRequests",
                                                     responseSchema: {
                                                         resultsList: "records",
                                                         fields: this.fields,
                                                         metaFields: { 
	                                                         totalRecords: "totalRecords"
	                                                     }
                                                     }
                                                 });
            
            this.dt = new YAHOO.widget.EndlessDataTable("notestable", this.columns,
                                                        this.ds,
                                                        {initialLoad: false,
                                                         draggableColumns: true,
                                                         dynamicData: true, 
                                                         MSG_EMPTY: "No data.  Please select one or more filters.",
                                                         MSG_LOADING: "Loading...",
                                                         height: "450px",
                                                         resultsPerPage: 100,
                                                         generateRequest: this.requestBuilder,
                                                         sortedBy : {
                                                             key:"ctime",
                                                             dir:YAHOO.widget.DataTable.CLASS_DESC
                                                         }
                                                        });

            this.dt.subscribe("rowMouseoverEvent", this.dt.onEventHighlightRow);
	        this.dt.subscribe("rowMouseoutEvent", this.dt.onEventUnhighlightRow); 
            this.dt.subscribe("rowClickEvent",
                              function(ev) {
                                  var target = YAHOO.util.Event.getTarget(ev);
                                  // Unselect row
                                  if (this.isSelected(target)) {
                                      this.unselectRow(target);
                                  }
                                  // Select row
                                  else {
                                      this.selectRow(target);
                                  }
                              }
                             );

            var tt = new YAHOO.widget.Tooltip("notesToolTip");
            var showTimer,hideTimer;

            this.dt.on('cellMouseoverEvent', function (oArgs) {
                var record, description, xy;
                if (showTimer) {
                    window.clearTimeout(showTimer);
                    showTimer = 0;
                }

                var target = oArgs.target;
                var column = this.getColumn(target);
                record = this.getRecord(target);
                if (column == null)
                    return;
                if (column.key == 'creator_username') {
                    description = record.getData('creator_displayname');
                }
                else {
                    description = null;
                }

                if (description)
                {
                    var xy = [parseInt(oArgs.event.clientX,10) + 10 ,parseInt(oArgs.event.clientY,10) + 10 ];
                    showTimer = window.setTimeout(function() {
                        tt.setBody(description);
                        tt.cfg.setProperty('xy',xy);
                        tt.show();
                        hideTimer = window.setTimeout(function() {
                            tt.hide();
                        },5000);
                    },500);
                }
            });


            this.dt.on('dataReturnEvent', this.updateEditTable, this.dt);
            this.dt.on('postRenderEvent', this.updateEditTable, this.dt);
            this.dt.on('columnReorderEvent', this.updateEditTable, this.dt);
            this.dt.on('columnResizeEvent', this.updateEditTable, this.dt);

        },
        updateEditTable: function (event, dt) {
            var xy, x, y;
            if (!dt) 
                return;

            // console.log("notes_table.updateEditTable");

            if (editable)
            {

                var thc = dt.getThLinerEl(dt.getColumn('creator_username'));
                var thr = dt.getThLinerEl(dt.getColumn('range'));
                var thn = dt.getThLinerEl(dt.getColumn('contents'));
                var cx = YAHOO.util.Dom.getX(thc);
                var rx = YAHOO.util.Dom.getX(thr);
                var nx = YAHOO.util.Dom.getX(thn);

                var lastrow = dt.getLastTrEl();
                if (lastrow)
                    y = YAHOO.util.Dom.getY(dt.getMsgTbodyEl()) + dt.getMsgTbodyEl().height + lastrow.height;
                else
                    y = YAHOO.util.Dom.getY(dt.getMsgTbodyEl()) + dt.getMsgTbodyEl().height;

                var nf = YAHOO.util.Dom.get('notesfields');
                var ae = YAHOO.util.Selector.query('#author', nf, true);
                var re = YAHOO.util.Selector.query('#range', nf, true);
                var ce = YAHOO.util.Selector.query('#notecontents', nf, true);
                YAHOO.util.Dom.setStyle(ae, 'width', thc.offsetWidth - 6 + "px");
                YAHOO.util.Dom.setStyle(re, 'width', thr.offsetWidth - 6 + "px");
                YAHOO.util.Dom.setStyle(ce, 'width', thn.offsetWidth - 6 + "px");
                YAHOO.util.Dom.setXY(ae, [cx, y]);
                YAHOO.util.Dom.setXY(re, [rx, y]);
                YAHOO.util.Dom.setXY(ce, [nx, y]);

            }
            if (typeof notespanel != 'undefined' && notespanel)
            {
                notespanel.moveTo(YAHOO.util.Dom.getViewportWidth()/2 - notespanel.element.offsetWidth/2, 20);
            }
        },
        requestBuilder: function (oState, dt) {
    	    var page, results, sort, dir;
    	    oState = oState || {pagination: null, sortedBy: null};
    	    sort = (oState.sortedBy) ? oState.sortedBy.key : null;
    	    dir = (oState.sortedBy && oState.sortedBy.dir === YAHOO.widget.DataTable.CLASS_DESC) ? "desc" : "asc";

            if (sort != dt.last_sort || dir != dt.last_dir)
            {
                dt.page = 0;
                dt.row_count = 0;
            }

            dt.last_sort = sort;
            dt.last_dir = dir;
    	    return  "&page=" 	+ dt.page +
                "&results=" 	+ dt.get('resultsPerPage') +
    		    "&sort=" 	+ sort +
    		    "&dir=" 	+ dir +
    	        ( dt.addrop ? "&addrop=" + encodeURIComponent(YAHOO.lang.JSON.stringify(dt.addrop)) : "") +
    	        ( dt.range ? "&range=" + encodeURIComponent(YAHOO.lang.JSON.stringify(dt.range)) : "") +
    	        ( dt.textsearch ? "&textsearch=" + encodeURIComponent(YAHOO.lang.JSON.stringify(dt.textsearch)) : "");
        },
        do_query:function(addrop, address, textsearch)
        {
            notes_form.dt.page = 0;
            //notes_form.dt.last_sort = null;
            notes_form.dt.addrop = addrop;
            notes_form.dt.range = address;
            notes_form.dt.textsearch = textsearch;
            notes_form.update(true);

        },
        update: function (reset, panel) {
            var oState = this.dt.getState(),
            request,
            oCallback;

    	    /* If the column sort direction needs to be updated, that may be done here.
    	       It is beyond the scope of this example, but the DataTable::sortColumn() method
    	       has code that can be used with some modification. */

            oState = this.dt.getState();
            if(reset)
            {
                this.dt.row_count = 0;
                this.dt.page = 0;
                this.dt.set("sortedBy", {key:"ctime", dir:YAHOO.widget.DataTable.CLASS_DESC});
            }

            var update_callback = function (oRequest, oResponse, oPayload)
            {
                if (reset)
                    this.onDataReturnInitializeTable(oRequest, oResponse, oPayload);
                else
                    this.onDataReturnAppendRows(oRequest, oResponse, oPayload);
                if (panel)
                    notespanel.show();
            }

    		oCallback = {
    			success : update_callback,
    			failure : update_callback,
                argument : oState,
    			scope : this.dt
    		};

    	    // Generate a query string
            request = this.dt.get("generateRequest")(oState, this.dt);
    	    // Fire off a request for new data.
    	    this.dt.getDataSource().sendRequest(request, oCallback);
        }

    }
    notes_form.init();

}

YAHOO.util.Event.on('btnShowNotes','click', do_notes_query);

YAHOO.util.Event.on('btnAddNotes','click',function() {
    var range = YAHOO.util.Dom.get("range").value;
    var contents = YAHOO.util.Dom.get("notecontents").value;

    if (! (range && contents)) return false;
    var sUrl = "notes/add_note?range="
        + YAHOO.lang.JSON.stringify(range)
        + "&contents="
        + YAHOO.lang.JSON.stringify(contents)

    var callback = {
        success: function(oResponse){
            //notes_table.dt.page = 0;
            //notes_form.last_sort = null;
            notes_form.update(true);
        },
        failure: function(oResponse){
            alert("Failed to add note");
        },
        timeout:5000
    }
    YAHOO.util.Connect.asyncRequest('POST', sUrl, callback);

});

YAHOO.util.Event.on('btnClearNotes','click', reset_notes_form);
