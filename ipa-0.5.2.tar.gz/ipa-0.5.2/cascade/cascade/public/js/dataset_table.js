YAHOO.util.Event.addListener(window, "load", function() {
    YAHOO.dataset_table = new function() {
        this.formatUrl = function(elCell, oRecord, oColumn, sData) {
            elCell.innerHTML = "<a href='" + oRecord.getData("ClickUrl") + "' target='_blank'>" + sData + "</a>";
        };

        var myColumnDefs = [
            {key:"id", label:"ID", hidden:true},
            {key:"name", label:"Catalog", sortable:true, resizeable: true},
            {key:"stime", label:"Begin", sortable:true, resizeable: true, width:140},
            {key:"etime", label:"End", sortable:true, resizeable: true, width:140},
            {key:"assoc_count", label:"Assocs", sortable:true, resizeable: true},
            {key:"ip_count", label:"IPs", sortable:true},
        ];

        this.myDataSource = new YAHOO.util.DataSource("datasets?");
        this.myDataSource.responseType = YAHOO.util.DataSource.TYPE_JSON;
        this.myDataSource.connMethodPost = true;
        this.myDataSource.connXhrMode = "queueRequests";
        this.myDataSource.responseSchema = {
            resultsList: "result",
            fields: ["id","name","stime","etime","assoc_count","ip_count"]
        };

        this.myDataTable = new YAHOO.widget.DataTable("datasets", myColumnDefs,
                                                      this.myDataSource,
                                                      {initialLoad:false,
                                                       draggableColumns: true,
                                                       scrollable: true,
                                                       height: (YAHOO.util.Dom.getViewportHeight() * 0.3) + "px"});
        this.myDataTable.subscribe("rowMouseoverEvent", this.myDataTable.onEventHighlightRow); 
	    this.myDataTable.subscribe("rowMouseoutEvent", this.myDataTable.onEventUnhighlightRow); 
	    this.myDataTable.subscribe("rowClickEvent", this.myDataTable.onEventSelectRow); 
    };
    YAHOO.util.Event.on('btn-show-ds','click',function() {

        var oCallback = {
            success : YAHOO.dataset_table.myDataTable.onDataReturnInitializeTable,
            failure : YAHOO.dataset_table.myDataTable.onDataReturnInitializeTable,
            scope : YAHOO.dataset_table.myDataTable,
            argument: YAHOO.dataset_table.myDataTable.getState() // data payload that will be returned to the callback function
        };
        url = "catalogs=" + YAHOO.lang.JSON.stringify(tree.selectedNodes());
        YAHOO.dataset_table.myDataSource.sendRequest(url, oCallback);
	    
    });    
});
