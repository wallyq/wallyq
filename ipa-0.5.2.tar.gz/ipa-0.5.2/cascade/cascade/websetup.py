"""Setup the cascade application"""
import logging
import pylons.test

from cascade.config.environment import load_environment

log = logging.getLogger(__name__)

def setup_app(command, conf, vars):
    """Place any commands to setup cascade here"""
    if not pylons.test.pylonsapp:
	load_environment(conf.global_conf, conf.local_conf)

