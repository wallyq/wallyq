from cascade.tests import *

class TestNotesController(TestController):

    def test_index(self):
        response = self.app.get(url(controller='notes', action='index'))
        # Test response...
