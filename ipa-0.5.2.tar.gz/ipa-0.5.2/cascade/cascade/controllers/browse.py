import logging

from pylons import request, response, session, tmpl_context as c, app_globals
from pylons.controllers.util import abort

from cascade.lib.base import BaseController, render, h
from pprint import pformat
from ipa import *
from cascade.model import *
from pylons.decorators import jsonify
import simplejson
from pylons import cache
from copy import deepcopy
import re

import beaker.cache

log = logging.getLogger(__name__)

ipa = app_globals.ipa

class BrowseController(BaseController):
    requires_auth = True
    requires_admin = False

    def index(self):
        return render('/browse.mako')


    @jsonify
    def catalogs_tree(self):
        if request.params.has_key('expr'):
            expr = int(request.params['expr'])
        else:
            expr = None

        catalogs = ipa.get_catalogs(expr)

        tree = {}
        tree['children'] = []
        tree['name'] = "[All IPA Catalogs]"
        tree['type'] = "root";
        #tree['type'] = "text"
        parents = [ tree ]
        lastdepth = 1
        for c in catalogs:
            depth = int(c.depth)
            cat = dict(catid=c.id, name=c.name, cattype=c.type, title=c.desc,
                       depth=c.depth, childcount=c.childcount,
                       type="catalog", children=[], datasets=[])
            while depth < lastdepth:
                p = parents.pop()
                depth += 1
            parents[-1]['children'].append(cat)
            if c.childcount:
                parents.append(cat)
            lastdepth = c.depth
        return { 'result': tree }

    @jsonify
    def datasets_tree(self):
        if request.params.has_key('expr'):
            expr = int(request.params['expr'])
        else:
            expr = None

        catalogs = list(ipa.get_catalogs(expr))

        tree = {}
        tree['children'] = []
        tree['type'] = "root"
        tree['name'] = "[All IPA Catalogs]"

        #tree['type'] = "text"
        #tree['label'] = "[All IPA Catalogs]"
        parents = [ tree ]
        lastdepth = 1
        for c in catalogs:
            items = re.findall('\.?([^.]+)', c.name)
            if len(items) > 1:
                prefix = '.'.join(items[:-1])
                suffix = items[-1]
            else:
                prefix = None
                suffix = c.name
            depth = int(c.depth)
            editable = session and (session['uid']==c.creator_uid or h.user().has_role('Admin'))
            if app_globals.config.has_key('ipa_user_path'):
                home = session and session.has_key('home') and session['home'] == c.name
                expanded = app_globals.config['ipa_user_path'] == c.name or home
            else:
                home = False
                expanded = False
            cat = dict(catid=c.id, expanded=expanded, name=c.name,
                       parent_id=c.parent_id, prefix=prefix, suffix=suffix,
                       cattype=c.type, title=c.desc, depth=c.depth, 
                       creator=c.creator, creator_uid=c.creator_uid, editable=editable,
                       home=home, childcount=c.childcount, type="catalog",
                       children=[], datasets=[])
            # print "cat: %s" %(cat)
            datasets = list(ipa.get_datasets([c.name + '/']))
            if datasets:
                min_begin = None
                min_end = None

                for d in datasets:
                    if min_begin == None or d.begin < min_begin:
                        min_begin = d.begin
                    if min_end == None or d.end > min_end:
                        min_end = d.end

                ds = dict(catid=c.id, count=len(datasets), begin=h.fix_datetime(min_begin)[0:10], end=h.fix_datetime(min_end)[0:10], type="dataset_group")
                cat['children'].append(ds)

            #    ds = dict(dsid=d.id, stime=h.fix_datetime(d.begin), etime=h.fix_datetime(d.end), assoc_count=d.assoc_count, ip_count=d.ip_count, type="dataset_group")
            #    cat['children'].append(ds)

            # print "parents: %s" %(parents)
            while depth < lastdepth:
                p = parents.pop()
                depth += 1
            parents[-1]['children'].append(cat)
            if c.childcount:
                parents.append(cat)
            lastdepth = c.depth
        return { 'result': tree }


    @jsonify
    def datasets_tree2(self):
        if request.params.has_key('expr'):
            expr = int(request.params['expr'])
        else:
            expr = None

        catalogs = ipa.get_catalogs(expr)

        tree = {}
        tree['children'] = []
        #tree['type'] = "text"
        #tree['label'] = "[All IPA Catalogs]"
        parents = [ tree ]
        lastdepth = 1
        for c in catalogs:
            depth = int(c.depth)
            cat = dict(catid=c.id, label=c.name, cattype=c.type, desc=c.desc,
                       depth=c.depth, childcount=c.childcount, type="catalog", children=[])
            while depth < lastdepth:
                p = parents.pop()
                depth += 1

            parents[-1]['children'].append(cat)

            datasets = list(ipa.get_datasets(c.id))
            for d in datasets:
                ds = dict(dsid=d.id, stime=h.fix_datetime(d.begin), etime=h.fix_datetime(d.end), assoc_count=d.assoc_count, ip_count=d.ip_count, type="dataset")
                cat['children'].append(ds)
                lastdepth += 1

            if c.childcount or len(datasets):
                parents.append(cat)
            lastdepth = c.depth
        return { 'result': tree }

    @jsonify
    def catalogs(self):

        if request.params.has_key('ids'):
            ids = [int(request.params['ids'])]
        else:
            ids = None

        try:
            maxdepth = int(request.params['maxdepth'])
        except:
            maxdepth = None

        catalogs = ipa.get_catalogs(ids)

        return { 'result': [ dict(id=c.id, name=c.name, parent_id=c.parent_id, cattype=c.type, desc=c.desc, depth=c.depth, childcount=c.childcount) for c in catalogs] }

    @jsonify
    def datasets(self):

        (expr) = (None,)

        if request.params.has_key('expr'):
            expr = simplejson.loads(request.params['expr'])

        if not expr:
            return None

        return { 'result': [ dict(id=ds.id, name=ds.cat_name, t_begin=h.fix_datetime(ds.begin), t_end=h.fix_datetime(ds.end), assoc_count=ds.assoc_count, ip_count=ds.ip_count) for ds in ipa.get_datasets(expr) ] }

    @jsonify
    def associations(self, paths=None, t_begin=None, t_end=None, address=None,
                     label=None,sortfield="catalog", sortdir="asc", invalidate=False):

        #@cache.cache('get_assocs', type="memory", expire=3600)
        def get_assocs(paths=None, t_begin=None, t_end=None, address=None,
                       label=None, sortfield="catalog", sortdir="asc",
                       limit=None, offset=None):

            return list(ipa.find_assocs(paths=paths, t_begin=t_begin, t_end=t_end,
                                         range=address, label=label,
                                         sortfield=sortfield, sortdir=sortdir,
                                         limit=limit, offset=offset))

        (paths_json, limit, offset, count) = (None,) * 4
        if request.params.has_key('results'):
            limit = int(request.params['results'])
        if request.params.has_key('page'):
            offset = int(request.params['page']) * limit
        if request.params.has_key('sort'):
            sortfield = request.params['sort']
        if request.params.has_key('dir'):
            sortdir = request.params['dir']
        if request.params.has_key('address'):
            address = request.params['address']
        if request.params.has_key('label'):
            label = request.params['label']
        if request.params.has_key('t_begin'):
            t_begin = simplejson.loads(request.params['t_begin'])
        if request.params.has_key('t_end'):
            t_end = simplejson.loads(request.params['t_end'])
        if request.params.has_key('paths'):
            paths_json = request.params['paths']
            paths = simplejson.loads(paths_json)

        if not (paths or address or label or t_begin or t_end):
            return { 'totalRecords': 0, 'records': [] }

        try:
            (results) = deepcopy(get_assocs(paths, t_begin, t_end, address, label, sortfield, sortdir, limit, offset))
        except IPAError, e:
            return { 'totalRecords': 0, 'records': [] }

        #myassocs = deepcopy(assocs[begin:end])
        for a in results:
            count = a['count']
            a['t_begin'] = h.fix_datetime(a['t_begin'])
            a['t_end'] = h.fix_datetime(a['t_end'])

        return { 'totalRecords': count, 'records': results }


    @jsonify
    def add_assoc(self):
        (dsid, range, label, value, result) = (None,) * 5
        if request.params.has_key('dsid'):
            dsid = int(request.params['dsid'])
        if request.params.has_key('range'):
            range = request.params['range']
        if request.params.has_key('label'):
            label = request.params['label']
        if request.params.has_key('value'):
           value = int(request.params['value'])

        if range:
            try:
                ipa.add_assoc(dsid, range, label, value, session['username'])
                result = True
            except IPARangeError:
                result = False

        return {'result': result}


    @jsonify
    def add_catalog(self):
        (catname, prefix, cattype, catdesc) = (None,) * 4

        if request.params.has_key('catname'):
            catname = request.params['catname']
        if request.params.has_key('prefix'):
            catname = request.params['prefix'] + catname
        if request.params.has_key('cattype'):
            cattype = int(request.params['cattype'])
        if request.params.has_key('catdesc'):
            catdesc = request.params['catdesc']

        if not (catname and cattype):
            return {'status': False, 'result' : "Invalid request"}

        try:
            cat = ipa.add_catalog(catname, type=cattype, desc=catdesc,
                                   creator=session['username'])
            result = cat.__dict__
            result['catid'] = result['id']
            result['cattype'] = result['type']
            del result['id']
        except Exception, e:
            return {'status': False, 'result' : str(e)}

        return {'status': True, 'result' : result}
        

    @jsonify
    def add_dataset(self):
        (catid, t_begin, t_end) = (None,) * 3

        if request.params.has_key('catid'):
            catid = int(request.params['catid'])
        if not (catid):
            return False;
        
        if (request.params.has_key('ds-start')
            and request.params['ds-start'] == "on"):

            if request.params.has_key('start-date'):
                t_begin = request.params['start-date']
            if request.params.has_key('start-time'):
                t_begin += ' ' + request.params['start-time']
        else:
            t_begin = "..."

        if (request.params.has_key('ds-end')
            and request.params['ds-end'] == "on"):

            if request.params.has_key('end-date'):
                t_end = request.params['end-date']
            if request.params.has_key('end-time'):
                t_end += ' ' + request.params['end-time']
        else:
            t_end = "..."

        cat = list(ipa.get_catalogs(catid))[0]
        
        if not cat:
            return False

        try:
            ds = cat.add_dataset(t_begin, t_end, creator=session['username'])

            if ds:
                datasets = list(ipa.get_datasets([catid], unique=True))
                min_begin = None
                min_end = None

                for d in datasets:
                    if min_begin == None or d.begin < min_begin:
                        min_begin = d.begin
                    if min_end == None or d.end > min_end:
                        min_end = d.end

                ds = dict(catid=catid, count=len(datasets), begin=h.fix_datetime(min_begin)[0:10], end=h.fix_datetime(min_end)[0:10], type="dataset_group")

            return {'status': True, 'result' : ds}
        except Exception, e:
            return {'status': False, 'result': str(e)}


    @jsonify
    def cat_properties(self):
        (catid, catname) = (None,) * 2

        if request.params.has_key('catpropid'):
            catid = int(request.params['catpropid'])
        if request.params.has_key('catpropname'):
            catname = request.params['catpropname']
        if request.params.has_key('catpropname'):
            catdesc = request.params['catpropdesc']

        if not (catid and catname):
            return {'status': False, 'result' : None}

        try:
            ipa.update_catalog(catid, catname, catdesc, session['username'])
        except:
            return {'status': False, 'result' : str(e)}

        return {'status': True, 'result' : None}


    @jsonify
    def link_catalog(self):
        (child, parent) = (None,) * 2
        if request.params.has_key('linkcatchild'):
            child = int(request.params['linkcatchild'])
        if request.params.has_key('linkcatparent'):
            parent = int(request.params['linkcatparent'])

        try:
            ipa.link_catalog(child, parent)
        except Exception, e:
            return {'status': False, 'result' : str(e)}

        return {'status': True, 'result' : None}

    @jsonify
    def unlink_catalog(self):
        (child, parent) = (None,) * 2
        if request.params.has_key('linkcatchild'):
            child = int(request.params['linkcatchild'])
        if request.params.has_key('linkcatparent'):
            parent = int(request.params['linkcatparent'])

        try:
            result = ipa.unlink_catalog(child, parent)
            return {'status': True, 'result' : result}
        except Exception, e:
            return {'status': False, 'result': str(e)}

    @jsonify
    def trash_catalog(self):
        (catalog_id) = (None,)
        if request.params.has_key('catid'):
            catalog_id = int(request.params['catid'])

        try:
            return ipa.trash_catalog(catalog_id, session['username'])
        except:
            return False


    @jsonify
    def untrash_catalog(self):
        (catalog_id) = (None,)
        if request.params.has_key('catid'):
            catalog_id = int(request.params['catid'])

        try:
            return ipa.untrash_catalog(catalog_id, session['username'])
        except:
            return False


    @jsonify
    def delete_catalog(self):
        (catalog_id) = (None,)
        if request.params.has_key('catid'):
            catalog_id = int(request.params['catid'])

        try:
            result = ipa.delete_catalog(catalog_id, session['username'])
            return {'status': True, 'result' : result}
        except Exception, e:
            return {'status': False, 'result': str(e)}

    @jsonify
    def delete_dataset(self):
        (dataset_id) = (None,)
        if request.params.has_key('dataset_id'):
            dataset_id = int(request.params['dataset_id'])

        try:
            result = ipa.delete_dataset(dataset_id, session['username'])
            return {'status': True, 'result' : result}
        except Exception, e:
            return {'status': False, 'result': str(e)}

