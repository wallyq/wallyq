import logging

from pylons import request, response, session, tmpl_context as c, url, app_globals
from pylons.controllers.util import abort, redirect

from cascade.lib.base import BaseController, render, h
from pylons.decorators import jsonify

from copy import deepcopy

log = logging.getLogger(__name__)

ipa = app_globals.ipa

class AdminController(BaseController):

    requires_auth = True
    requires_auditor = True
    requires_admin = False

    def index(self): 
        return render('/admin.mako')

    @jsonify
    def user_list(self):

        (limit, offset, begin, end) = (None,) * 4

        if request.params.has_key('results'):
            limit = int(request.params['results'])
        if request.params.has_key('startIndex'):
            offset = int(request.params['startIndex'])

        if offset:
            begin = offset
        if limit:
            end = offset + limit

        # FIXME: caching?
        def get_ipa_users():
            return [ u.__dict__ for u in sorted(list(ipa.get_users()), key=lambda user: user.username) ]

        users = get_ipa_users()

        myusers = deepcopy(users[begin:end])

        return { 'totalRecords': len(users), 'records': myusers }

    
    def users(self):
        return render('/adminusers.mako')

    def audit(self):
        return render('/adminaudit.mako')

    @jsonify
    def audit_log(self):

        (limit, offset) = (None,) * 2

        if request.params.has_key('results'):
            limit = int(request.params['results'])
        if request.params.has_key('page'):
            offset = int(request.params['page']) * limit

        def get_audit_log(limit=None, offset=None):
            return list(ipa.get_audit_log(limit=limit, offset=offset))

        records = deepcopy(get_audit_log(limit=limit, offset=offset))
        for r in records:
            count = r['count']
            r['ctime'] = h.fix_datetime(r['ctime'])

        return { 'totalRecords': count, 'records': records }

    @jsonify
    def audit_detail(self):

        (table, txid) = (None,) * 2
        (limit, offset, sortfield, sortdir) = (None,) * 4

        if request.params.has_key('results'):
            limit = int(request.params['results'])
        if request.params.has_key('page'):
            offset = int(request.params['page']) * limit
        if request.params.has_key('txid'):
            txid = int(request.params['txid'])
        if request.params.has_key('sort'):
            sortfield = request.params['sort']
        if request.params.has_key('dir'):
            sortdir = request.params['dir']

        if (not txid):
            return { 'totalRecords': 0, 'records': [] }
        

        def get_audit_detail(txid, limit=None, offset=None, sortfield=None, sortdir=None):
            return list(ipa.get_audit_detail(txid, limit=limit, offset=offset,
                                             sortfield=sortfield, sortdir=sortdir))

        records = deepcopy(list(get_audit_detail(txid, limit=limit, offset=offset,
                                                 sortfield=sortfield, sortdir=sortdir)))
        for r in records:
            count = r['count']
            r['ctime'] = h.fix_datetime(r['ctime'])

        return { 'totalRecords': count, 'records': records }


    @jsonify
    def add_user(self):
        (uid, username, displayname, role) = (None,) * 4

        if request.params.has_key('username'):
            username = request.params['username']
        if request.params.has_key('displayname'):
            displayname = request.params['displayname']
        if request.params.has_key('role'):
            role = request.params['role']

        if not (username and displayname and role):
            return {'status': False, 'result' : "Missing parameter"}

        try:
            uid = ipa.add_user(username, displayname, role=role,
                                admin_username=session['username'])
        except Exception, e:
            return {'status': False, 'result' : str(e)}

        if app_globals.config.has_key('user_path'):
            # Add a "home directory" for the user to import catalogs and links to system catalogs
            try:
                parent = list(ipa.get_catalogs("^%s" %(app_globals.config['user_path']), include_children=True))[0]

                homecat = ipa.add_catalog(name=username, type=1, parent=parent.id,
                                  desc="User catalog for %s" %(displayname),
                                  creator=username)
            except Exception, e:
                return {'status': False, 'result' : str(e)}

        return {'status': True, 'result' : uid}

    @jsonify
    def update_user(self):
        (uid, username, displayname, role) = (None,) * 4

        if request.params.has_key('moduid'):
            uid = request.params['moduid']
        if request.params.has_key('moddisplayname'):
            displayname = request.params['moddisplayname']
        if request.params.has_key('modrole'):
            role = request.params['modrole']

        if not (displayname and role):
            return {'status': False, 'result' : "Missing parameter"}

        try:
            uid = ipa.update_user(uid, displayname, role=role,
                                admin_username=session['username'])
        except Exception, e:
            return {'status': False, 'result' : str(e)}

        return {'status': True, 'result' : uid}

    @jsonify
    def delete_user(self):
        uid = None

        if request.params.has_key('uid'):
            uid = int(request.params['uid'])

        if not (uid):
            return {'status': False, 'result' : "userid parameter error"}

        try:
            rs = ipa.delete_user(uid, admin_username=session['username'])
        except Exception, e:
            return {'status': False, 'result' : str(e)}

        return {'status': True, 'result' : None}
