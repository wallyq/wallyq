import logging

from pylons import request, response, session, tmpl_context as c, app_globals
from pylons.controllers.util import abort

from cascade.lib.base import BaseController, render, h
from pylons import cache
from copy import deepcopy
from pylons.decorators import jsonify
import simplejson
from ipa import *

log = logging.getLogger(__name__)

ipa = app_globals.ipa

class NotesController(BaseController):

    requires_auth = True

    def index(self):
        return render('/notes.mako')


    @jsonify
    def notes(self):

        #@cache.cache('get_note_count', type="memory", expire=3600)
        def get_note_count(addrop, range, textsearch):
            return len(list(ipa.get_range_notes(comparison=addrop, range=range, textsearch=textsearch, sortfield=sortfield, sortdir=sortdir)))

        #@cache.cache('get_notes', type="memory", expire=3600)
        def get_notes(addrop, range, textsearch, sortfield, sortdir, limit, offset):
            #print "get_notes: %s, %s, %s, %s, %s, %s" %(range, textsearch, sortfield, sortdir, limit, offset)
            return [get_note_count(addrop, range, textsearch),
                    list(ipa.get_range_notes(comparison=addrop, range=range, textsearch=textsearch,
                                             sortfield=sortfield, sortdir=sortdir,
                                             limit=limit, offset=offset))
                    ]
                    
        (addrop, range, textsearch, sort, dir, limit, offset) = (None,) * 7

        sortfield = "ctime"
        sortdir = "desc"

        if request.params.has_key('addrop'):
            addrop = simplejson.loads(request.params['addrop'])
        if request.params.has_key('range'):
            range = simplejson.loads(request.params['range'])
        if request.params.has_key('textsearch'):
            textsearch = simplejson.loads(request.params['textsearch'])
        if request.params.has_key('results'):
            limit = int(request.params['results'])
        if request.params.has_key('page'):
            offset = int(request.params['page']) * limit
        if request.params.has_key('sort'):
            sortfield = request.params['sort']
        if request.params.has_key('dir'):
            sortdir = request.params['dir']


        (count, results) = deepcopy(get_notes(addrop, range, textsearch, sortfield, sortdir, limit, offset))

        for n in results:
            n['ctime'] = h.fix_datetime(n['ctime'])

        return { 'totalRecords': count, 'records': results }

    @jsonify
    def add_note(self):
        (addr, contents) = (None,) * 2

        if request.params.has_key('range'):
            addr = simplejson.loads(request.params['range'])
        if request.params.has_key('contents'):
            contents = simplejson.loads(request.params['contents'])

        if not (addr and contents):
            return [False]

        ipa.add_note(addr, contents, session['username'])

        return [True]
