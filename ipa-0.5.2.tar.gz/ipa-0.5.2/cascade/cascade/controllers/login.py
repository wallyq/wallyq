import logging

from pylons import request, response, session, tmpl_context as c, url, app_globals
from pylons.controllers.util import abort, redirect

from cascade.lib.base import BaseController, render
import cascade.lib.helpers as h
from ipa import *
import pam


log = logging.getLogger(__name__)

class LoginController(BaseController):
    def index(self):
        """
        Show login form. Submits to /login/submit
        """
        return render('login.mako')

    def submit(self):
        """
        Verify username and password
        """
        # Both fields filled?
        form_username = str(request.params.get('username'))
        form_password = str(request.params.get('password'))

        print "user: %s" %(form_username)

        # First, authenticate to PAM
        if not (app_globals.config.has_key('ipa_fake_auth') and app_globals.config['ipa_fake_auth'] == "true"):
            if not pam.authenticate(form_username, form_password, 'login'):
                print "Authentication failure"
                return render('login.mako')
        else:
            print "Faking PAM authentication"

        # Next, check if the user id is in IPA (no password check here)
        try:
            h.user_login(form_username)
        except Exception, e:
            print str(e)
            return render('login.mako')

        # Send user back to the page he originally wanted to get to
        if session.get('path_before_login'):
            print "redirect prev: %s" %(session.get('path_before_login'))
            redirect(url(session['path_before_login']))
        else: # if previous target is unknown just send the user to a welcome page
            print "redirect home: %s" %(url('home'))
            redirect(url('home'))
            
    def logout(self):
        """
        Logout the user and display a confirmation message
        """
        print "logout"
        for k in ['user', 'uid', 'username', 'displayname' 'roles', 'path_before_login', 'home']:
            if k in session:
                del session[k]
        session.save()
        redirect(url('home'))
