from ipa import *
import operator

def get_catalogs():
    ipa = IPA()
    catalog_names = [ (x.id, x.name) for x in ipa.get_catalogs('') ]
    catalog_names.sort(key=operator.itemgetter(1))    
    return catalog_names
