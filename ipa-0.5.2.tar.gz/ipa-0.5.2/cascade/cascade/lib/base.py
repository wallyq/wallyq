"""The base Controller API

Provides the BaseController class for subclassing.
"""
from pylons.controllers import WSGIController
from pylons.templating import render_mako as render
from pylons import session, request, response, config, tmpl_context as c
from pylons.controllers.util import redirect
import cascade.lib.helpers as h
from pylons import url
from pylons.controllers.util import abort

class BaseController(WSGIController):
    requires_auth = False
    requires_admin = False
    requires_auditor = False

    def __before__(self):
        # Authentication required?
        
        def form_login():
            print "form_login"
            session['path_before_login'] = request.path_info
            return redirect(url(controller='login', action='index'))

        if 'REMOTE_USER' in request.environ:
            principal = request.environ['REMOTE_USER']
            print "kerberos principal: %s" %(principal)
            username = principal.split('@')[0]
            try:
                h.user_login(username)
            except Exception, e:
                abort(403, "Insufficient priveleges to view this page")

        if self.requires_auth and 'user' not in session:
            # Remember where we came from so that the user can be sent there
            # after a successful login
            session['path_before_login'] = request.path_info
            session.save()
            return redirect(url(controller='login', action='index'))
        if (self.requires_admin and not h.user().has_role('Admin')):
            abort(403, "Insufficient priveleges to view this page")
        if (self.requires_auditor and not h.user().has_role('Auditor')):
            abort(403, "Insufficient priveleges to view this page")

        if 'username' in session:
            c.username = session['username']

        if config.has_key('ipa_kerberos_realm'):
            c.kerberos_enabled = True
            c.kerberos_realm = config['ipa_kerberos_realm']
        else:
            c.kerberos_enabled = False

    def __call__(self, environ, start_response):
        """Invoke the Controller"""
        # WSGIController.__call__ dispatches to the Controller method
        # the request is routed to. This routing information is
        # available in environ['pylons.routes_dict']
        return WSGIController.__call__(self, environ, start_response)
