"""Helper functions

Consists of functions to typically be used within templates, but also
available to Controllers. This module is available to templates as 'h'.
"""
# Import helpers as desired, or define your own, ie:
#from webhelpers.html.tags import checkbox, password
from pylons import session, url, request, response, app_globals

# from webflash import Flash

# flash = Flash(
#     get_response=lambda: response,
#     get_request=lambda: request
# )

# def flash_ok(message):
#     flash(message, status='ok')

# def flash_info(message):
#     flash(message, status='info')

# def flash_alert(message):
#     flash(message, status='alert')

#class User(object):

#    def __init__(self, username=None, displayname=None, roles=None):
#        self.username = username
#        self.displayname = displayname
#        self.roles = roles

def fix_datetime(dt):
    if dt:
        return dt.isoformat().replace('T',' ').replace('-','/')
    else:
        return ""

def user():
    if 'user' in session:
        return session['user']
    return None

def user_login(username):
    print "user_login"
    ipa = app_globals.ipa

    try:
        user = iter(ipa.get_users(username)).next()
    except Exception, e:
        raise Exception("User not found in IPA database: %s" %(e))

    session['user'] = user
    session['uid'] = user.id
    session['username'] = user.username
    session['displayname'] = user.displayname
    session['roles'] = user.roles

    if app_globals.config.has_key('ipa_user_path'):
        session['home'] = "%s.%s" %(app_globals.config['ipa_user_path'], user.username)
        session.save()
