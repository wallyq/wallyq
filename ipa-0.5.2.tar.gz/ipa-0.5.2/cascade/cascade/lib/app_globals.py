"""The application's Globals object"""
from beaker.cache import CacheManager
from beaker.util import parse_cache_config_options
from ipa import *
from pylons import config


class Globals(object):

    """Globals acts as a container for objects available throughout the
    life of the application

    """
    def __init__(self, config):
        """One instance of Globals is created during application
        initialization and is available during requests via the
        'app_globals' variable

        """
        if config.has_key('ipa_db_pooled') and config['ipa_db_pooled']:
            pooled = True
        else:
            pooled = False
        
        if config['ipa_db_uri']:
            self.ipa = IPA(uri=config['ipa_db_uri'], pooled=pooled)
        else:
            self.ipa = IPA(pooled=True)

        self.config = config

        #print "user path: %s " %(self.config['ipa_user_path'])

        self.cache = CacheManager(**parse_cache_config_options(config))
