/*
** ipa.h
** IP Association Library API Definition
**
** ------------------------------------------------------------------------
** Copyright (C) 2006-2010 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov <tonyc@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/

#ifndef _IPA_IPA_H_
#define _IPA_IPA_H_

/**
 * @file
 *
 * @mainpage libipa
 *
 * IPA is a suite of tools and libraries which aims to provide a flexible
 * repository of IP address data and metadata.  The libipa client library
 * provides an application programming interface to data stored in IPA.
 *
 * You can view details of the libipa interface @subpage libipa "here".
 *
 */

#ifdef HAVE_CONFIG_H
#    include "config.h"
#endif

#include <stdio.h>

#if STDC_HEADERS
#    include <stdlib.h>
#    include <stddef.h>
#else
#    if   HAVE_STDLIB_H
#        include <stdlib.h>
#    endif
#    if   HAVE_MALLOC_H
#        include <malloc.h>
#    endif
#endif /* if STDC_HEADERS */

#if     HAVE_INTTYPES_H
#    include <inttypes.h>
#else
#    if   HAVE_STDINT_H
#        include <stdint.h>
#    endif
#endif /* if     HAVE_INTTYPES_H */
#if     HAVE_UNISTD_H
#    include <unistd.h>
#endif

#if     HAVE_LIMITS_H
#    include <limits.h>
#endif

#if     HAVE_STRING_H
#    if   !STDC_HEADERS && HAVE_MEMORY_H
#        include <memory.h>
#    endif
#    include <string.h>
#endif /* if     HAVE_STRING_H */
#if     HAVE_STRINGS_H
#    include <strings.h>
#endif

#if     HAVE_STDARG_H
#    include <stdarg.h>
#endif

#if     HAVE_ERRNO_H
#    include <errno.h>
#endif

#if     HAVE_ARPA_INET_H
#    include <arpa/inet.h>
#endif

#if     HAVE_PWD_H
#    include <pwd.h>
#endif

/* PRI* macros for printing */
#if !defined (PRIu32)
/* Assume we either get them all or get none of them. */
#    define PRId32 "d"
#    define PRIi32 "i"
#    define PRIo32 "o"
#    define PRIu32 "u"
#    define PRIx32 "x"
#    define PRIX32 "X"

#    define PRId16 PRId32
#    define PRIi16 PRIi32
#    define PRIo16 PRIo32
#    define PRIu16 PRIu32
#    define PRIx16 PRIx32
#    define PRIX16 PRIX32

#    define PRId8  PRId32
#    define PRIi8  PRIi32
#    define PRIo8  PRIo32
#    define PRIu8  PRIu32
#    define PRIx8  PRIx32
#    define PRIX8  PRIX32
#endif /* !defined(PRIU32) */
#if !defined (PRIu64)
#    if (SIZEOF_LONG >= 8)
#        define PRId64 "l" PRId32
#        define PRIi64 "l" PRIi32
#        define PRIo64 "l" PRIo32
#        define PRIu64 "l" PRIu32
#        define PRIx64 "l" PRIx32
#        define PRIX64 "l" PRIX32
#    else
#        define PRId64 "ll" PRId32
#        define PRIi64 "ll" PRIi32
#        define PRIo64 "ll" PRIo32
#        define PRIu64 "ll" PRIu32
#        define PRIx64 "ll" PRIx32
#        define PRIX64 "ll" PRIX32
#    endif /* if (SIZEOF_LONG >= 8) */
#endif     /* !defined(PRIu64) */

#include <glib.h>
#if GLIB_CHECK_VERSION(2, 6, 0)
#    include <glib/gstdio.h>
#else
#    define g_debug(...) g_log(G_LOG_DOMAIN,      \
                               G_LOG_LEVEL_DEBUG, \
                               __VA_ARGS__)
#endif /* if GLIB_CHECK_VERSION(2, 6, 0) */
#include <airdbc/airdbc.h>

/** @defgroup libipa libipa
 *
 * The IPA client library.
 *
 * libipa provides functions for querying and managing IP address data and
 * metadata in an IPA data store.  To use libipa, include <ipa/ipa.h> in your
 * application code, and link your application against the libipa shared
 * libraries.
 *
 * @section libipa_interface Interface
 *
 * @subsection libipa_context_sec The IPAContext
 *
 * Before you can communicate with the IPA data store, your application must
 * first create an IPAContext using ipa_create_context().  After this context
 * is created, you can invoke other methods.  Once your application is
 * finished talking to IPA, use ipa_destroy_context() to free resources
 * associated with the IPA transaction.
 *
 * @subsection libipa_transactions_sec Transactions
 *
 * IPA applications are responsible for transactional integrity.  IPA provides
 * methods for applications to @ref ipa_begin() "begin", @ref ipa_commit()
 * "commit", and @ref ipa_rollback() "rollback (abort)" transactions.
 *
 * @subsection libipa_import_sec Importing a Dataset
 *
 * To import data into IPA, call ipa_add_dataset() to create the empty
 * dataset,then call ipa_add_assoc() for every IP range association in that
 * dataset.  Once all associations are added, call ipa_commit() to complete
 * the transaction.
 *
 * @subsection libipa_export_sec Exporting a Dataset
 *
 * To export a single IPA dataset, call ipa_get_dataset() to load the
 * dataset into the IPAContext.  Then, call ipa_get_assoc() to retrieve each
 * association in the dataset.
 *
 * @subsection libipa_qeury_sec Advanced Queries
 *
 * Users who are familiar with the IPA data model may wish to execute custom
 * queries.  To do so, follow this example:
 *
 * @include libipa_advanced_query_example.c
 *
 * @{
 */

#define ENV_IPA_DB_URI "IPA_DB_URI"

#define IPA_CHECK_ERR( e, m, n )                                       \
    if (e != NULL) {                                                   \
        g_critical("%s: %s", m, (e && e->message) ? e->message : "" ); \
        g_clear_error(&e);                                             \
        return n;                                                      \
    }

/** The following error return values are defined for IPA: */
typedef enum _IPAStatus {
    IPA_OK = 0,       /**< No errors occurred */
    IPA_ERR_NOTFOUND, /**< A required resource was was not found */
    IPA_ERR_FILEIO,   /**< File input/output error */
    IPA_ERR_SQL,      /**< Error from the IPA relational database */
    IPA_ERR_INVALID,  /**< An invalid argument was given */
    IPA_ERR_UNKNOWN   /**< Unknown error */
} IPAStatus;

/** IPA catalogs hold one of the following types of data */
typedef enum _IPACatalogType
{
    IPA_CAT_NONE = 0, /**< Catalog hasn't been assigned a type yet */
    IPA_CAT_SET,      /**< Catalog contains IPset data */
    IPA_CAT_BAG,      /**< Catalog contains Bag data */
    IPA_CAT_PMAP,     /**< Catalog contains prefix map data */
    IPA_CAT_MMAP      /**< Catalog contains multimap data */
} IPACatalogType;


typedef enum _IPAContextState
{
    IPA_STATE_INITIAL = 0, /**< Context is ready */
    IPA_STATE_EXPORT,      /**< Export operation in progress */
    IPA_STATE_IMPORT,      /**< Import operation in progress */
    IPA_STATE_QUERY,       /**< Query operation in progresss */
    IPA_STATE_QUERY_DONE   /**< Query operation is complete */
} IPAContextState;

/**
 * IPA Context data structure.  This represents a handle to an IPA data store.
 */
typedef struct _IPAContext {
    IPAContextState  state;       /**< Keeps state of context operations */
    char            *db_uri;      /**< AirDBC URI of the IPA database */
    uint64_t         ds_id;       /**< The ID of the current dataset */
    AdbConnection   *conn;        /**< AirDBC connection object */
    AdbStatement    *stmt;        /**< AirDBC statement object */
    AdbResultSet    *rs;          /**< AirDBC result set object */
    GString         *sql;         /**< Holds SQL strings as they're invoked */
    IPACatalogType   cat_type;    /**< The type of the current IPA catalog */
    uint8_t          cat_width;   /**< Width of catalog field on output */
    uint8_t          range_width; /**< Width of range field on output */
    uint8_t          label_width; /**< Width of label field on output */
    uint8_t          value_width; /**< Width of value field on output */
    gboolean         verbose;     /**< Dump debug information*/
    uint8_t          displayfields;
    GScanner        *scanner;
    char            *uname;
} IPAContext;

#define IPA_ADDR_LEN  16
#define IPA_RANGE_LEN ((2 * IPA_ADDR_LEN) + 4)
#define IPA_LABEL_LEN 1024
#define IPA_VALUE_LEN 32
#define IPA_CAT_LEN   64

/* Constants for specifying which columns to return from a query */
#define IPA_COL_CATALOG 1
#define IPA_COL_START   2
#define IPA_COL_END     4
#define IPA_COL_RANGE   8
#define IPA_COL_LABEL   16
#define IPA_COL_VALUE   32
#define IPA_COL_ALL     63


/**
 * An IPA result record containing an IP address range, a label for that
 * range,and a scalar value associated with the range.  The latter two may be
 * irrelevant for some catalog types.
 */
typedef struct _IPAAssoc {
    char      range[IPA_RANGE_LEN]; /**< IP range as text */
    uint32_t  begin;                /**< First address in IP range */
    uint32_t  end;                  /**< Last address in IP range */
    char      label[IPA_LABEL_LEN]; /**< Textual label for IP range */
    char      value[IPA_VALUE_LEN]; /**< Scalar value associated with range */
    char      catalog[IPA_CAT_LEN]; /**< Catalog containing association **/
    char      t1[IPA_VALUE_LEN];    /**< begin timestamp */
    char      t2[IPA_VALUE_LEN];    /**< end timestamp */
} IPAAssoc;

typedef struct _IPAColumn {
    char     *label;      /**< Textual label for column header */
    int       width;      /**< With of column on output */
    gboolean  align_left; /**< If true, left-align the column */
    char     *val;        /**< Scratch buffer for field contents */
} IPAColumn;

/**
 * Create a handle to an IPA data store.
 *
 * @param ipa The address of an @ref IPAContext pointer.
 * @param db_uri The URI of an IPA data store.  URIs should be of the form
 * driver://username:password\@hostname/database
 * e.g.
 * postgresql://ipauser:secret\@dbserver/ipa
 * @param uname Username of the user in the IPA users table
 * @return IPA error status.
 */
int ipa_create_context(
    IPAContext **ipa,
    char        *db_uri,
    char        *uname);

/**
 * Destroy an IPA context that was created with @ref ipa_create_context().
 *
 * @param ipa The address of an @ref IPAContext pointer.
 * @return IPA error status.
 */
void ipa_destroy_context(
    IPAContext **ipa);


/**
 * Begin an IPA transaction.
 *
 * @param ipa A valid IPA context.
 */
void ipa_begin(
    IPAContext *ipa);

/**
 * Commit (complete) an IPA transaction.
 *
 * @param ipa A valid IPA context.
 */
void ipa_commit(
    IPAContext *ipa);

/**
 * Rollback (abort) an IPA transaction.
 *
 * @param ipa A valid IPA context.
 */
void ipa_rollback(
    IPAContext *ipa);

/**
 * Add a new IPA dataset to the database.
 *
 * @param ipa A valid IPA context.
 * @param catname The name of the catalog to add the new dataset to.
 * @param catdesc A short description of the catalog (for new catalogs)
 * @param type The type of the catalog as a @ref IPACatalogType value
 * @param begin Beginning of the validity date range for this dataset.
 * @param end End of the validity date range for this dataset.
 * @return IPA error status.
 */
int ipa_add_dataset(
    IPAContext    *ipa,
    const char    *catname,
    const char    *catdesc,
    IPACatalogType type,
    const char    *begin,
    const char    *end);

/**
 * Add an IP range to a dataset with an optional label and/or scalar value.
 *
 *
 * @param ipa   A valid IPA context.
 * @param addr1 The start address of the IP range.
 * @param addr2 The end address of the IP range.
 * @param label The name of the label to assign to the IP range.
 *              For IPA_CAT_SET and IPA_CAT_BAG catalog types, this parameter
 *              is ignored.
 * @param value The scalar value to assign to the labeled range.
 * @return      IPA error status.
 */
int ipa_add_assoc(
    IPAContext *ipa,
    uint32_t    addr1,
    uint32_t    addr2,
    char       *label,
    uint64_t    value);

/**
 * Convenience function for adding CIDRized IP ranges.
 *
 * @param ipa A valid IPA context.
 * @param addr The start address of the block.
 * @param prefix The number of prefix bits.
 * @param label The name of the label to assign to the IP range.
 * @param value The scalar value to assign to the labeled range.
 * @return IPA error status.
 */
int ipa_add_cidr(
    IPAContext *ipa,
    uint32_t    addr,
    uint32_t    prefix,
    char       *label,
    uint64_t    value);


/**
 * Retrieve a dataset record.
 *
 * @param ipa A valid IPA context.
 * @param catalog_name The name of the catalog to retrieve from
 * @param dataset_time A time string to select datasets active at a specific
 * time
 * @return IPA error status.
 */
int ipa_get_dataset(
    IPAContext *ipa,
    const char *catalog_name,
    const char *dataset_time);

/**
 * Retrieve the next range in an open dataset.
 *
 * @param ipa       A valid IPA context.
 * @param assoc     (out) IPAAssoc record of the next range in the dataset.
 * @return          IPA error status.
 */
int ipa_get_assoc(
    IPAContext *ipa,
    IPAAssoc   *assoc);

int ipa_get_next_assoc(
   IPAContext *ipa,
   IPAAssoc   *assoc);
    

/**
 * Get associations matching all of the supplied parameters
 *
 * @param ipa       A valid IPA context.
 * @param catalog   Catalog name
 * @param range     IP range
 * @param label     Comma-delimited list of one or more labels
 * @param value     A number or number range in the form of x-y
 * @param t1        Begin date
 * @param t2        End date
 * @param displayfields  Bitmask of columns to return from query
 * @return          IPA error status.
 */
int ipa_do_assoc_query(
    IPAContext *ipa,
    const char *catalog,
    const char *range,
    const char *label,
    const char *value,
    const char *t1,
    const char *t2,
    int displayfields
    );

/**
 * @{
 * @internal
 */
typedef enum _IPAOrderBy {
    IPA_ORDER_DEFAULT = 0,
    IPA_ORDER_CTIME,
    IPA_ORDER_MTIME
} IPAOrderBy;

uint32_t ipa_mask_from_prefix(
    uint32_t pfx);

/** @} */

/** @} End defgroup libipa_api */


typedef enum _IPAQuerySymbol {
    /* Query operations */
    IPAQUERY_CATLIST = G_TOKEN_LAST + 1,
    IPAQUERY_SETLIST,
    IPAQUERY_FIND,
    IPAQUERY_NONE,
    /* Attribute query keywords */
    IPAQUERY_IN,
    IPAQUERY_ONLY,
    IPAQUERY_ADDR,
    IPAQUERY_LABEL,
    IPAQUERY_VALUE,
    IPAQUERY_AT,
    IPAQUERY_BEFORE,
    IPAQUERY_AFTER,
    IPAQUERY_BETWEEN,
    IPAQUERY_AND,
    IPAQUERY_SHOW
} IPAQuerySymbol;

/* symbol arrays */
typedef const struct _symbol_table {
    gchar *symbol_name;
    guint  symbol_token;
} symbol_table_t;

static symbol_table_t
symbols_main[] = {
    { "catlist", IPAQUERY_CATLIST },
    { "setlist", IPAQUERY_SETLIST },
    { "find",    IPAQUERY_FIND    },
    { NULL,                     0 }
},
*symbols_main_p = symbols_main,
symbols_find[]  = {
    { "in",      IPAQUERY_IN      },
    { "only",    IPAQUERY_ONLY    },
    { "addr",    IPAQUERY_ADDR    },
    { "label",   IPAQUERY_LABEL   },
    { "value",   IPAQUERY_VALUE   },
    /* Time range constraints */
    { "at",      IPAQUERY_AT      },
    { "before",  IPAQUERY_BEFORE  },
    { "after",   IPAQUERY_AFTER   },
    { "between", IPAQUERY_BETWEEN },
    { "and",     IPAQUERY_AND     },
    /* "display" shows a subset of columns in the output */
    { "show", IPAQUERY_SHOW },
    { NULL,                     0 }
}, *symbols_find_p = symbols_find,
symbols_none[]     = {
    { NULL, 0 }
}, *symbols_none_p = symbols_none;


#define IPA_ADD_COLUMN( A, l, w, a )       \
    {                                      \
    if (A) {                               \
        IPAColumn col = { l, w, a, NULL }; \
        g_array_append_val(A, col);        \
    }                                      \
    }

int ipa_parse_query(
    IPAContext *ipa,
        char *query
);

gboolean ipa_scan_addr(
    GScanner *scanner,
    uint32_t *addr);

gboolean ipa_scan_range(
    GScanner *scanner,
    uint32_t *a,
    uint32_t *b);

/* FIXME:  In the library? */
gboolean ipa_ntop(
    int      family,
    uint32_t addr,
    GString *str);


#endif /* ifndef _IPA_IPA_H_ */


