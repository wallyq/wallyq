SET search_path TO ipa, public;

CREATE LANGUAGE 'plpgsql';
CREATE LANGUAGE 'plperlu';

CREATE OR REPLACE FUNCTION update_assoc_count_perl()
RETURNS TRIGGER
LANGUAGE plperlu
AS $_$
  use strict;
  my $event = $_TD->{event};
  my ($oldid,$newid) = ($_TD->{old}{dataset_id},$_TD->{new}{dataset_id});
  if ($event eq 'INSERT') {
    $_SHARED{assoc_count}{$newid}++;
  }
  elsif ($event eq 'DELETE') {
    $_SHARED{assoc_count}{$oldid}--;
    $_SHARED{assoc_count}{$oldid}||=-1;
  }
  elsif ($oldid ne $newid) {
    $_SHARED{assoc_count}{$oldid}--;
    $_SHARED{assoc_count}{$oldid}||=-1;
    $_SHARED{assoc_count}{$newid}++;
  }
  return;
$_$;

CREATE OR REPLACE FUNCTION get_assoc_count(int)
RETURNS INTEGER
LANGUAGE plperlu
AS $_$
  my $id = shift;
  return $_SHARED{assoc_count}{$id} || 0;
$_$;

CREATE OR REPLACE FUNCTION start_bulkload_assoc_count()
RETURNS TEXT
LANGUAGE plperlu
AS $_$
  spi_exec_query("ALTER TABLE assoc_set DISABLE TRIGGER assoc_update_assoc_count");
  spi_exec_query("ALTER TABLE assoc_bag DISABLE TRIGGER assoc_update_assoc_count");
  spi_exec_query("ALTER TABLE assoc_pmap DISABLE TRIGGER assoc_update_assoc_count");
  spi_exec_query("ALTER TABLE assoc_mmap DISABLE TRIGGER assoc_update_assoc_count");
  spi_exec_query("ALTER TABLE assoc_set ENABLE TRIGGER update_assoc_count_perl");
  spi_exec_query("ALTER TABLE assoc_bag ENABLE TRIGGER update_assoc_count_perl");
  spi_exec_query("ALTER TABLE assoc_pmap ENABLE TRIGGER update_assoc_count_perl");
  spi_exec_query("ALTER TABLE assoc_mmap ENABLE TRIGGER update_assoc_count_perl");
  return 'Ready to bulkload';
$_$;

CREATE OR REPLACE FUNCTION end_bulkload_assoc_count()
RETURNS TEXT
LANGUAGE plperlu
AS $_$
  my $sth = spi_prepare(
    'UPDATE dataset SET assoc_count = assoc_count + $1 WHERE dataset_id = $2',
    'int4', 'int4');
  for my $id (keys %{$_SHARED{assoc_count}}) {
    my $val = $_SHARED{assoc_count}{$id};
    spi_exec_prepared($sth,$val,$id);
  }

  my $sth = spi_prepare(
    'UPDATE dataset SET ip_count = (SELECT SUM(ip4r_size(a.range)) from assoc a WHERE dataset_id=$1) WHERE dataset_id = $1',
    'int4');
  for my $id (keys %{$_SHARED{assoc_count}}) {
    spi_exec_prepared($sth,$id);
  }

  undef $_SHARED{assoc_count};

  spi_exec_query("ALTER TABLE assoc_set ENABLE TRIGGER assoc_update_assoc_count"); ## x3 etc.
  spi_exec_query("ALTER TABLE assoc_bag ENABLE TRIGGER assoc_update_assoc_count"); ## x3 etc.
  spi_exec_query("ALTER TABLE assoc_pmap ENABLE TRIGGER assoc_update_assoc_count"); ## x3 etc.
  spi_exec_query("ALTER TABLE assoc_mmap ENABLE TRIGGER assoc_update_assoc_count"); ## x3 etc.
  spi_exec_query("ALTER TABLE assoc_set DISABLE TRIGGER update_assoc_count_perl");
  spi_exec_query("ALTER TABLE assoc_bag DISABLE TRIGGER update_assoc_count_perl");
  spi_exec_query("ALTER TABLE assoc_pmap DISABLE TRIGGER update_assoc_count_perl");
  spi_exec_query("ALTER TABLE assoc_mmap DISABLE TRIGGER update_assoc_count_perl");
  return 'Bulk load complete';
$_$;
