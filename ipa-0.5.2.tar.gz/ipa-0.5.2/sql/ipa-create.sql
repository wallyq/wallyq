CREATE DATABASE ipa;

\c ipa

CREATE ROLE g_ipa_admin NOLOGIN CREATEROLE;
GRANT ALL PRIVILEGES ON DATABASE ipa TO g_ipa_admin;

CREATE ROLE g_ipa_auditor NOLOGIN;
CREATE ROLE g_ipa_user NOLOGIN;

CREATE USER ipa WITH PASSWORD 'ipa' INHERIT CREATEROLE IN ROLE g_ipa_admin;
GRANT SELECT ON pg_catalog.pg_authid TO ipa;
ALTER DATABASE ipa OWNER to ipa;

GRANT g_ipa_user TO g_ipa_auditor WITH ADMIN OPTION;
GRANT g_ipa_auditor TO g_ipa_admin WITH ADMIN OPTION;

CREATE SCHEMA ipa;
ALTER DATABASE ipa SET search_path TO ipa,public;

ALTER SCHEMA ipa OWNER TO ipa;

GRANT ALL PRIVILEGES ON SCHEMA ipa TO g_ipa_admin;
GRANT USAGE ON SCHEMA ipa TO g_ipa_user;

