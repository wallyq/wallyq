--
-- IPA database schema (PostgreSQL)
--
-- Authors: Tony Cebzanov  <tonyc@cert.org>
--
-- This is the canonical version of the IPA database schema.
-- All changes to the database schema MUST be reflected in this file.
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.


SET search_path TO ipa, public;

ALTER DEFAULT PRIVILEGES IN SCHEMA ipa REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES IN SCHEMA ipa GRANT ALL ON TABLES TO g_ipa_admin WITH GRANT OPTION;
ALTER DEFAULT PRIVILEGES IN SCHEMA ipa GRANT SELECT ON TABLES TO g_ipa_user;

ALTER DEFAULT PRIVILEGES IN SCHEMA ipa REVOKE ALL ON SEQUENCES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES IN SCHEMA ipa GRANT ALL ON SEQUENCES TO g_ipa_admin WITH GRANT OPTION;
ALTER DEFAULT PRIVILEGES IN SCHEMA ipa GRANT USAGE, SELECT ON SEQUENCES TO g_ipa_user;

ALTER DEFAULT PRIVILEGES IN SCHEMA ipa REVOKE ALL ON FUNCTIONS FROM PUBLIC;
ALTER DEFAULT PRIVILEGES IN SCHEMA ipa GRANT ALL ON FUNCTIONS TO g_ipa_admin WITH GRANT OPTION;
ALTER DEFAULT PRIVILEGES IN SCHEMA ipa GRANT EXECUTE ON FUNCTIONS TO g_ipa_user;

-- TABLES AND VIEWS -----------------------------------------------------------


-- users table -----------------------------------------------------------
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    displayname TEXT NOT NULL
);

CREATE INDEX users_name_idx on users (username);

GRANT INSERT, UPDATE, DELETE ON users TO g_ipa_admin;


-- catalog table ---------------------------------------------------------
CREATE TABLE catalog(
    catalog_id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    type INTEGER NOT NULL,
    creator_uid INTEGER NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
    description TEXT NULL,
    "ctime" TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now(),
    "mtime" TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX catalog_name_idx ON catalog ((lower(name)));
CREATE INDEX catalog_type_idx ON catalog(type);

GRANT INSERT, UPDATE ON catalog TO g_ipa_user;

-- catalog_edge table -----------------------------------------------
CREATE TABLE catalog_edge(
       id SERIAL PRIMARY KEY,
       child INTEGER NOT NULL REFERENCES catalog (catalog_id) ON DELETE CASCADE DEFERRABLE,
       parent INTEGER,
       UNIQUE (child, parent),
       CHECK (child <> parent)
);

GRANT INSERT, UPDATE ON catalog_edge TO g_ipa_user;


-- Trigger function for avoiding cycles in catalog hierarchy
CREATE OR REPLACE FUNCTION check_edge_cycle() RETURNS trigger AS $$
DECLARE
    dupes INTEGER;
    cycles INTEGER;
BEGIN
    -- Cycle detection isn't safe against concurrent insertions, so
    -- we'll have to lock the table here.  Luckily, this is a relatively
    -- infrequent operation.  If "FOR UPDATE" is ever implemented for
    -- recursive queries (it's not as of v8.4.2) we should try that here
    -- instead of locking the table.
    LOCK TABLE catalog_edge IN EXCLUSIVE MODE;

    -- Check the tree for any cycles.
    WITH RECURSIVE search_graph(parent, child, id, depth, path, cycle) AS (
         SELECT NEW.parent, NEW.child, NEW.id, 1,
          ARRAY[NEW.id], false
          UNION ALL
            SELECT g.parent, g.child, g.id, sg.depth + 1,
          path || g.id,
          g.id = ANY(path)
            FROM catalog_edge g, search_graph sg
            WHERE g.parent = sg.child AND NOT cycle
    )
    SELECT INTO cycles COUNT(*) FROM search_graph WHERE cycle;
    IF cycles > 0 THEN
       RAISE EXCEPTION 'Linking these two catalogs would create a cycle.';
    END IF;

    SELECT INTO dupes SUM(d.duplicates) FROM (SELECT COUNT(*) AS duplicates
        FROM catalog_tree GROUP BY path HAVING COUNT(*) > 1) AS d;

    IF dupes > 0 THEN
       RAISE EXCEPTION 'Duplicate path.';
    END IF;

    RETURN NEW;
END
$$ LANGUAGE plpgsql;

CREATE TRIGGER catalog_edge_prevent_cycles AFTER INSERT ON catalog_edge
    FOR EACH ROW EXECUTE PROCEDURE check_edge_cycle();

-- catalog_tree view -----------------------------------------------
CREATE OR REPLACE VIEW catalog_tree AS
    WITH RECURSIVE x(level, parent, child, name, path) AS
    (SELECT 1::integer, e.parent, e.child, c.name, array[c.name]
    FROM (catalog_edge e JOIN catalog c ON e.child=c.catalog_id)
    WHERE parent IS NULL

    UNION ALL

    SELECT x.level + 1, base.parent, base.child, base.name,
        array_append(path, base.name)
    FROM (catalog_edge e JOIN catalog c ON e.child=c.catalog_id) AS base, x
    WHERE base.parent = x.child)
SELECT array_to_string(path, '.') AS path, name, parent, child,
    level AS depth
FROM x
ORDER BY path;

-- catalog_view view -----------------------------------------------
CREATE OR REPLACE VIEW catalog_view AS
SELECT ct.path AS catalog_path, ct.depth, ct.parent, c.catalog_id, c.name,
    c.type AS catalog_type, c.creator_uid AS catalog_uid, c.description,
    c.ctime, c.mtime, ( SELECT count(*) AS count
    FROM catalog_tree ct1
    WHERE ct1.parent = ct.child ) AS childcount
FROM catalog_tree ct
    JOIN catalog c ON ct.child = c.catalog_id
ORDER BY ct.path;

-- dataset table -----------------------------------------------------
CREATE TABLE dataset(
    dataset_id SERIAL PRIMARY KEY,
    catalog_id INTEGER NOT NULL REFERENCES catalog (catalog_id)
    ON DELETE CASCADE,
    t_begin TIMESTAMP WITHOUT TIME ZONE NULL,
    t_end TIMESTAMP WITHOUT TIME ZONE NULL,
    creator_uid INTEGER NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
    "ctime" TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now(),
    "mtime" TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now(),
    "assoc_count" BIGINT NOT NULL DEFAULT 0,
    "ip_count" BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX dataset_catalog_id_idx ON dataset (catalog_id);
CREATE INDEX dataset_time_idx ON dataset USING btree (t_begin, t_end);

GRANT INSERT, UPDATE, DELETE ON dataset TO g_ipa_user;

-- dataset_view view -------------------------------------------------
CREATE OR REPLACE VIEW dataset_view AS
SELECT DISTINCT d.dataset_id,
    (cv.catalog_path || '/'::text) || d.dataset_id AS dataset_path,
    cv.catalog_id, cv.catalog_path, cv.catalog_type, cv.catalog_uid,
    d.t_begin, d.t_end, d.creator_uid AS dataset_uid, d.ctime, d.mtime,
    d.assoc_count, d.ip_count
FROM dataset d JOIN catalog_view cv ON d.catalog_id = cv.catalog_id;

-- label table ------------------------------------------------------
CREATE TABLE label(
    label_id SERIAL,
    catalog_id INTEGER NOT NULL REFERENCES catalog (catalog_id)
    ON DELETE CASCADE,
    name TEXT NULL,
    PRIMARY KEY (label_id)
);
CREATE INDEX label_catalog_name_idx ON label (catalog_id, name);

GRANT INSERT, UPDATE, DELETE ON label TO g_ipa_user;

-- assoc tables -----------------------------------------------------

CREATE TABLE assoc (
    dataset_id INTEGER NOT NULL REFERENCES dataset (dataset_id)
    ON DELETE CASCADE,
    range ip4r NOT NULL,
    label_id INTEGER NULL,
    value BIGINT NULL,
    creator_uid INTEGER NOT NULL REFERENCES users (id) ON DELETE RESTRICT
);

GRANT INSERT, UPDATE, DELETE ON assoc TO g_ipa_user;

CREATE TABLE assoc_set (
    PRIMARY KEY (dataset_id, range),
    FOREIGN KEY (dataset_id) REFERENCES dataset (dataset_id) ON DELETE CASCADE,
    FOREIGN KEY (creator_uid) REFERENCES users (id) ON DELETE RESTRICT
) INHERITS (assoc);
CREATE INDEX assoc_set_range_idx ON assoc_set USING gist (range);

GRANT INSERT, UPDATE, DELETE ON assoc_set TO g_ipa_user;

CREATE TABLE assoc_bag (
    PRIMARY KEY (dataset_id, range),
    FOREIGN KEY (dataset_id) REFERENCES dataset (dataset_id) ON DELETE CASCADE,
    FOREIGN KEY (creator_uid) REFERENCES users (id) ON DELETE RESTRICT
) INHERITS (assoc);
CREATE INDEX assoc_bag_range_idx ON assoc_bag USING gist (range);
CREATE INDEX assoc_bag_dataset_idx ON assoc_bag (dataset_id);
CREATE INDEX assoc_bag_value_idx ON assoc_bag (value);

GRANT INSERT, UPDATE, DELETE ON assoc_bag TO g_ipa_user;

CREATE TABLE assoc_pmap (
    PRIMARY KEY (dataset_id, range),
    FOREIGN KEY (dataset_id) REFERENCES dataset (dataset_id) ON DELETE CASCADE,
    FOREIGN KEY (label_id) REFERENCES label (label_id) ON DELETE CASCADE,
    FOREIGN KEY (creator_uid) REFERENCES users (id) ON DELETE RESTRICT
) INHERITS (assoc);
CREATE INDEX assoc_pmap_range_idx ON assoc_pmap USING gist (range);
CREATE INDEX assoc_pmap_dataset_idx ON assoc_pmap (dataset_id);
CREATE INDEX assoc_pmap_label_idx ON assoc_pmap (label_id);

GRANT INSERT, UPDATE, DELETE ON assoc_pmap TO g_ipa_user;

CREATE TABLE assoc_mmap (
    PRIMARY KEY (dataset_id, range, label_id),
    FOREIGN KEY (dataset_id) REFERENCES dataset (dataset_id) ON DELETE CASCADE,
    FOREIGN KEY (label_id) REFERENCES label (label_id) ON DELETE CASCADE,
    FOREIGN KEY (creator_uid) REFERENCES users (id) ON DELETE RESTRICT
) INHERITS (assoc);
CREATE INDEX assoc_mmap_range_idx ON assoc_mmap USING gist (range);
CREATE INDEX assoc_mmap_dataset_idx on assoc_mmap (dataset_id);
CREATE INDEX assoc_mmap_label_idx on assoc_mmap (label_id);
CREATE INDEX assoc_mmap_value_idx on assoc_mmap (value);

GRANT INSERT, UPDATE, DELETE ON assoc_mmap TO g_ipa_user;

CREATE TABLE note (
    id SERIAL PRIMARY KEY,
    creator_uid INTEGER REFERENCES users (id) ON DELETE RESTRICT,
    range IP4R NOT NULL,
    contents TEXT,
    tsv tsvector,
    "ctime" TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT now(),
    FOREIGN KEY (creator_uid) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX note_range_idx ON note USING gist (range);
CREATE INDEX note_contents_idx ON note USING gin(tsv);
CREATE TRIGGER tsvectorupdate BEFORE INSERT OR UPDATE
    ON note FOR EACH ROW EXECUTE PROCEDURE
    tsvector_update_trigger(tsv, 'pg_catalog.english', contents);

GRANT INSERT, UPDATE, DELETE ON note TO g_ipa_user;

-- rules to force all inserts into child tables
CREATE RULE insert_default AS
    ON INSERT TO assoc
    DO INSTEAD NOTHING;

CREATE OR REPLACE RULE insert_set AS ON INSERT TO assoc
    WHERE new.label_id IS NULL AND new.value IS NULL
    DO INSTEAD INSERT INTO assoc_set (dataset_id, range, creator_uid)
        VALUES (new.dataset_id, new.range, new.creator_uid);

CREATE OR REPLACE RULE insert_bag AS ON INSERT TO assoc
    WHERE new.label_id IS NULL AND new.value IS NOT NULL
    DO INSTEAD INSERT INTO assoc_bag (dataset_id, range, value, creator_uid)
        VALUES (new.dataset_id, new.range, new.value, new.creator_uid);

CREATE OR REPLACE RULE insert_pmap AS ON INSERT TO assoc
    WHERE new.label_id IS NOT NULL AND new.value IS NULL
    DO INSTEAD INSERT INTO assoc_pmap (dataset_id, range, label_id, creator_uid)
        VALUES (new.dataset_id, new.range, new.label_id, new.creator_uid);

CREATE OR REPLACE RULE insert_mmap AS ON INSERT TO assoc
WHERE new.label_id IS NOT NULL AND new.value IS NOT NULL
    DO INSTEAD INSERT INTO assoc_mmap (dataset_id, range, label_id, value,
        creator_uid)
    VALUES (new.dataset_id, new.range, new.label_id, new.value, new.creator_uid);



-- STORED PROCEDURES --------------------------------------------------------

-- set_timestamp() --------------------------------------------------
CREATE FUNCTION set_timestamp() RETURNS TRIGGER AS $set_timestamp$
BEGIN
NEW.mtime := now();
RETURN NEW;
END;
$set_timestamp$
LANGUAGE 'plpgsql';

-- update_assoc_count () --------------------------------------------

CREATE OR REPLACE FUNCTION update_assoc_count()
RETURNS TRIGGER AS
'
   BEGIN
      IF TG_OP = ''INSERT'' THEN
         UPDATE dataset
            SET assoc_count = assoc_count + 1
            WHERE dataset_id = NEW.dataset_id;
         UPDATE dataset
            SET ip_count = ip_count + ip4r_size(NEW.range)
            WHERE dataset_id = NEW.dataset_id;
      ELSIF TG_OP = ''UPDATE'' THEN
         UPDATE dataset
            SET assoc_count = assoc_count - 1
            WHERE dataset_id = OLD.dataset_id;
         UPDATE dataset
            SET ip_count = ip_count - ip4r_size(OLD.range)
            WHERE dataset_id = OLD.dataset_id;
         UPDATE dataset
            SET assoc_count = assoc_count + 1
            WHERE dataset_id = NEW.dataset_id;
         UPDATE dataset
            SET ip_count = ip_count + ip4r_size(NEW.range)
            WHERE dataset_id = NEW.dataset_id;
      ELSIF TG_OP = ''DELETE'' THEN
         UPDATE dataset
            SET assoc_count = assoc_count - 1
            WHERE dataset_id = OLD.dataset_id;
         UPDATE dataset
            SET ip_count = ip_count - ip4r_size(OLD.range)
            WHERE dataset_id = OLD.dataset_id;
      END IF;
      RETURN NEW;
   END;
' LANGUAGE plpgsql;


CREATE TRIGGER assoc_update_assoc_count
    AFTER INSERT OR UPDATE OR DELETE ON assoc_set
    FOR EACH ROW EXECUTE PROCEDURE update_assoc_count();
CREATE TRIGGER assoc_update_assoc_count
    AFTER INSERT OR UPDATE OR DELETE ON assoc_bag
    FOR EACH ROW EXECUTE PROCEDURE update_assoc_count();
CREATE TRIGGER assoc_update_assoc_count
    AFTER INSERT OR UPDATE OR DELETE ON assoc_pmap
    FOR EACH ROW EXECUTE PROCEDURE update_assoc_count();
CREATE TRIGGER assoc_update_assoc_count
    AFTER INSERT OR UPDATE OR DELETE ON assoc_mmap
    FOR EACH ROW EXECUTE PROCEDURE update_assoc_count();

CREATE TRIGGER update_assoc_count_perl
  AFTER INSERT OR UPDATE OR DELETE ON assoc_set
  FOR EACH ROW EXECUTE PROCEDURE update_assoc_count_perl();
CREATE TRIGGER update_assoc_count_perl
  AFTER INSERT OR UPDATE OR DELETE ON assoc_bag
  FOR EACH ROW EXECUTE PROCEDURE update_assoc_count_perl();
CREATE TRIGGER update_assoc_count_perl
  AFTER INSERT OR UPDATE OR DELETE ON assoc_pmap
  FOR EACH ROW EXECUTE PROCEDURE update_assoc_count_perl();
CREATE TRIGGER update_assoc_count_perl
  AFTER INSERT OR UPDATE OR DELETE ON assoc_mmap
  FOR EACH ROW EXECUTE PROCEDURE update_assoc_count_perl();




-- get_associations
CREATE OR REPLACE FUNCTION get_associations(
       IN i_catids INTEGER[],
       IN i_dsids INTEGER[],
       IN i_findpaths TEXT[],
       IN i_t_begin TIMESTAMP WITHOUT TIME ZONE,
       IN i_t_end TIMESTAMP WITHOUT TIME ZONE,
       IN i_range IP4R,
       IN i_label TEXT,
       IN i_limit INTEGER DEFAULT NULL,
       IN i_offset INTEGER DEFAULT 0,
       OUT o_catalog TEXT,
       OUT o_t_begin TIMESTAMP WITHOUT TIME ZONE,
       OUT o_t_end TIMESTAMP WITHOUT TIME ZONE,
       OUT o_range IP4R,
       OUT o_begin IP4,
       OUT o_end IP4,
       OUT o_label TEXT,
       OUT o_value BIGINT)
    RETURNS SETOF RECORD AS $$
DECLARE
    t_begin TIMESTAMP WITHOUT TIME ZONE;
    t_end TIMESTAMP WITHOUT TIME ZONE;
    query TEXT;
BEGIN
FOR o_catalog, o_t_begin, o_t_end, o_range, o_begin, o_end, o_label, o_value IN
    SELECT d.o_catalog_path, d.o_t_begin, d.o_t_end, a.range,
        lower(a.range), upper(a.range), l.name, a.value
    FROM assoc a LEFT JOIN label l ON a.label_id = l.label_id
        JOIN get_datasets(i_catids, i_dsids, i_findpaths, i_t_begin, i_t_end) d
        ON a.dataset_id=d.o_dataset_id
    WHERE
        CASE WHEN i_range IS NULL THEN TRUE ELSE a.range <<= i_range END
        AND CASE WHEN i_label IS NULL THEN TRUE ELSE l.name = i_label END
    LIMIT i_limit
    OFFSET i_offset
    LOOP
        RETURN NEXT;
    END LOOP;
    RETURN;
END;
$$
LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION userid_from_username(IN i_uname TEXT)
RETURNS INTEGER AS $$
DECLARE
    user_id INTEGER;
BEGIN
    SELECT INTO user_id id FROM users where username=i_uname;
    IF user_id IS NULL THEN
        RAISE EXCEPTION 'User % not found in IPA user table', i_uname;
    END IF;
    RETURN user_id;
END
$$
LANGUAGE plpgsql;




CREATE OR REPLACE FUNCTION parse_catalog_path(
    IN cat_name TEXT,
    OUT parent_id INTEGER,
    OUT parent_name TEXT,
    OUT child_id INTEGER,
    OUT child_name TEXT) AS $$
BEGIN
    SELECT INTO parent_name, child_name
        array_to_string(name[1:array_upper(name, 1)-1], '.'),
        name[array_upper(name,1)]
    FROM regexp_split_to_array(cat_name, E'\\.') AS name;

    IF parent_name = '' THEN
        SELECT INTO parent_name NULL;
    END IF;

    SELECT INTO parent_id catalog_id
    FROM catalog_view
    WHERE catalog_path = parent_name;

    SELECT INTO child_id catalog_id
    FROM catalog_view
    WHERE catalog_path = (parent_name || '.' || child_name);

    RETURN;
END
$$
LANGUAGE plpgsql;




CREATE OR REPLACE FUNCTION add_catalog(
    IN cat_name TEXT,
    IN cat_type INTEGER,
    IN cat_desc TEXT,
    IN uname TEXT)
    RETURNS INTEGER AS $$
DECLARE
    parent_id INTEGER;
    child_id INTEGER;
    parent_name TEXT;
    child_name TEXT;
    user_id INTEGER;
BEGIN

    SELECT INTO parent_id, parent_name, child_id, child_name
        * FROM parse_catalog_path(cat_name);

    IF child_id IS NOT NULL THEN
            RAISE EXCEPTION 'Catalog % already exists.', cat_name;
    END IF;

    IF parent_name IS NOT NULL AND parent_id IS NULL THEN
            RAISE EXCEPTION 'Parent catalog % does not exist.', parent_name;
    END IF;

    SELECT INTO user_id userid_from_username(uname);
    -- RAISE NOTICE 'add_catalog: %, %, %, %', parent_name, child_name, parent_id, child_id;

    INSERT INTO catalog (name, type, description, creator_uid)
        VALUES (child_name,
            CASE WHEN cat_type IS NOT NULL
            THEN cat_type
            ELSE (SELECT type FROM catalog WHERE catalog_id=parent_id) END,
            cat_desc, user_id);
    SELECT INTO child_id currval('catalog_catalog_id_seq');
    -- RAISE NOTICE 'add_catalog: %, %', parent_id, child_id;
    INSERT INTO catalog_edge (child, parent) VALUES (child_id, parent_id);
    RETURN child_id;
END
$$
LANGUAGE plpgsql;

-- new add_dataset to handle additions at the proper tree level
CREATE OR REPLACE FUNCTION add_dataset(
    IN cname TEXT,
    IN ctype INTEGER,
    IN cdesc TEXT,
    IN begin_time TEXT,
    IN end_time TEXT,
    IN uname TEXT)
    RETURNS INTEGER AS $$
DECLARE
    ds_id INTEGER;
    parent_name TEXT;
    child_name TEXT;
    parent_id INTEGER;
    child_id INTEGER;
BEGIN
    SELECT INTO parent_id, parent_name, child_id, child_name
        * FROM parse_catalog_path(cname);

    IF parent_id IS NULL AND cname ~* E'\\.' THEN
            RAISE EXCEPTION 'Parent catalog % was not found.', parent_name;
    ELSE
        IF child_id IS NULL THEN
            SELECT INTO child_id
                add_catalog(cname, ctype, cdesc, uname);
        END IF;
    END IF;
    -- RAISE NOTICE 'add_dataset: %, %, %, %', parent_name, child_name, parent_id, child_id;

    SELECT INTO ds_id add_dataset(child_id, begin_time, end_time, uname);
    RETURN ds_id;
END
$$
LANGUAGE plpgsql;

-- add_dataset() ----------------------------------------------------
CREATE OR REPLACE FUNCTION add_dataset(
    IN cat_id INTEGER,
    IN begin_time TEXT,
    IN end_time TEXT,
    IN uname TEXT)
    RETURNS INTEGER AS $$
DECLARE
    cat_id ALIAS FOR $1;
    begin_timestamp TIMESTAMP WITHOUT TIME ZONE;
    end_timestamp TIMESTAMP WITHOUT TIME ZONE;
    ds_id INTEGER;
    setcount INTEGER;
    catalog_type TEXT;
    user_id INTEGER;
BEGIN
    SELECT INTO user_id userid_from_username(uname);

    IF begin_time IS NULL AND end_time IS NULL THEN
        RAISE EXCEPTION 'A valid begin/end time must be supplied';
    END IF;

    IF begin_time = '...' THEN
        SELECT '-infinity'::timestamp into begin_timestamp;
    ELSE
        SELECT begin_time::timestamp into begin_timestamp;
    END IF;

    IF end_time = '...' THEN
        SELECT 'infinity'::timestamp into end_timestamp;
    ELSE
        SELECT end_time::timestamp into end_timestamp;
    END IF;

    IF begin_timestamp = end_timestamp THEN
        RAISE EXCEPTION 'Begin and end times must not be equal.';
    END IF;

    -- Ensure time range does not overlap
    SELECT INTO setcount COUNT(*) FROM dataset d
        WHERE catalog_id = cat_id
        AND (begin_timestamp, end_timestamp) OVERLAPS (d.t_begin, d.t_end);

    IF setcount > 0 THEN
        RAISE EXCEPTION
        'The specified date range overlaps with another dataset in the catalog';
    END IF;

    -- No we can go ahead and insert the dataset record.
    INSERT INTO dataset (catalog_id, t_begin, t_end, creator_uid)
        VALUES (cat_id, begin_timestamp, end_timestamp, user_id);
    SELECT INTO ds_id currval('dataset_dataset_id_seq');
    -- If all that worked, update the catalog's mtime
    UPDATE catalog SET mtime=now() WHERE catalog_id=cat_id;
    RETURN ds_id;
END
$$
LANGUAGE plpgsql;


-- add_label() ------------------------------------------------------
CREATE OR REPLACE FUNCTION add_label(INTEGER, VARCHAR)
    RETURNS INTEGER AS $add_label$
DECLARE
    cat_id ALIAS FOR $1;
    label_name ALIAS FOR $2;
    label_id_new INTEGER;
BEGIN
    SELECT INTO label_id_new label_id
        FROM label
        WHERE catalog_id = cat_id
        AND name = label_name;
    IF label_id_new IS NULL THEN
        SELECT INTO label_id_new nextval('label_label_id_seq');
        INSERT INTO label(label_id, catalog_id, name)
            VALUES (label_id_new, cat_id, label_name);
    END IF;
    RETURN label_id_new;
END
$add_label$
LANGUAGE plpgsql;


-- add_assoc() ------------------------------------------------
CREATE OR REPLACE FUNCTION add_assoc(
    IN i_dsid INTEGER,
    IN i_addr1 IP4,
    IN i_addr2 IP4,
    IN i_label TEXT,
    IN i_value BIGINT,
    IN i_uname TEXT)
    RETURNS INTEGER AS $$
DECLARE
    cat_id INTEGER = NULL;
    lid INTEGER;
    user_id INTEGER;
    allow_dupes BOOLEAN = TRUE;
BEGIN
    SELECT INTO user_id userid_from_username(i_uname);

    if i_label IS NOT NULL THEN
        -- Get the catalog ID for this dataset
        SELECT INTO cat_id catalog_id
        FROM dataset
        WHERE dataset_id=i_dsid;

        SELECT INTO lid add_label(cat_id, i_label);
    END IF;
    -- Add the range to the catalog
    INSERT INTO assoc (dataset_id, range, label_id, value, creator_uid)
        VALUES (i_dsid, ip4r(i_addr1, i_addr2), lid, i_value, user_id);
    RETURN 0;
END
$$
LANGUAGE plpgsql;


-- add_note() ------------------------------------------------
CREATE OR REPLACE FUNCTION add_note(
    IN i_range IP4R,
    IN i_contents TEXT,
    IN i_uname TEXT
) RETURNS BOOLEAN AS $$
DECLARE
    user_id INTEGER;
BEGIN
    IF i_range IS NULL OR i_contents IS NULL or i_uname IS NULL THEN
        RAISE EXCEPTION 'Invalid arguments to add_note';
    END IF;
    SELECT INTO user_id userid_from_username(i_uname);

    INSERT INTO note (range, contents, creator_uid)
        VALUES (i_range, i_contents, user_id);
    RETURN TRUE;
END
$$
LANGUAGE plpgsql;


-- get_dataset() ----------------------------------------------------
CREATE OR REPLACE FUNCTION get_dataset(TEXT, TIMESTAMP WITHOUT TIME ZONE)
    RETURNS SETOF RECORD AS $get_dataset$
DECLARE
    catalog_name ALIAS FOR $1;
    dataset_time_arg ALIAS FOR $2;
    dataset_time TIMESTAMP WITHOUT TIME ZONE;
    ds_id INTEGER;
    r RECORD;
BEGIN
    IF dataset_time_arg IS NULL THEN
        SELECT INTO dataset_time NOW();
    ELSE
        SELECT INTO dataset_time dataset_time_arg;
    END IF;

    FOR r IN SELECT d.dataset_id, d.cattype
        FROM (
            SELECT d.*, c.*
            FROM dataset d JOIN catalog c1 ON d.catalog_id=c1.catalog_id
            JOIN (
                select catid,catpath,cattype from
                    get_catalogs(ARRAY[catalog_name])
            ) AS c ON d.catalog_id=c.catid
        ) AS d
        WHERE d.t_begin <= dataset_time
        AND d.t_end > dataset_time LOOP
        RETURN NEXT r;
    END LOOP;

    RETURN;
END;
$get_dataset$
LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION add_user(
    IN i_username TEXT,
    IN i_displayname TEXT,
    IN i_groupname TEXT
) RETURNS INTEGER AS $$
DECLARE
    is_super BOOLEAN DEFAULT FALSE;
BEGIN

    IF EXISTS (SELECT * FROM users WHERE username=i_username)
    THEN
        RAISE EXCEPTION 'User already exists.';
    END IF;

    INSERT INTO users (username, displayname) VALUES (i_username, i_displayname);

    -- The PostgreSQL user might already exist, so we check here.

    IF NOT EXISTS (SELECT * FROM pg_catalog.pg_roles WHERE rolname=i_username)
    THEN
        EXECUTE 'CREATE ROLE ' || i_username || ' LOGIN IN ROLE ' || i_groupname;
    END IF;

    SELECT INTO is_super rolsuper FROM pg_catalog.pg_roles WHERE rolname=i_username;

    IF (i_groupname = 'g_ipa_admin' AND NOT is_super)
    THEN
        EXECUTE 'ALTER USER ' || i_username || ' CREATEROLE';
    END IF;
    
    IF NOT is_super
    THEN
        EXECUTE 'ALTER USER ' || i_username || ' SET search_path to ipa, public';
    END IF;

    -- If the user already existed, they might not be in the group.  We need to
    -- add Postgres superusers to the group explicitly here.
    IF NOT pg_has_role(i_username, i_groupname, 'MEMBER')
    OR is_super
    THEN
        EXECUTE 'GRANT ' || i_groupname || ' TO ' || i_username;
    END IF;

    EXECUTE 'GRANT USAGE ON SCHEMA ipa TO ' || i_username;

    -- The IPA superuser account needs to be able to SET ROLE to this user
    IF NOT pg_has_role('ipa', i_username, 'USAGE')  THEN
        EXECUTE 'GRANT ' || i_username || ' TO ipa';
    END IF;

    RETURN currval('users_id_seq');
END;
$$
LANGUAGE plpgsql;

REVOKE EXECUTE ON FUNCTION add_user(TEXT, TEXT, TEXT) FROM g_ipa_user, g_ipa_auditor;


CREATE OR REPLACE FUNCTION update_user(
    IN i_userid INTEGER,
    IN i_displayname TEXT,
    IN i_groupname TEXT
) RETURNS INTEGER AS $$
DECLARE
    uname TEXT;
BEGIN

    IF NOT EXISTS (SELECT * FROM users WHERE id=i_userid)
    THEN
        RAISE EXCEPTION 'User does not exist.';
    END IF;

    -- Change the user's display name in the users table
    UPDATE users SET displayname=i_displayname WHERE id=i_userid;

    SELECT INTO uname username FROM users WHERE id=i_userid;

    IF (i_groupname = 'g_ipa_admin'
        AND NOT (SELECT rolsuper FROM pg_catalog.pg_roles
            WHERE rolname=uname)
        )
    THEN
        EXECUTE 'ALTER USER ' || uname || ' CREATEROLE';
    END IF;
    
    IF NOT (SELECT rolsuper FROM pg_catalog.pg_roles
        WHERE rolname=uname)
    THEN
        EXECUTE 'ALTER USER ' || uname || ' SET search_path to ipa, public';
    END IF;

    -- Revoke all IPA groups before adding the new ones
    EXECUTE 'REVOKE g_ipa_admin, g_ipa_auditor, g_ipa_user FROM ' || uname;

    -- If the user already existed, they might not be in the group
    IF NOT pg_has_role(uname, i_groupname, 'MEMBER') THEN
        EXECUTE 'GRANT ' || i_groupname || ' TO ' || uname;
    END IF;

    EXECUTE 'GRANT USAGE ON SCHEMA ipa TO ' || uname;
    -- The IPA superuser account needs to be able to SET ROLE to this user

    IF NOT pg_has_role('ipa', uname, 'USAGE')  THEN
        EXECUTE 'GRANT ' || uname || ' TO ipa';
    END IF;

    RETURN i_userid;
END;
$$
LANGUAGE plpgsql;

REVOKE EXECUTE ON FUNCTION update_user(INTEGER, TEXT, TEXT) FROM g_ipa_user, g_ipa_auditor;


CREATE OR REPLACE FUNCTION delete_user(
    IN i_userid INTEGER
) RETURNS BOOLEAN AS $$
DECLARE
    uname TEXT;
BEGIN
    SELECT INTO uname username FROM users WHERE id=i_userid;
    DELETE FROM users WHERE id=i_userid;
    EXECUTE 'REVOKE g_ipa_admin, g_ipa_auditor, g_ipa_user FROM ' || uname;
    EXECUTE 'REVOKE USAGE ON SCHEMA ipa FROM ' || uname;
    RETURN TRUE;
END;
$$
LANGUAGE plpgsql;

REVOKE EXECUTE ON FUNCTION delete_user(INTEGER) FROM g_ipa_user, g_ipa_auditor;


CREATE OR REPLACE FUNCTION get_user_info(
    IN username TEXT,
    OUT displayname TEXT
)
AS $$
BEGIN
    SELECT * FROM users u JOIN (
        SELECT r.rolname, r.rolsuper, r.rolinherit,
            r.rolcreaterole, r.rolcreatedb, r.rolcanlogin,
            r.rolconnlimit,
        ARRAY(SELECT b.rolname
        FROM pg_catalog.pg_auth_members m
        JOIN pg_catalog.pg_roles b ON (m.roleid = b.oid)
        WHERE m.member = r.oid) as memberof
        FROM pg_catalog.pg_roles r
    ) r
    ON u.username=r.rolname;
END;
$$
LANGUAGE plpgsql;


-- Audit option #2
CREATE OR REPLACE FUNCTION ipa_audit_trigger() RETURNS trigger AS
$BODY$ 

DECLARE 

_PK_NAMES CONSTANT varchar[] := 
          ARRAY(SELECT a.attname AS pk_name FROM pg_class c, pg_attribute a, pg_index i
     WHERE c.oid = i.indrelid
     AND a.attrelid = i.indexrelid
     AND a.attisdropped = false /* such column names are like "........pg.dropped.1........" and are invalid */
     AND a.attnum > 0 /* i.e is not a system column like OID: they have (arbitrary) negative numbers */
     AND i.indisprimary = TRUE /* is pk */
     AND c.oid = TG_RELID /* regclass takes current schema into consideration! */); 

_FIELD_NAMES CONSTANT varchar[] := ARRAY(SELECT a.attname AS pk_name FROM pg_class c, pg_attribute a
     WHERE c.oid = a.attrelid
     AND a.attisdropped = false /* such column names are like "........pg.dropped.1........" and are invalid */
     AND a.attnum > 0 /* i.e is not a system column like OID: they have (arbitrary) negative numbers */
     AND c.oid = TG_RELID); /* regclass takes current schema into consideration! */ 

_PK_VALUES varchar[]; 
  _tx_counter BIGINT = 0;
BEGIN 

-- this function works only when marked as AFTER trigger!
PERFORM assert(TG_WHEN = 'AFTER', 'Wrong execution of ipa_audit_log(): should only be executed AFTER an event!');
-- this function works only when marked as FOR EACH ROW trigger!
PERFORM assert(TG_LEVEL = 'ROW', 'Wrong execution of ipa_audit_log(): should only be executed FOR EACH ROW!'); 

-- table sanity check
PERFORM assert(TG_TABLE_NAME IS NOT NULL, 'TG_TABLE_NAME IS NULL');
PERFORM assert(_PK_NAMES IS NOT NULL AND array_length(_PK_NAMES, 1) IS NOT NULL, 'Table ' || TG_TABLE_NAME || ' can not be logged: it has no PK!');  -- FOR-loop will otherwise throw "upper bound of FOR loop cannot be null" 

-- skip changes on audit_table: otherwise endless loop
IF TG_TABLE_NAME = 'audit_log' THEN
 return NULL; -- result is ignored since this is an AFTER trigger
END IF; 

-- find PK value
FOR i IN 1 .. array_length(_PK_NAMES, 1)
LOOP
 DECLARE
  tmp text;
  tmp_record record;
 BEGIN
  CASE TG_OP
  WHEN 'UPDATE', 'INSERT' THEN tmp_record = NEW;
  WHEN 'DELETE' THEN tmp_record = OLD;
  END CASE; 

  EXECUTE 'SELECT $1.' || quote_ident(_PK_NAMES[i]) INTO STRICT tmp USING tmp_record;
  _PK_VALUES[i] := tmp;
 END;
END LOOP; 

-- PK values sanity check
PERFORM assert(_PK_VALUES IS NOT NULL AND array_length(_PK_VALUES, 1) IS NOT NULL, '_PK_VALUES IS NULL'); -- FOR-loop will otherwise throw "upper bound of FOR loop cannot be null"
PERFORM assert(array_length(_PK_VALUES, 1) = array_length(_PK_NAMES, 1), '_PK_VALUES count not equal to _PK_NAMES count in table ' || TG_TABLE_NAME); 

-- find fields to be logged
FOR i IN 1 .. array_length(_FIELD_NAMES, 1)
LOOP
 -- field_name sanity check
 PERFORM assert(_FIELD_NAMES[i] IS NOT NULL, '_FIELD_NAMES[' || i || '] IS NULL'); 

 DECLARE
  _field_name CONSTANT varchar := quote_ident(_FIELD_NAMES[i]);
  _distinct boolean;
  _old text;
  _new text;
 BEGIN 

 CASE TG_OP --fall through is unfortunately not supported
  WHEN 'UPDATE' THEN
   -- compare the two fields according to the type-default functions.
   -- note that <> returns false on NULL input and IS DISTINCT FROM does not, but only if both inputs are NULL!
   EXECUTE 'SELECT $1.' || _field_name || ' IS DISTINCT FROM $2.' || _field_name || ';' INTO STRICT _distinct USING OLD, NEW;
   CONTINUE WHEN NOT _distinct; 

   EXECUTE 'SELECT $1.' || _field_name || ';' INTO STRICT _new USING NEW;
   EXECUTE 'SELECT $1.' || _field_name || ';' INTO STRICT _old USING OLD;
  WHEN 'INSERT' THEN
   EXECUTE 'SELECT $1.' || _field_name || ';' INTO STRICT _new USING NEW;
  WHEN 'DELETE' THEN
   EXECUTE 'SELECT $1.' || _field_name || ';' INTO STRICT _old USING OLD;
  ELSE
   RAISE EXCEPTION 'Unhandled TG_OP in ipa_audit_log(): %', TG_OP;
 END CASE; 

 CONTINUE WHEN _new IS NULL AND _old IS NULL; 

 PERFORM ipa_audit_log(statement_timestamp()::timestamp without time zone, SESSION_USER::varchar, TG_TABLE_NAME::varchar, _field_name, _PK_NAMES, _PK_VALUES, TG_OP::table_audit_mod_type, _old, _new);
 END;
END LOOP; 

RETURN NULL; -- result is ignored since this is an AFTER trigger
END; 

$BODY$
  LANGUAGE 'plpgsql' VOLATILE SECURITY DEFINER; 


CREATE TYPE table_audit_mod_type AS ENUM ('INSERT', 'UPDATE', 'DELETE', 'TRUNCATE');


 CREATE OR REPLACE FUNCTION ipa_audit_log(_ctime timestamp without time zone, _user name, _table name, _field name, _pk_name character varying[], _pk_value character varying[], _mod_type table_audit_mod_type, _value_old text, _value_new text)
  RETURNS void AS
$BODY$
DECLARE
BEGIN 

INSERT INTO audit_log(txid, ctime, username, tablename, field, pk_name, pk_value, mod_type, value_old, value_new)
 VALUES (txid_current(), _ctime, _user, _table, _field, _pk_name, _pk_value, _mod_type, _value_old, _value_new); 

END;
$BODY$
  LANGUAGE 'plpgsql' VOLATILE;


 CREATE OR REPLACE FUNCTION assert(boolean, character varying)
  RETURNS void AS
$BODY$
BEGIN
 IF NOT $1 OR $1 IS NULL THEN
   IF $2 IS NOT NULL THEN
     RAISE EXCEPTION 'Assert failure: %', $2;
   END IF;
   RAISE NOTICE 'Assert. Message is null';
 END IF;
END;$BODY$
  LANGUAGE 'plpgsql' VOLATILE; 


CREATE TABLE audit_log
(
  id serial primary key,
  txid bigint NOT NULL,
  ctime timestamp without time zone NOT NULL,
  username character varying(64) NOT NULL,
  tablename character varying(32) NOT NULL,
  field character varying(32) NOT NULL,
  pk_name character varying(32)[] NOT NULL,
  pk_value character varying(64)[] NOT NULL,
  mod_type table_audit_mod_type NOT NULL,
  value_old text,
  value_new text,
  CONSTRAINT audit_log_check_pk CHECK (array_length(pk_name, 1) = array_length(pk_value, 1))
);


CREATE OR REPLACE VIEW audit_changes AS
 SELECT audit_log.txid, array_agg(audit_log.id), audit_log.ctime, audit_log.username, audit_log.tablename, audit_log.pk_name, audit_log.pk_value, audit_log.mod_type, ARRAY[array_agg(audit_log.field), array_agg(audit_log.value_old)::character varying[], array_agg(audit_log.value_new)::character varying[]] AS changeset
   FROM audit_log
  GROUP BY audit_log.txid, audit_log.ctime, audit_log.username, audit_log.tablename, audit_log.pk_name, audit_log.pk_value, audit_log.mod_type;


CREATE OR REPLACE FUNCTION ipa_enable_audit(
        IN tablename TEXT,
        IN enabled BOOLEAN) RETURNS VOID AS $$
DECLARE
    triggername TEXT;
BEGIN
    triggername = tablename || '_audit_trigger';
    IF enabled THEN
        EXECUTE 'CREATE TRIGGER ' || triggername || ' '
        || 'AFTER INSERT OR DELETE OR UPDATE ON ' || tablename || ' '
        || 'FOR EACH ROW '
        || 'EXECUTE PROCEDURE ipa_audit_trigger()';
    ELSE
        EXECUTE 'DROP TRIGGER ' || triggername || ' ON ' || tablename;
    END IF;
END;
$$ LANGUAGE 'plpgsql';


-- Enable auditing for all tables.  Change TRUE to FALSE for any tables you
-- don't want auditing enabled for.
SELECT ipa_enable_audit('users', TRUE);
SELECT ipa_enable_audit('catalog', TRUE);
SELECT ipa_enable_audit('dataset', TRUE);
SELECT ipa_enable_audit('label', TRUE);
SELECT ipa_enable_audit('assoc_set', TRUE);
SELECT ipa_enable_audit('assoc_bag', TRUE);
SELECT ipa_enable_audit('assoc_pmap', TRUE);
SELECT ipa_enable_audit('assoc_mmap', TRUE);
SELECT ipa_enable_audit('note', TRUE);

