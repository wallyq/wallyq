#!/usr/bin/env python
## ------------------------------------------------------------------------
## setup.py
## distutils setup script for ipa-python
## ------------------------------------------------------------------------
## Copyright (C) 2006-2011 Carnegie Mellon University. All Rights Reserved.
## ------------------------------------------------------------------------
## Authors: Tony Cebzanov <tonyc@cert.org>
## ------------------------------------------------------------------------
## GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
## Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
## ------------------------------------------------------------------------


from netsa import dist

dist.set_name("ipa")
dist.set_version("0.5.2")
dist.set_title("IPA")
dist.set_description("""
                     IPA is an IP address annotation system. IPA provides a
                     flexible and efficient repository of IP address
                     information, tools for querying and maintaining the data,
                     and shared libraries and modules for IPA data access by
                     client applications.
                     """)

dist.set_maintainer("NetSA Group <netsa-help@cert.org>")
dist.set_url("http://tools.netsa.cert.org/ipa")
dist.set_license("GPL")

dist.add_package("ipa")

dist.add_version_file("src/ipa/VERSION")

dist.execute()
