## ------------------------------------------------------------------------
## ipa/errors.py
## ipa-python errors
## ------------------------------------------------------------------------
## Copyright (C) 2006-2011 Carnegie Mellon University. All Rights Reserved.
## ------------------------------------------------------------------------
## Authors: Tony Cebzanov <tonyc@cert.org>
## ------------------------------------------------------------------------
## GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
## Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
## ------------------------------------------------------------------------


##@defgroup ipapython_exceptions ipa-python Exception Classes
##@{
class IPAError(Exception):
    """Base class for all IPA exceptions."""
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return """IPA Error: %s""" %(self.msg)

class IPASQLExecutionError(IPAError):
    """IPA exception raised when a query execution fails.."""
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return """SQL execution error: %s""" %(self.msg)

class IPARangeError(IPAError):
    """IPA exception raised when ranges conflict."""
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return """Error making IPA association: %s""" %(self.msg)

class IPACatalogNotFoundError(IPAError):
    """IPA exception raised when a catalog doesn't exist with the given name."""
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return """IPA catalog error: %s""" %(self.msg)

class IPADatasetNotFoundError(IPAError):
    """IPA exception raised when a dataset doesn't exist for the given date."""
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return """IPA dataset error: %s""" %(self.msg)

class IPADatasetError(IPAError):
    """IPA exception raised when dataset ranges overlap."""
    def __init__(self, msg):
        self.msg = msg        
    def __str__(self):
        return """IPA dataset error: %s""" %(self.msg)

class IPALabelError(IPAError):
    """IPA exception raised when there is a problem querying labels."""
    def __init__(self, msg):
        self.msg = msg        
    def __str__(self):
        return """IPA dataset error: %s""" %(self.msg)
##@}

## @} End defgroup ipapython

