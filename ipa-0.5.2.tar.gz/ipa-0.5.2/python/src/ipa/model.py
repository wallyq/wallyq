## ------------------------------------------------------------------------
## ipa/__init__.py
## ipa-python main module
## ------------------------------------------------------------------------
## Copyright (C) 2006-2011 Carnegie Mellon University. All Rights Reserved.
## ------------------------------------------------------------------------
## Authors: Tony Cebzanov <tonyc@cert.org>
## ------------------------------------------------------------------------
## GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
## Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
## ------------------------------------------------------------------------

from errors import *

catalog_types = [ "none", "set", "bag", "pmap", "mmap" ]


user_groups = dict([(x, "g_ipa_" + x.lower())
                     for x in ("User", "Auditor", "Admin")])

user_groups_inv = dict((v,k) for k, v in user_groups.iteritems())


class IPAUser(object):

    def __init__(self, **kwargs):
        if 'username' not in kwargs or 'displayname' not in kwargs:
            raise IPAError("Must supply a username and displayname for the user")
        self.__dict__.update(kwargs)
        self.roles = [ user_groups_inv[x] for x in self.roles ]

    def __repr__(self):
        return "IPAUser([%s] %s %r)" %(self.username, self.displayname, self.roles)

    def __json__(self):
        # Does nothing until http://pylonshq.com/project/pylonshq/ticket/632
        # is implemented.  Until then, caller needs to use __dict__.
        return dict(self)

    def has_role(self, role):
        return self.roles and role in self.roles

    def is_admin(self):
        return 'Admin' in self.roles



class IPACatalog(object):
    """A logical partition of related IPA datasets."""
    def __init__(self, name, type="set", context=None,
                 id=None, parent_id=None, desc=None,
                 creator=None, creator_uid=None,
                 depth=None, childcount=0):
        # FIXME: do depth, children belong here?
        self.id = id
        self.parent_id = parent_id
        self.context = context
        self.name = name

        if isinstance(type, str):
            self.type = catalog_types.index(type)
        else:
            self.type = type

        self.desc = desc
        self.creator_uid = creator_uid
        self.creator = creator
        self.depth = depth
        self.childcount = childcount

    def __repr__(self):
        return "IPACatalog(%s, %d, %s)" %(self.name, self.id, self.desc)


    def add_dataset(self, start, end, creator):
        """
        Add a new dataset to the catalog
        """

        try:
            rs = self.context.execute("SELECT ipa.add_dataset(:id, :start, :end, :creator)",
                                      id=self.id, start=start, end=end, creator=creator )
            res = list(rs)
            if not res:
                raise IPADatasetError, "problem creating dataset"
            ds_id = res[0]
        except Exception, e:
            raise IPADatasetError(str(e))

        return IPADataset(ds_id, cat_type=self.type, context=self.context)

    def get_dataset(self, date):
        """
        Retrieve a dataset for a given time from the catalog
        """

        sql = """
            SELECT * FROM get_dataset(:name, :date) AS
            (dataset_id INTEGER, catalog_type INTEGER)
            """

        try:
            rs = self.context.execute(sql, name=name, date=date)
            res = rs.fetchone()
            if not res:
                raise IPADatasetNotFoundError, "no dataset for %s" % date
            ds_id = res[0]
        except IPADatasetNotFoundError:
            raise
        except Exception, e:
            raise IPADatasetError(str(e))

        return IPADataset(ds_id, cat_type=self.type)

    # Get datasets for this catalog
    def get_datasets(self, begin=None, end=None):
        """
        Retrieve one or more datasets valid during a time interval from the
        catalog
        """
        sql = """
        SELECT dataset_id, t_begin, t_end, ctime, mtime, assoc_count, ip_count
        FROM dataset_view
        WHERE
        catalog_id = :id
        AND CASE WHEN :t_begin IS NULL THEN TRUE ELSE
        (:t_begin::timestamp, :t_end::timestamp) OVERLAPS (t_begin, t_end) END
        """

#        if begin:
#            sql += "AND t_begin >= %s"
#            params.append(begin)
#        if end:
#            sql += "AND t_end < %s"
#            params.append(end)
        try:
            rs = self.context.execute(sql, id=self.id, t_begin=begin, t_end=end)
        except Exception, e:
            raise IPADatasetError, str(e)
        for (dataset_id, begin, end, ctime, mtime, assoc_count, ip_count) in rs:
            yield IPADataset(dataset_id, begin=begin, end=end,
                             ctime=ctime, mtime=mtime,
                             assoc_count=assoc_count, ip_count=ip_count )
        #rs.close()

    def get_labels(self, labels=None):
        """
        Retrieve all of the labels in the dataset
        """
        sql = """
            SELECT label_id, name FROM label
            WHERE catalog_id = %s
            """
        params = [self.id]
        if labels:
            t = ['%s'] * len(labels)
            sql += "AND name IN (%s)\n" % ", ".join(t)
            params.extend(labels)
        try:
            rs = self.context.execute(sql, params)
        except Exception, e:
            raise IPADatasetError, str(e)
        for (id, name) in rs:
            yield IPALabel(id, name, self.id)
        #rs.close()

    def delete_dataset(self, date):
        """
        Deletes the dataset for a given time from the catalog
        """
        try:
            ds = self.get_dataset(date)
        except Exception, e:
            raise IPADatasetNotFoundError, str(e)
        try:
            sql = "DELETE FROM dataset where dataset_id = %s"
            try:
                rs = self.context.execute(sql, [ds.id] )
            except Exception, e:
                raise IPADatasetError, str(e)
        finally:
            a=1
            ##rs.close()


class IPADataset(object):
    """
    A collection of IPA associations valid during a particular time interval
    """
    def __init__(self, id, context=None, begin=None, end=None, ctime=None, mtime=None,
                 cat_name = None, cat_type=None, assoc_count = 0, ip_count = 0):
        self.context = context
        (self.id, self.begin, self.end, self.ctime, self.mtime, self.cat_name, self.cat_type, self.assoc_count, self.ip_count) = \
            (id, begin, end, ctime, mtime, cat_name, cat_type, assoc_count, ip_count)

    def __repr__(self):
        return "IPADataset(%s, %s, %s)" %(self.cat_name, self.begin, self.end)


    def __inflate__(self):
        try:
            rs = self.context.execute("""
                select t_begin, t_end from dataset where dataset_id=:id
            """, id=self.id )
            rows = list(rs)[0]
        except Exception, e:
            raise IPADatasetError, str(e)

        if not rows:
            raise IPADatasetError, "no dataset for id %s" % id
        self.begin = rows[0]
        self.end   = rows[1]

    def __iter__(self):
        sql = """
            SELECT a.range, 
            lower(a.range)::bigint AS begin, 
            upper(a.range)::bigint AS end, 
            l.name, a.value 
            FROM assoc a
            LEFT JOIN label l ON a.label_id=l.label_id 
            WHERE a.dataset_id=%s;
            """
        try:
            rs = self.context.execute(sql, ( self.id, ))
        except Exception, e:
            raise IPADatasetError, str(e)
        for row in rs:
            yield row
        #rs.close()

    def add_assoc(self, addr, label=None, value=None, creator=None):
        """
        Add an IP association to the dataset.
        """
        try:
            try:
                try:
                    (begin, end) = addr
                    rs = self.context.execute("SELECT add_assoc(%s, %s::ip4, %s::ip4, %s, %s, %s)",
                        ( self.id, begin, end, label, value, creator ) )
                except ValueError:
                    rs = self.context.execute("SELECT add_assoc(%s, %s, lower(%s::ip4r), upper(%s::ip4r), %s, %s, %s)",
                        ( self.id, addr, addr, label, value, creator ) )
            except Exception, e:
                self.conn.rollback()
                raise IPARangeError(str(e))
        finally:
            a=1
            ##rs.close()

    def __hash__(self):
        return self.id

class IPALabel(object):
    """A textual label which can be used in one or more IPA associations"""
    def __init__(self, id, name, catalog_id, conn=None):
        (self.id, self.name, self.catalog_id) = (id, name, catalog_id)

    def __str__(self):
        return self.name

    # having these here makes label objects play nicely with datasets
    # and string versions of labels

    def __hash__(self):
        return self.name.__hash__()

    def __cmp__(self, other):
        if isinstance(other, self.__class__):
            return cmp(self.id, other.id)
        else:
            return cmp(str(self), other)

class IPAAssoc(object):
    def __init__(self, catalog=None, stime=None, etime=None, range=None, begin=None, end=None, label=None, value=None):
        self.catalog = catalog
        self.stime = stime
        self.etime = etime
        self.range = range
        self.begin = begin
        self.end = end
        self.label = label
        self.value = value

