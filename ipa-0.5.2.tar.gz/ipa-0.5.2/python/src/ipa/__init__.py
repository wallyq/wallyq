## ------------------------------------------------------------------------
## ipa/__init__.py
## ipa-python main module
## ------------------------------------------------------------------------
## Copyright (C) 2006-2011 Carnegie Mellon University. All Rights Reserved.
## ------------------------------------------------------------------------
## Authors: Tony Cebzanov <tonyc@cert.org>
## ------------------------------------------------------------------------
## GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
## Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
## ------------------------------------------------------------------------

from netsa import find_version
__version__ = find_version(__file__)

from os import getenv, getlogin
from netsa.sql import *

from errors import *
from model import *

##@namespace ipa
#IPA module for Python

##@defgroup ipapython ipa-python
# 
# The ipa Python module provides an interface to IPA data from Python
# applications. The functionality is similar to that provided by @ref libipa,
# except with a more "Python-esque" interface.
# Please note that this module is not simply a Python wrapper for libipa, and
# you do not need to install libipa to use ipa-python.
#
# ipa-python consists of @ref ipapython_data "data classes" for interacting with
# IPA, and @ref ipapython_exceptions "exception classes" that define various
# errors that may be thrown by IPA.
#
# @section intro_sec Installation
#
# The preferred installation procedure is to run IPA's top-level
# <tt>configure</tt> script with the <tt>--with-python</tt> option.  If you
# only want the Ipa-python components installed, you can run <tt>configure</tt>
# in the <tt>python/</tt> subdirectory of the distribution, then run
# <tt>make</tt> and <tt>make install</tt> to build agnd install.
# 
# Technical note:  While a <tt>Makefile</tt> is provided, it is essentially a
# wrapper around Python's distutils build system, and the Python module is
# installed by invoking the included <tt>setup.py</tt> script.  The skeleton
# <tt>configure</tt> script and <tt>Makefile</tt> are provided to allow
# ipa-python to be embedded in and installed as part of the larger suite of
# tools and libraries.
# 
# @file
# ipa-python interface
# @{


# constants

#conn = None

##@defgroup ipapython_data ipa-python Data Classes
# 
# These classes provide an interface for working with IPA data.
#
##@{

class IPA(object):
    """
    Represents a connection to an IPA data store.

    *uri* should be a `netsa.sql` database URI.

    If *pooled* is True, a database connection pool will be used
    instead of opening a new connection for each request.
    """

    def __init__(self, uri=None, pooled=False):
        if uri == None:
            uri = getenv("IPA_DB_URI")
            if uri == None:
                raise ImportError(
                    """could not get IPA database info from the environment.
                    Please set IPA_DB_URI appropriately.""")
        self.uri = uri
        self.pooled = pooled
        if self.pooled:
            self.pool = db_create_pool(uri)
            #self.pool = db_create_pool(uri)
        else:
            self.conn = db_connect(self.uri)
            
    def __repr__(self):
        return "IPA(%s)" %(self.uri)

    def execute(self, sql, role=None, **params):
        if self.pooled:
            conn = self.pool.connect()
        else:
            conn = self.conn

        if role:
            conn.execute("SET ROLE :role", role=role)
        try:
            rs = conn.execute(sql, **params)
        except Exception, e:
            conn.rollback()
            raise IPASQLExecutionError(e) 

        conn.commit()
        if role:
            conn.execute("RESET ROLE")
        del conn
        return rs
        

    def commit(self):
        self.conn.commit()

    def abort(self):
        self.conn.rollback()


    def add_user(self, username, displayname, role="User",
                 admin_username=None):
        """
        Add a new user to the IPA database
        """
        try:
            admin_user = iter(self.get_users(admin_username)).next()
        except StopIteration:
            raise IPAError("Admin user does not exist")
        
        if not admin_user.is_admin():
            raise Exception('Only administrators can add users')

        try:
            rs = self.execute("""
            SELECT add_user(:username::text, :displayname::text, :groupname::text);""",
                              role=admin_username,
                              username=username,
                              displayname=displayname,
                              groupname=user_groups[role])
            return list(rs)[0]

        except Exception, e:
            raise IPAError(str(e))


    def update_user(self, uid, displayname, role="User",
                 admin_username=None):
        """
        Change a user's name or role
        """
        try:
            admin_user = iter(self.get_users(admin_username)).next()
        except StopIteration:
            raise IPAError("Admin user does not exist")
            
        if not admin_user.is_admin():
            raise Exception('Only administrators can add users')

        try:
            rs = self.execute("""
                              SELECT update_user(:uid::integer,
                              :displayname::text, :groupname::text);""",
                              role=admin_username,
                              uid=uid,
                              displayname=displayname,
                              groupname=user_groups[role])
            return list(rs)[0]

        except Exception, e:
            raise IPAError(str(e))

    def delete_user(self, userid, admin_username=None):
        """
        Delete an existing user from the IPA database
        """
        admin_user = iter(self.get_users(admin_username)).next()

        if not (admin_user.is_admin()):
            raise Exception('Only administrators can delete users')

        try:
            rs = self.execute("SELECT delete_user(:userid)",
                              role=admin_username,
                              userid=userid)

        except Exception, e:
            raise IPAError(str(e))

        return True

    def check_catalog_owner(self, catalog_id, username):
        """
        Check if *username* owns the catalog with id *catalog_id*
        """
        result = False
        try:
            rs = self.execute("""
            SELECT (SELECT catalog_uid FROM catalog_view WHERE catalog_id = :catalog_id LIMIT 1)
            = (SELECT id FROM users WHERE username=:username)""", catalog_id=catalog_id, username=username)
            result = iter(rs).next()[0]
        except Exception, e:
            return False

        return result

    def check_dataset_owner(self, dataset_id, username):
        """
        Check if user *username* owns the dataset with id *dataset_id*
        """
        result = False
        try:
            rs = self.execute("""
            SELECT (SELECT dataset_uid FROM dataset_view
                    WHERE dataset_id = :dataset_id LIMIT 1)
            = (SELECT id FROM users WHERE username=:username)""",
                              dataset_id=dataset_id, username=username)
            result = iter(rs).next()[0]
        except Exception, e:
            return False

        return result


    def get_users(self, username=None):
        keys = ["id", "username", "displayname", "roles"]

        rs = self.execute("""
            SELECT id, username, displayname,
            ARRAY(SELECT DISTINCT b.rolname AS role_name
            FROM pg_auth_members m
            JOIN pg_authid a ON m.member = a.oid
            JOIN pg_authid b ON m.roleid = b.oid
            WHERE pg_has_role(username, a.oid, 'USAGE'::text)
            AND b.rolname LIKE 'g_ipa_%'
            ) AS roles FROM users u
            WHERE
            CASE WHEN :username IS NULL
            THEN TRUE
            ELSE u.username = :username
            END
            """, username=username);

        for record in rs:
            user = dict(zip(keys, record))
            yield IPAUser(**user)

    def add_catalog(self, name, type="set", desc=None, creator=None):
        """
        Add a new catalog to the IPA database.
        *name* is the full name of the catalog, in dotted notation
        (e.g. ``foo.bar.baz``).

        *type* is the catalog type, which should be one of ``set``, ``bag``,
        ``pmap``, or ``mmap``
        """

        if isinstance(type, int):
            typeid = type
        elif isinstance(type, str):
            typeid = catalog_types.index(type)
        else:
            raise Exception('Invalid catalog type')

        try:

            rs = self.execute("""SELECT * FROM add_catalog(:name::text,
                                :type::integer, :desc::text, :creator::text)""",
                              name=name, type=typeid,
                              desc=desc, creator=creator)
            id = iter(rs).next()[0]
        except Exception, e:
            raise IPAError(e)

        catalog = IPACatalog(name, type, id=id, desc=desc)
        return catalog

    def link_catalog(self, child, parent):
        """
        Create a link between a parent and child catalog.  The *parent* and
        *child* parameters should be the catalog IDs to link.        
        """
        
        if not child and parent:
            return False
        try:
            rs = self.execute("""INSERT INTO catalog_edge (child, parent)
                              VALUES (:child, :parent)""",
                              child=child, parent=parent)

        except Exception, e:
            raise IPAError(str(e))

        return True

    def unlink_catalog(self, child, parent):
        """
        Remove a link between a parent and child catalog.  The *parent* and
        *child* parameters should be the catalog IDs to unlink.
        """
        
        if not child and parent:
            return False
        try:
            rs = self.execute(
                "SELECT COUNT(*) FROM catalog_view WHERE catalog_id=:child",
                child=child)
            (count,) = iter(rs).next()
            if count <= 1:
                raise Exception("Unlinking this child would create an orphan.")
            else:
                rs = self.execute("""DELETE FROM catalog_edge
                                  WHERE child=:child
                                  AND parent=:parent""",
                                  child=child, parent=parent)
            
        except Exception, e:
            raise IPAError(str(e))

        return True

    def update_catalog(self, catid, catname, catdesc, username):
        """
        Change the name of the catalog with id *catid* to *catname*.
        """

        if not catid and catname:
            return False

        user = iter(self.get_users(username)).next()

        if not (user.is_admin() or self.check_catalog_owner(catalog_id, username)):
            return False

        try:
            rs = self.execute(
                """UPDATE catalog
                SET name=:catname, description=:catdesc
                WHERE catalog_id=:catid;""",
                catname=catname, catdesc=catdesc, catid=catid)

        except Exception, e:
            raise IPAError(str(e))

        return True


    def delete_catalog(self, catalog_id, username):
        """
        Remove a catalog from the database.  This operation is destructive,
        unlike :func:`trash_catalog`.  Use with caution.
        """

        user = iter(self.get_users(username)).next()

        if not (user.is_admin() or self.check_catalog_owner(catalog_id, username)):
            return False

        try:
            rs = self.execute("""DELETE FROM catalog
                              WHERE catalog_id=:catalog_id""",
                              catalog_id=catalog_id)
        except Exception, e:
            raise IPAError(str(e))

        return True

    def delete_dataset(self, dataset_id, username):
        """
        Deletes a dataset from the IPA database.
        """

        user = iter(self.get_users(username)).next()

        if not (user.is_admin() or self.check_dataset_owner(dataset_id, username)):
            return False

        try:
            rs = self.execute("""DELETE FROM dataset
                              WHERE dataset_id=:dataset_id""",
                              dataset_id=dataset_id)
        except Exception, e:
            raise IPAError(str(e))

        return True

    def grok_catalog_spec(self, expr):
        """
        Takes a catalog expression and repackages it for consumption by one of the
        backend functions that handle either catalog paths or numeric catalog IDs.

        Acceptable formats:
            Numeric catalog ID:  3
            Catalog path name: 'foo.bar'
            Array of catalog ids: [ 3, 4, 123 ]
            Array of catalog paths: ['foo.bar', 'foo.baz']
            None: None (will get all catalogs)
        """
        (ids, paths) = (None,) * 2
        
        if isinstance(expr, list) and len(expr) and isinstance(expr[0], int):
            ids = expr
        elif isinstance(expr, list) and len(expr) and (isinstance(expr[0], str) or isinstance(expr[0], unicode)):
            paths = expr
        elif isinstance(expr, int):
            ids = [expr]
        elif isinstance(expr, str) or isinstance(expr, unicode):
            paths = [expr]
        elif expr == None:
            ids = None
            paths = None
        else:
            raise IPAError("Invalid catalog specification")

        return (ids, paths)
        

    def get_catalogs(self, expr=None):
        """
        Return a list of IPA catalogs matching *expr*
        """

        (ids, paths) = self.grok_catalog_spec(expr)

        if paths:
           paths = [ x.replace('=', '***=') for x in paths ]

        query = """
        SELECT catalog_id, catalog_path, catalog_type, description, catalog_uid,
        (SELECT username FROM users WHERE id=catalog_uid) AS creator,
        depth, childcount, parent
        FROM catalog_view
        WHERE
        CASE WHEN :ids IS NULL THEN TRUE ELSE catalog_id = ANY(:ids) END
        AND CASE WHEN :paths IS NULL THEN TRUE ELSE catalog_path ~* ANY(:paths) END
        """

        try:
            rs = self.execute(query, ids=ids, paths=paths)
        except Exception, e:
            raise IPACatalogNotFoundError(str(e))

        for row in rs:
            (id, path, type, desc, creator_uid, creator, depth, childcount, parent_id) = row
            yield IPACatalog(
                path, type,
                context=self, id=id, parent_id=parent_id,
                desc=desc, creator_uid=creator_uid, creator=creator,
                depth=depth, childcount=childcount)


    def get_catalog(self, name):
        """
        Retrieve the named catalog from the database
        """
        #rs = self.conn.cursor()
        try:
            try:
                rs = self.execute("SELECT catalog_id, catalog_type, description FROM catalog WHERE name=:name", name=name);
                (id, type, desc) = iter(rs).next()
            except Exception, e:
                raise IPACatalogNotFoundError(str(e))
        finally:
            a=1
            ##rs.close()
            
        catalog = IPACatalog(name, catalog_types[type], id=id, desc=desc, context=self)
        return catalog

    # Get datasets across any number of catalogs
    def get_datasets(self, expr, begin=None, end=None,
                     include_children=True, unique=False,
                     sortfield="t_end", sortdir="desc"):
        """
        Retrieve one or more datasets valid during a time interval.

        *expr* is a catalog expression, which can be of any of the following formats:
        * numeric catalog id
        * catalog path name
        * list of numeric catalog IDs
        * list of path names

        If *expr* is `None`, the query will be across all catalogs in the
        database.

        The default behavior is to return each dataset for each catalog that
        matches *expr*, but tue to the fact that the catalog tree can contain
        multiple links to the same catalog, this can lead to duplication of
        dataset records.  To de-dupe these, set the *unique* argument to
        `True`.
        """

        orderby = ""
        distinct = ""

        # There's a bit of a special convenience case here:  a "catalog spec" of
        # the form foo.bar/123 will query for dataset 123 in catalog foo.bar.

        (ids, paths) = self.grok_catalog_spec(expr)

        if sortfield:
            orderby = "ORDER BY %s" %(sortfield)
            if sortdir and sortdir.lower() in ['asc', 'desc']:
                orderby += " %s" %(sortdir)

        if unique:
            distinct = "DISTINCT ON (dataset_id)"

        sql = """
        SELECT * FROM (
        SELECT %s dataset_id, catalog_path, t_begin, t_end, ctime, mtime, assoc_count, ip_count FROM dataset_view
        WHERE
        CASE WHEN :ids IS NULL THEN TRUE ELSE catalog_id = ANY(:ids) END
        AND CASE WHEN :paths IS NULL THEN TRUE ELSE dataset_path ~* ANY(:paths) END
        AND CASE WHEN :t_begin IS NULL THEN TRUE ELSE (:t_begin::timestamp, :t_end::timestamp) OVERLAPS (t_begin, t_end) END
        ORDER BY dataset_id, catalog_path
        ) AS datasets
        %s
        """ %(distinct, orderby)

        try:
            rs = self.execute(sql, ids=ids, paths=paths,
                              t_begin=begin, t_end=end)
        except Exception, e:
            raise IPADatasetError, str(e)

        for (dataset_id, cat_name, begin, end, ctime, mtime, assoc_count, ip_count) in rs:
            yield IPADataset(dataset_id, cat_name=cat_name, begin=begin, end=end, ctime=ctime, mtime=mtime, assoc_count=assoc_count, ip_count=ip_count )



    def count_assocs(self, catalogs=None, datasets=None, paths=None,
                     t_begin=None, t_end=None,
                     range=None, label=None):

        sql = """
        SELECT COUNT(*) 
        FROM assoc a
        LEFT JOIN label l ON a.label_id=l.label_id
        JOIN dataset_view dv
        ON a.dataset_id=dv.dataset_id
        WHERE CASE WHEN :catalogs IS NULL THEN TRUE ELSE dv.catalog_path ~* ANY (:catalogs) END
        AND CASE WHEN :datasets IS NULL THEN TRUE ELSE dv.dataset_id = ANY (:datasets) END
        AND CASE WHEN :paths IS NULL THEN TRUE ELSE dv.dataset_path ~* ANY (:paths) END
        AND CASE WHEN :t_begin IS NULL THEN TRUE ELSE (:t_begin::timestamp, :t_end::timestamp) OVERLAPS (t_begin, t_end) END
        AND CASE WHEN :range IS NULL THEN TRUE ELSE range <<= :range END
        AND CASE WHEN :label IS NULL THEN TRUE ELSE l.name = :label END
        """

        #print sql

        try:
            rs = self.execute(sql, catalogs=catalogs, datasets=datasets,
                              paths=paths, t_begin=t_begin, t_end=t_end,
                              range=range, label=label)
        except Exception, e:
            raise IPADatasetError, str(e)

        count = list(rs)[0]
        return count


    def find_assocs(self, catalogs=None, datasets=None, paths=None, t_begin=None, t_end=None,
                    range=None, label=None, limit=None, offset=None,
                    sortfield="catalog", sortdir="asc"):
        """
        Query the IPA database for associations matching the given parameters.

        *catalogs* is a list of catalog paths to match, or `None` to search all
        catalogs.

        *datasets* is a list of dataset IDs to match, or `None` to search all
        datasets

        *paths* is a list of dataset paths to match, or `None` to search all
        datasets

        *t_begin* is the beginning of a time range to query, or `None` if no
        time range is specified

        *t_end* is the end of a time range to query, or `None` if no
        time range is specified

        *range* is an IP address range to query

        *label* is a textual label to query
        """
        keys = ["catalog", "t_begin", "t_end",
                "range", "begin", "end", "label", "value", "count"]

        if sortfield == "catalog":
            orderby = "ORDER BY catalog %s, t_begin DESC, t_end DESC, range, label" %(sortdir)
        elif sortfield == "t_begin":
            orderby = "ORDER BY t_begin %s, t_end DESC, catalog ASC, range, label" %(sortdir)
        elif sortfield == "t_end":
            orderby = "ORDER BY t_end %s, t_begin DESC, catalog ASC, range, label" %(sortdir)
        elif sortfield == "range":
            orderby = "ORDER BY range %s, catalog, t_begin, t_end, label" %(sortdir)
        elif sortfield == "label":
            orderby = "ORDER BY label %s, range, catalog, t_begin, t_end" %(sortdir)
        else:
            orderby = ""

        sql = """
        SELECT catalog_path AS catalog,
        t_begin,
        t_end,
        range,
        lower(range) AS begin, 
        upper(range) AS end,
        l.name AS label,
        a.value AS value,
        COUNT(*) OVER() AS count
        FROM assoc a
        LEFT JOIN label l ON a.label_id=l.label_id
        JOIN dataset_view dv
        ON a.dataset_id=dv.dataset_id
        WHERE CASE WHEN :catalogs IS NULL THEN TRUE ELSE dv.catalog_path ~* ANY (:catalogs) END
        AND CASE WHEN :datasets IS NULL THEN TRUE ELSE dv.dataset_id = ANY (:datasets) END
        AND CASE WHEN :paths IS NULL THEN TRUE ELSE dv.dataset_path ~* ANY (:paths) END
        AND CASE WHEN :t_begin IS NULL THEN TRUE ELSE (:t_begin::timestamp, :t_end::timestamp) OVERLAPS (t_begin, t_end) END
        AND CASE WHEN :range IS NULL THEN TRUE ELSE range && :range END
        AND CASE WHEN :label IS NULL THEN TRUE ELSE l.name = :label END
        %s
        LIMIT :limit
        OFFSET :offset
        """ %(orderby)

        #print sql
        try:
            rs = self.execute(sql, catalogs=catalogs, datasets=datasets,
                              paths=paths, t_begin=t_begin, t_end=t_end,
                              range=range, label=label,
                              limit=limit, offset=offset)
        except Exception, e:
            raise IPADatasetError, str(e)

        for row in rs:
            yield dict(zip(keys, row))


    def get_range_notes(self, range=None, textsearch=None, comparison="overlaps",
                        limit=None, offset=None,
                        sortfield="ctime", sortdir="desc"):
        """
        Query notes for a given time range or containing a given textual term.
        """
        
        keys = ["range", "creator_username", "creator_displayname", "ctime", "contents"]
        operator = "&&"

        if sortfield == "ctime":
            orderby = "ctime %s, range, creator_username ASC" %(sortdir)
        elif sortfield == "range":
            orderby = "range %s, ctime DESC, creator_username ASC" %(sortdir)
        elif sortfield == "creator_username":
            orderby = "creator_username %s, ctime DESC, range ASC" %(sortdir)
        else:
            raise IPAError("Bad sort field: %s" %(sortfield))

        if comparison == None or comparison == "overlaps":
            operator = "&&"
        elif comparison == "contains":
            operator = ">>="
        elif comparison == "is contained in":
            operator = "<<="
        else:
            raise IPAError("Bad comparison operator: %s" %(comparison))

        sql = """SELECT n.range AS range,
           (SELECT username FROM users WHERE id=n.creator_uid) AS creator_username,
           (SELECT displayname FROM users WHERE id=n.creator_uid) AS creator_displayname,
           n.ctime AS ctime,
           n.contents AS contents
           FROM note n
           WHERE
               CASE WHEN :range IS NULL THEN TRUE ELSE range %s :range END
               AND CASE WHEN :textsearch IS NULL THEN TRUE ELSE n.tsv @@ to_tsquery(:textsearch) END
            ORDER BY %s
            LIMIT :limit
            OFFSET :offset
            """ %(operator, orderby)

        #print sql

        try:
            rs = self.execute(sql, range=range, textsearch=textsearch, limit=limit, offset=offset)
        except Exception, e:
            #rs.close()
            raise IPARangeError(str(e))


        for row in rs:
            yield dict(zip(keys, row))
            
        #rs.close()

    def add_note(self, range, contents, creator):
        """
        Add a note for the given range
        """
        if not (range and contents and creator):
            raise IPAError("add_note called with invalid arguments")

        query = "select add_note(:range, :contents, :creator)"
        try:
            rs = self.execute(query, range=range, contents=contents, creator=creator)
        except Exception, e:
            raise IPAError(str(e))


    def add_assoc(self, dsid, addr, label=None, value=None, creator=None):
        """
        Add an IP association to the dataset
        """
        try:
            try:
                (begin, end) = addr
                rs = self.execute("SELECT add_assoc(:dsid, :begin::ip4, :end::ip4, :label, :value, :creator)",
                                       dsid=dsid, begin=begin, end=end, label=label, value=value, creator=creator )
            except ValueError:
                rs = self.execute("SELECT add_assoc(:dsid, lower(:addr::ip4r), upper(:addr::ip4r), :label, :value, :creator)",
                                       dsid=dsid, addr=addr, label=label, value=value, creator=creator )
        except Exception, e:
            raise IPARangeError(str(e))

# SELECT DISTINCT txid, ctime, username, COUNT(id) OVER () FROM audit_view
    def get_audit_log(self, limit=None, offset=None):

        keys = ["txid", "ctime", "username", "num",
                "num_ins", "num_upd", "num_del", "count"]

        orderby= "ORDER BY txid DESC"

        sql = """
        SELECT a.txid, MIN(a.ctime), a.username, SUM(a.num) AS num,
        SUM(CASE mod_type WHEN 'INSERT' THEN a.num ELSE 0 END) AS num_ins,
        SUM(CASE mod_type WHEN 'UPDATE' THEN a.num ELSE 0 END) AS num_upd,
        SUM(CASE mod_type WHEN 'DELETE' THEN a.num ELSE 0 END) AS num_del,
        COUNT(*) OVER() AS count
        FROM (
            SELECT txid, mod_type, MIN(ctime) AS ctime,
            username, COUNT(*)::integer AS num
            FROM audit_log GROUP BY txid, mod_type, username
        ) a
        GROUP by a.txid, a.username
        %s
        LIMIT :limit
        OFFSET :offset
        """ %(orderby)

        #print sql
        try:
            rs = self.execute(sql, limit=limit, offset=offset)
        except Exception, e:
            raise IPADatasetError, str(e)

        for row in rs:
            yield dict(zip(keys, row))

    def get_audit_detail(self, txid,
                         limit=None, offset=None,
                         sortfield="id", sortdir="asc"):

        keys = ["id", "ctime", "mod_type", "tablename",
                "field", "value_old", "value_new"]

        if sortfield == "id":
            orderby= "ORDER BY id %s" %(sortdir)
        elif sortfield == "tablename":
            orderby = "ORDER BY tablename %s, id ASC" %(sortdir)
        else:
            raise IPAError("Bad sort field: %s" %(sortfield))

        sql = """
        SELECT %s, COUNT(*) OVER() AS count
        FROM audit_log
        WHERE txid=:txid
        %s
        LIMIT :limit
        OFFSET :offset
        """ %(', '.join(keys), orderby)

        try:
            rs = self.execute(sql, txid=txid, limit=limit, offset=offset)
        except Exception, e:
            raise IPADatasetError, str(e)

        for row in rs:
            yield dict(zip(keys + ["count"], row))



##@}

