/*
 ** airdbc.c
 ** AirDBC Database Abstraction Layer
 **
 ** ------------------------------------------------------------------------
 ** Copyright (C) 2000-2005 Carnegie Mellon University. All Rights Reserved.
 ** ------------------------------------------------------------------------
 ** Authors: Brian Trammell <bht@cert.org>
 ** ------------------------------------------------------------------------
 ** From libair::db, by Brian Trammell, Roman Danyliw, and Sean Levy.
 ** ------------------------------------------------------------------------
 ** GNU Lesser GPL Rights pursuant to Version 2.1, February 1999
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
 ** ------------------------------------------------------------------------
 */

#include <airdbc/autoinc.h>
#include <airdbc/airdbc.h>
#include <airdbc/airdbc_drv.h>

static GSList *drivers = NULL;

/* Driver management */

void                adb_driver_register(
    AdbDriver           *driver)
{
    drivers = g_slist_prepend(drivers, driver);
}

static AdbDriver           *adb_driver_lookup(
    const char          *name)
{
    GSList              *td;

    for (td = drivers; td; td = td->next) {
        if (strcmp(name, ((AdbDriver *)td->data)->name) == 0) {
            return (AdbDriver *)td->data;
        }
    }
    return NULL;
}

static void         adb_driver_core_init()
{
    static gboolean core_done = FALSE;

    if (!core_done) {
#if HAVE_POSTGRESQL
        adb_pg_register();
#endif
#if HAVE_ORACLE_OCI
        adb_oci_register();
#endif
        core_done = TRUE;
    }
}

/* Connection management */

AdbConnection       *adb_conn_create(
    const char           *uri,
    GError              **err)
{
    AdbConnection       *conn = NULL;
    char                *cp   = NULL, *cp2 = NULL, *cp3 = NULL;

    /* Ensure core drivers are loaded */
    adb_driver_core_init();

    /* Allocate handle */
    conn = g_new0(AdbConnection, 1);

    /* Parse database URI */
    conn->uri_full  = g_strdup(uri);
    conn->uri_store = g_strdup(uri);
    cp              = conn->uri_store;

    /* Get scheme */
    if ((cp2 = strstr(cp, "://"))) {
        *cp2         = 0;
        conn->scheme = cp;
        cp           = cp2 + 3;
    } else {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_ARGUMENT,
                    "Malformed AirDBC URI: missing ://");
        goto err;
    }

    /* Get username and password if present */
    if ((cp2 = strchr(cp, '@'))) {
        *cp2 = 0;
        if ((cp3 = strchr(cp, ':'))) {
            /* Username and password present */
            *cp3           = 0;
            conn->password = cp3 + 1;
        } else {
            /* Only username present */
            conn->password = NULL;
        }
        conn->username = cp;
        cp             = cp2 + 1;
    } else {
        /* Neither username nor password present */
        conn->username = NULL;
        conn->password = NULL;
    }

    /* Get hostname and port */
    if ((cp2 = strchr(cp, '/'))) {
        *cp2 = 0;
        if ((cp3 = strchr(cp, ':'))) {
            /* Host and port present */
            *cp3 = 0;
            if (!sscanf(cp3 + 1, "%hu", &(conn->port))) {
                g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_ARGUMENT,
                            "Malformed AirDBC URI: garbage port %s",
                            cp3 + 1);
                goto err;
            }
        } else {
            /* Only host present */
            conn->port = 0;
        }
	if (cp != cp2) {
	   conn->host = cp;
	}
	else
	{
	    conn->host = NULL;
            conn->port = 0;
	}
        cp         = cp2 + 1;
    } else {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_ARGUMENT,
                    "Malformed AirDBC URI: missing database name");
        goto err;
    }

    /* Separate DB name from additional data */
    if ((cp2 = strchr(cp, '/'))) {
        *cp2             = 0;
        conn->additional = cp2 + 1;
    } else {
        conn->additional = NULL;
    }

    /* Stash database name */
    conn->dbname = cp;

    /* URI is parsed. Get driver based on scheme. */
    conn->driver = adb_driver_lookup(conn->scheme);
    if (!conn->driver) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_ARGUMENT,
                    "Malformed AirDBC URI: unsupported driver %s",
                    conn->scheme);
        goto err;
    }

    /* Do driver-specific (dctx) allocation */
    if (!conn->driver->alloc(conn, err)) goto err;

    /* All done */
    return conn;

  err:
    if (conn->uri_full) g_free(conn->uri_full);
    if (conn->uri_store) g_free(conn->uri_store);
    if (conn) g_free(conn);
    return NULL;
}

gboolean            adb_conn_open(
    AdbConnection        *conn,
    GError              **err)
{
    /* Reopen is a no-op. */
    if (conn->is_connected) return TRUE;

    /* Pass open down to driver */
    if (conn->driver->open(conn, err)) {
        conn->is_connected = TRUE;
        return TRUE;
    } else {
        return FALSE;
    }
}

gboolean            adb_conn_close(
    AdbConnection        *conn,
    GError              **err)
{
    /* Reclose is a no-op. */
    if (!(conn->is_connected)) return TRUE;

    /* Pass close down to driver */
    if (conn->driver->close(conn, err)) {
        conn->is_connected = FALSE;
        return TRUE;
    } else {
        return FALSE;
    }
}

gboolean            adb_conn_is_open(
    AdbConnection       *conn)
{
    return conn->is_connected;
}

void                adb_conn_free(
    AdbConnection       *conn)
{
    /* Force closed if connected */
    if (conn->is_connected) {
        GError          *err = NULL;
        if (!adb_conn_close(conn, &err)) {
            g_warning("Forced close on free failed: %s", err->message);
            g_clear_error(&err);
        }
    }

    /* Pass free down to driver */
    conn->driver->free(conn);

    /* Free connection itself */
    g_free(conn->uri_store);
    g_free(conn);
}

gboolean            adb_transaction_begin(
    AdbConnection        *conn,
    GError              **err)
{
    return conn->driver->begin(conn, err);
}

gboolean            adb_transaction_commit(
    AdbConnection        *conn,
    GError              **err)
{
    return conn->driver->commit(conn, err);
}

gboolean            adb_transaction_rollback(
    AdbConnection        *conn,
    GError              **err)
{
    return conn->driver->rollback(conn, err);
}

AdbStatement        *adb_stmt_prepare(
    AdbConnection        *conn,
    char                 *sql,
    uint32_t              param_maxlen,
    GError              **err)
{
    char                    *cp      = NULL;
    AdbStatement            *stmt    = NULL;
    GString                 *pn      = NULL, *resql = NULL;
    GSList                  *poslist = NULL;
    enum {  ADB_PREP_INIT,
            ADB_PREP_SQ0,
            ADB_PREP_SQ1,
            ADB_PREP_DQ,
            ADB_PREP_PARAM } state = ADB_PREP_INIT;

    /* Allocate statement */
    stmt            = g_new0(AdbStatement, 1);
    stmt->conn      = conn;
    stmt->param_map = g_hash_table_new_full(g_str_hash, g_str_equal,
                                            g_free, NULL);

    /* Rewrite parameters and build parameter map */
    resql = g_string_new("");
    pn    = g_string_new("");
    for (cp = sql; *cp; cp++) {
        switch (state) {
          case ADB_PREP_INIT:
            if (*cp == '\'') {
                state = ADB_PREP_SQ0;
            } else if (*cp == '"') {
                state = ADB_PREP_DQ;
            } else if (*cp == ':') {
                /* Check to make sure colon isn't part of a PostgreSQL-style
                 * cast.  If it is, pass it along without parameter
                 * substitution */
                if (*(cp+1) == ':' || *(cp-1) == ':') {
                    g_string_append_c(resql, *cp);
                } else {
                    g_string_truncate(pn, 0);
                    state = ADB_PREP_PARAM;
                }
                break;
            }
            g_string_append_c(resql, *cp);
            break;
          case ADB_PREP_SQ0:
            if (*cp == '\'') {
                state = ADB_PREP_SQ1;
            }
            g_string_append_c(resql, *cp);
            break;
          case ADB_PREP_SQ1:
            if (*cp == '\'') {
                state = ADB_PREP_SQ0;
            } else { state = ADB_PREP_INIT; }
            g_string_append_c(resql, *cp);
            break;
          case ADB_PREP_DQ:
            if (*cp == '"') {
                state = ADB_PREP_INIT;
            }
            g_string_append_c(resql, *cp);
            break;
          case ADB_PREP_PARAM:
            if (!g_ascii_isalnum(*cp) || (!*(cp+1))) {
                state = ADB_PREP_INIT;
                /* End of parameter name. Add parameter to map. */
                poslist = g_hash_table_lookup(stmt->param_map, pn->str);
                if (poslist) poslist = g_slist_copy(poslist);
                poslist = g_slist_prepend(poslist,
                                          GUINT_TO_POINTER(stmt->param_count));
                g_hash_table_insert(stmt->param_map, g_strdup(
                                        pn->str), poslist);
                /* Advance position */
                (stmt->param_count)++;
                /* Emit native parameter placeholder. */
                g_string_append_printf(resql, "%s",
                                       conn->driver->param_prefix);
                if (conn->driver->param_numsuffix) {
                    g_string_append_printf(resql, "%u",
                                           stmt->param_count);
                }
                if (!g_ascii_isalnum(*cp)) {
                    g_string_append_c(resql, *cp);
                }
            } else {
                /* In parameter name. Continue building current parameter. */
                g_string_append_c(pn, *cp);
            }
            break;
          default:
            g_assert_not_reached();
        }
    }

    /* Default parameter size */
    if (!param_maxlen) param_maxlen = 255;
    stmt->param_maxlen = param_maxlen;

    /* Allocate parameter string buffer and pointers */
    if (stmt->param_count) {
        stmt->param_buf = g_new0(char, stmt->param_count * stmt->param_maxlen);
        stmt->param_str = g_new0(char *, stmt->param_count);
    }

    /* Stash processed SQL */
    stmt->sql = resql->str;

    /* Free strings */
    g_string_free(pn, TRUE);
    g_string_free(resql, FALSE);

    /* Pass prepare down to driver */
    if (conn->driver->prepare(stmt, err)) {
        return stmt;
    } else {
        if (stmt->sql) g_free(stmt->sql);
        if (stmt->param_map) g_hash_table_destroy(stmt->param_map);
        if (stmt->param_buf) g_free(stmt->param_buf);
        if (stmt->param_str) g_free(stmt->param_str);
        g_free(stmt);
        return NULL;
    }
}

void                adb_stmt_free(
    AdbStatement        *stmt)
{
    /* Pass free down to driver */
    stmt->conn->driver->free_stmt(stmt);

    /* Free statement itself */
    g_free(stmt->sql);
    g_hash_table_destroy(stmt->param_map);
    g_free(stmt->param_str);
    g_free(stmt->param_buf);
    g_free(stmt);
}

gboolean            adb_stmt_bind(
    AdbStatement         *stmt,
    uint32_t              pos,
    const char           *val,
    GError              **err)
{
    /* Range check */
    if (pos >= stmt->param_count) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "Parameter %u out of range", pos);
        return FALSE;
    }

    /* Copy and set parameter */
    if (val) {
        stmt->param_str[pos] = stmt->param_buf + (stmt->param_maxlen * pos);
        if (g_strlcpy(stmt->param_str[pos], val,
                      stmt->param_maxlen) >= stmt->param_maxlen)
        {
            g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                        "Parameter %u truncated", pos);
            return FALSE;
        }
    } else {
        stmt->param_str[pos] = NULL;
    }

    /* Done */
    return TRUE;
}

gboolean            adb_stmt_bind_named(
    AdbStatement         *stmt,
    const char           *name,
    const char           *val,
    GError              **err)
{
    GSList              *poslist = NULL;

    /* Get position list for name */
    poslist = g_hash_table_lookup(stmt->param_map, name);
    if (!poslist) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "No such parameter %s", name);
        return FALSE;
    }

    /* Bind type and pointer to each position in the list */
    for (; poslist; poslist = g_slist_next(poslist)) {
        g_assert(adb_stmt_bind(stmt, GPOINTER_TO_UINT(poslist->data),
                               val, NULL));
    }

    return TRUE;
}

gboolean            adb_stmt_execute(
    AdbStatement         *stmt,
    GError              **err)
{
    return stmt->conn->driver->exec(stmt, err);
}

AdbResultSet        *adb_stmt_query(
    AdbStatement         *stmt,
    GError              **err)
{
    AdbResultSet        *rs = NULL;

    /* Allocate result set */
    rs       = g_new0(AdbResultSet, 1);
    rs->stmt = stmt;

    /* Pass query down to driver */
    if (stmt->conn->driver->query(rs, err)) {
        return rs;
    } else {
        g_free(rs);
        return NULL;
    }
}

void                adb_rs_free(
    AdbResultSet        *rs)
{
    rs->stmt->conn->driver->free_rs(rs);
    g_free(rs);
}

gboolean            adb_rs_next(
    AdbResultSet         *rs,
    GError              **err)
{
    return rs->stmt->conn->driver->next(rs, err);
}

uint32_t            adb_rs_row_count(
    AdbResultSet *rs,
    GError      **err)
{
    return rs->stmt->conn->driver->rowcount(rs, err);
}

uint32_t            adb_rs_column_count(
    AdbResultSet         *rs,
    GError              **err)
{
    return rs->stmt->conn->driver->colcount(rs, err);
}


uint32_t            adb_rs_field_width(
    AdbResultSet *rs,
    uint32_t      row,
    uint32_t      col,
    GError      **err)
{
    return rs->stmt->conn->driver->fieldwidth(rs, row, col, err);
}


char                *adb_rs_column_name(
    AdbResultSet         *rs,
    uint32_t              col,
    GError              **err)
{
    return rs->stmt->conn->driver->colname(rs, col, err);
}

char                *adb_rs_column_type(
    AdbResultSet         *rs,
    uint32_t              col,
    GError              **err)
{
    return rs->stmt->conn->driver->colname(rs, col, err);
}

gboolean            adb_rs_fetch(
    AdbResultSet         *rs,
    uint32_t              col,
    const char          **val,
    GError              **err)
{
    return rs->stmt->conn->driver->fetch(rs, col, val, err);
}

gboolean            adb_rs_fetch_buf(
    AdbResultSet         *rs,
    uint32_t              col,
    const char           *buf,
    size_t                len,
    GError              **err)
{
    return rs->stmt->conn->driver->fetch_buf(rs, col, buf, len, err);
}

gboolean            adb_rs_fetch_named(
    AdbResultSet         *rs,
    const char           *name,
    const char          **val,
    GError              **err)
{
    uint32_t             col;
    void                *ignored;

    /* Build column name map if necessary */
    if (!rs->colname_map) {
        uint32_t             colcount, i;
        char                *colname = NULL;
        if (!(colcount = adb_rs_column_count(rs, err))) goto cmerr;
        rs->colname_map = g_hash_table_new(g_str_hash, g_str_equal);
        for (i = 0; i < colcount; i++) {
            if (!(colname = adb_rs_column_name(rs, i, err))) goto cmerr;
            g_hash_table_insert(rs->colname_map, colname, GUINT_TO_POINTER(i));
        }
    }

    /* Do lookup */
    if (!g_hash_table_lookup_extended(rs->colname_map, name,
                                      &ignored, (void **)&col))
    {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "No such column %s", name);
        return FALSE;
    }

    /* Do fetch */
    return adb_rs_fetch(rs, col, val, err);

  cmerr:
    if (rs->colname_map) g_hash_table_destroy(rs->colname_map);
    rs->colname_map = NULL;
    return FALSE;
}
