/*
 ** drv_pg.c
 ** AirDBC PostgreSQL driver
 **
 ** ------------------------------------------------------------------------
 ** Copyright (C) 2000-2005 Carnegie Mellon University. All Rights Reserved.
 ** ------------------------------------------------------------------------
 ** Authors: Brian Trammell <bht@cert.org>
 ** ------------------------------------------------------------------------
 ** From libair::db, by Brian Trammell, Roman Danyliw, and Sean Levy.
 ** ------------------------------------------------------------------------
 ** GNU Lesser GPL Rights pursuant to Version 2.1, February 1999
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
 ** ------------------------------------------------------------------------
 */

#include <airdbc/autoinc.h>

#if HAVE_POSTGRESQL

#include <airdbc/airdbc.h>
#include <airdbc/airdbc_drv.h>
#include <libpq-fe.h>

#define ADB_PG_PORT 5432

/* Statement identity generator. */

typedef struct _AdbPgConnCtx {
    PGconn              *pgconn;
} AdbPgConnCtx;

typedef struct _AdbPgStmtCtx {
    char                *name;
} AdbPgStmtCtx;

typedef struct _AdbPgRsCtx {
    PGresult            *result;
    int32_t              row;
    uint32_t             colcount;
    uint32_t             rowcount;
} AdbPgRsCtx;

static gboolean     adb_pg_verify_cmd(
    PGresult             *esr,
    AdbConnection        *conn,
    gboolean              rsfree,
    const char           *msg,
    const char           *sqlstr,
    GError              **err)
{
    gboolean             ok = TRUE;
    const char          *errmsg;
    ExecStatusType       ess;

    /* get result status */
    if (esr) {
        ess    = PQresultStatus(esr);
        errmsg = PQresultErrorMessage(esr);
    } else {
        errmsg = PQerrorMessage(((AdbPgConnCtx *)(conn->dconn))->pgconn);
    }

    /* report error as appropriate */
    if (!esr || ((ess != PGRES_COMMAND_OK) && (ess != PGRES_TUPLES_OK))) {
        ok = FALSE;
        if (sqlstr) {
            g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RDBMS,
                        "%s: %s [stmt: %s]", msg, errmsg, sqlstr);
        } else {
            g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RDBMS,
                        "%s: %s", msg, errmsg);
        }
        if (PQstatus(((AdbPgConnCtx *)conn->dconn)->pgconn)
            == CONNECTION_BAD)
        {
            adb_conn_close(conn, NULL);
        }
    }

    /* clean up after result unless we might need it. */
    if (esr && rsfree) PQclear(esr);

    return ok;
}

static gboolean     adb_pg_alloc(
    AdbConnection        *conn,
    GError              **err)
{
    AdbPgConnCtx        *dconn = NULL;

    /* Allocate a PostgreSQL connection context */
    conn->dconn = g_new0(AdbPgConnCtx, 1);
    dconn       = (AdbPgConnCtx *)conn->dconn;

    /* Fill it in */
    dconn->pgconn = NULL;

    /* Default port */
    if (!conn->port) conn->port = ADB_PG_PORT;

    /* All done. */
    return TRUE;
}

static gboolean     adb_pg_open(
    AdbConnection        *conn,
    GError              **err)
{
    AdbPgConnCtx        *dconn    = (AdbPgConnCtx *)conn->dconn;
    GString             *conninfo = NULL;
    gboolean             ok       = TRUE;

    /* Construct a conninfo string */
    conninfo = g_string_new("");

    if (conn->host)
    {
        g_string_append_printf(conninfo, " host=%s", conn->host);
    }
    if (conn->port)
    {
        g_string_append_printf(conninfo, " port=%d", conn->port);
    }
    if (conn->dbname)
    {
        g_string_append_printf(conninfo, " dbname=%s", conn->dbname);
    }

    if (conn->username) {
        g_string_append_printf(conninfo, " user=%s", conn->username);
    }

    if (conn->password) {
        g_string_append_printf(conninfo, " password=%s", conn->password);
    }

    /* Attempt to connect to the database */
    dconn->pgconn = PQconnectdb(conninfo->str);
    if (dconn->pgconn) {
        if (PQstatus(dconn->pgconn) != CONNECTION_OK) {
            g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_CONNECT,
                        "Couldn't connect to %s: %s", conn->uri_full,
                        PQerrorMessage(dconn->pgconn));
            PQfinish(dconn->pgconn);
            dconn->pgconn = NULL;
            ok            = FALSE;
        }
    } else {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_CONNECT,
                    "Couldn't connect to %s: null connection",
                    conn->uri_full);
        ok = FALSE;
    }

    /* All done */
    if (conninfo) g_string_free(conninfo, TRUE);
    return ok;
}

static gboolean  adb_pg_close(
    AdbConnection        *conn,
    GError              **err)
{
    AdbPgConnCtx        *dconn = (AdbPgConnCtx *)conn->dconn;

    PQfinish(dconn->pgconn);
    dconn->pgconn = NULL;
    return TRUE;
}

static void         adb_pg_free(
    AdbConnection       *conn)
{
    g_free(conn->dconn);
    conn->dconn = NULL;
}

static gboolean     adb_pg_begin(
    AdbConnection        *conn,
    GError              **err)
{
    AdbPgConnCtx        *dconn = (AdbPgConnCtx *)conn->dconn;

    return adb_pg_verify_cmd(PQexec(dconn->pgconn, "BEGIN"),
                             conn, TRUE, "Transation start failed", NULL, err);
}

static gboolean     adb_pg_commit(
    AdbConnection        *conn,
    GError              **err)
{
    AdbPgConnCtx        *dconn = (AdbPgConnCtx *)conn->dconn;

    return adb_pg_verify_cmd(PQexec(dconn->pgconn, "COMMIT"),
                             conn, TRUE, "Transation end failed", NULL, err);
}

static gboolean     adb_pg_rollback(
    AdbConnection        *conn,
    GError              **err)
{
    AdbPgConnCtx        *dconn = (AdbPgConnCtx *)conn->dconn;

    return adb_pg_verify_cmd(PQexec(dconn->pgconn, "ROLLBACK"),
                             conn, TRUE, "Transation end failed", NULL, err);
}

static gboolean     adb_pg_prepare(
    AdbStatement         *stmt,
    GError              **err)
{
    AdbPgConnCtx        *dconn = (AdbPgConnCtx *)stmt->conn->dconn;
    AdbPgStmtCtx        *dstmt = NULL;
    GString             *name  = NULL;

    /* Allocate statement context */
    stmt->dstmt = g_new0(AdbPgStmtCtx, 1);
    dstmt       = (AdbPgStmtCtx *)stmt->dstmt;

    /* Generate a statement name based on the statement pointer */
    name = g_string_new("");
    g_string_sprintf(name, "adbpg%08x", (uint32_t)stmt);
    dstmt->name = name->str;
    g_string_free(name, FALSE);

    /* Prepare statement */
    if (!adb_pg_verify_cmd(PQprepare(dconn->pgconn, dstmt->name,
                                     stmt->sql, 0, NULL),
                           stmt->conn, TRUE,
                           "Error preparing statement", stmt->sql, err))
    {
        /* Prep failed; free statement context */
        g_free(dstmt->name);
        g_free(dstmt);
        return FALSE;
    }

    return TRUE;
}

static void         adb_pg_free_stmt(
    AdbStatement        *stmt)
{
    AdbPgConnCtx        *dconn      = (AdbPgConnCtx *)stmt->conn->dconn;
    AdbPgStmtCtx        *dstmt      = (AdbPgStmtCtx *)stmt->dstmt;
    GString             *sqldealloc = NULL;
    GError              *err        = NULL;

    /* Use SQL DEALLOCATE command to free statement on server side */
    sqldealloc = g_string_new("");
    g_string_sprintf(sqldealloc, "DEALLOCATE \"%s\"", dstmt->name);
    if (!adb_pg_verify_cmd(PQexec(dconn->pgconn, sqldealloc->str),
                           stmt->conn, TRUE,
                           "Statement DEALLOCATE falied", stmt->sql, &err))
    {
        g_warning("%s", err->message);
        g_clear_error(&err);
    }
    g_string_free(sqldealloc, TRUE);

    /* Deallocate statement on client side */
    g_free(dstmt->name);
    g_free(dstmt);
    stmt->dstmt = NULL;
}

static gboolean     adb_pg_execute(
    AdbStatement         *stmt,
    GError              **err)
{
    AdbPgConnCtx        *dconn = (AdbPgConnCtx *)stmt->conn->dconn;
    AdbPgStmtCtx        *dstmt = (AdbPgStmtCtx *)stmt->dstmt;

    return adb_pg_verify_cmd(PQexecPrepared(dconn->pgconn, dstmt->name,
                                            stmt->param_count,
                                            (const char **)stmt->param_str,
                                            NULL, NULL, 0),
                             stmt->conn, TRUE,
                             "Statement execution failed", stmt->sql, err);
}

static gboolean     adb_pg_query(
    AdbResultSet         *rs,
    GError              **err)
{
    AdbPgConnCtx        *dconn = (AdbPgConnCtx *)rs->stmt->conn->dconn;
    AdbPgStmtCtx        *dstmt = (AdbPgStmtCtx *)rs->stmt->dstmt;
    AdbPgRsCtx          *drs   = NULL;

    /* Allocate result set context */
    rs->drs = g_new0(AdbPgRsCtx, 1);
    drs     = (AdbPgRsCtx *)rs->drs;

    drs->result = PQexecPrepared(dconn->pgconn, dstmt->name,
                                 rs->stmt->param_count,
                                 (const char **)rs->stmt->param_str,
                                 NULL, NULL, 0);
    if (!adb_pg_verify_cmd(drs->result, rs->stmt->conn, FALSE,
                           "Query execution failed", rs->stmt->sql, err))
    {
        g_free(rs->drs);
        rs->drs = NULL;
        return FALSE;
    }

    /* Store result set metainformation */
    drs->rowcount = PQntuples(drs->result);
    drs->colcount = PQnfields(drs->result);
    drs->row      = -1;
    return TRUE;
}

static void         adb_pg_free_rs(
    AdbResultSet        *rs)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;

    PQclear(drs->result);
    g_free(drs);
    rs->drs = NULL;
}

static gboolean     adb_pg_next(
    AdbResultSet         *rs,
    GError              **err)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;

    if (++ (drs->row) >= drs->rowcount) {
        drs->row = drs->rowcount;
        return FALSE;
    } else {
        return TRUE;
    }
}

static uint32_t     adb_pg_rowcount(
                                    AdbResultSet         *rs,
                                    GError              **err)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;
    
    return drs->rowcount;
}

static uint32_t     adb_pg_colcount(
    AdbResultSet         *rs,
    GError              **err)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;

    return drs->colcount;
}


static uint32_t adb_pg_fieldwidth(
    AdbResultSet *rs,
    uint32_t      row,
    uint32_t      col,
    GError      **err)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;

    return PQgetlength( drs->result, row, col );
}
                                   
static char         *adb_pg_colname(
    AdbResultSet         *rs,
    uint32_t              col,
    GError              **err)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;

    return PQfname(drs->result, col);
}

static gboolean     adb_pg_fetch(
    AdbResultSet         *rs,
    uint32_t              col,
    const char          **val,
    GError              **err)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;

    if (drs->row >= drs->rowcount) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "At end of result set");
        return FALSE;
    }

    if (col >= drs->colcount) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "Column %u out of range", col);
        return FALSE;
    }

    *val = PQgetvalue(drs->result, drs->row, col);
    return TRUE;
}


static gboolean     adb_pg_fetch_buf(
    AdbResultSet         *rs,
    uint32_t              col,
    char                 *buf,
    size_t                len,
    GError              **err)
{
    AdbPgRsCtx          *drs = (AdbPgRsCtx *)rs->drs;

    if (drs->row >= drs->rowcount) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "At end of result set");
        return FALSE;
    }

    if (col >= drs->colcount) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "Column %u out of range", col);
        return FALSE;
    }

    g_strlcpy(buf, PQgetvalue(drs->result, drs->row, col), len);
    return TRUE;
}


static AdbDriver adb_pg_driver = {
    "postgresql",
    "$",              TRUE, /* Prepared statement parameters look like $n */
    adb_pg_alloc,
    adb_pg_open,
    adb_pg_close,
    adb_pg_free,
    adb_pg_begin,
    adb_pg_commit,
    adb_pg_rollback,
    adb_pg_prepare,
    adb_pg_free_stmt,
    adb_pg_execute,
    adb_pg_query,
    adb_pg_free_rs,
    adb_pg_next,
    adb_pg_rowcount,
    adb_pg_colcount,
    adb_pg_fieldwidth,
    adb_pg_colname,
    adb_pg_fetch,
    adb_pg_fetch_buf
};

void adb_pg_register()
{
    adb_driver_register(&adb_pg_driver);
}

#else

void adb_pg_register()
{
    g_assert_not_reached();
}

#endif




