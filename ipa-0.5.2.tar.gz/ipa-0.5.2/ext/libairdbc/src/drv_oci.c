/*
 ** drv_oci.c
 ** AirDBC Oracle Call Interface driver
 **
 ** ------------------------------------------------------------------------
 ** Copyright (C) 2000-2005 Carnegie Mellon University. All Rights Reserved.
 ** ------------------------------------------------------------------------
 ** Authors: Brian Trammell <bht@cert.org>
 ** ------------------------------------------------------------------------
 ** Since I wrote the original abomination that was this driver, I'm taking
 ** all the credit myself - bht 2005-11-11
 ** ------------------------------------------------------------------------
 ** GNU Lesser GPL Rights pursuant to Version 2.1, February 1999 
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
 ** ------------------------------------------------------------------------
 */
 
#include <airdbc/autoinc.h>

#if HAVE_ORACLE_OCI

#include <airdbc/airdbc.h>
#include <airdbc/airdbc_drv.h>
#include <oci.h>

typedef struct _AdbOciConnCtx {
    OCIEnv          *env;
    OCISvcCtx       *svc;
    OCIServer       *svr;
    OCIError        *err;
} AdbOciConnCtx;

typedef struct _AdbOciStmtCtx {
    OCIStmt         *stmt;
    OCIBind         **bha;
    int16_t         *iva;
} AdbOciStmtCtx;

typedef struct _AdbOciRsCtx {
    gboolean        row_valid;
    uint32_t        colcount;
    OCIDefine       **dha;
    int16_t         *iva;
    char            *dbuf;
} AdbOciRsCtx;

#define ADB_OCI_EBUF_SZ 1024
#define ADB_OCI_TRANS_TIMEOUT 60

static gboolean     adb_oci_v(
    int32_t             status,
    const char          *message,
    AdbConnection       *conn,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)conn->dconn;
    uint32_t            cstat = OCI_SERVER_NORMAL;
    int32_t             ecode = 0;
    int32_t             estat = 0;
    char                ebuf[ADB_OCI_EBUF_SZ];
    
    if (status == OCI_SUCCESS) {
        return TRUE;
    } else if (status == OCI_NO_DATA) {
        return FALSE;
    } else {
        /* get error from environment */
        if ((estat = OCIErrorGet(dconn->err, 1, NULL, &ecode, ebuf, 
                                 ADB_OCI_EBUF_SZ, OCI_HTYPE_ERROR)) 
                   == OCI_SUCCESS) {
            g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RDBMS,
                        "Error %s: %s", message, ebuf);
        } else {
            g_critical("GetError failed on status %d: %d", status, estat);
        }
        /* check for connection termination */
        if (dconn->svr) {
            if (OCIAttrGet(dconn->svr, OCI_HTYPE_SERVER, 
                           &cstat, NULL, OCI_ATTR_SERVER_STATUS, 
                           dconn->err) != OCI_SUCCESS) {
                if ((estat = OCIErrorGet(dconn->err, 1, NULL, &ecode, ebuf, 
                                         ADB_OCI_EBUF_SZ, OCI_HTYPE_ERROR))
                           == OCI_SUCCESS) {
                    g_critical("Connection check failed: %s", ebuf);
                } else {
                    g_critical("GetError failed on connection check fail: %d", 
                               estat);
                }
            }
            if (cstat == OCI_SERVER_NOT_CONNECTED) {
                adb_conn_close(conn, NULL);
            }
        }
        return FALSE;
    }
}

static gboolean     adb_oci_vh(
    int32_t             status,
    const char          *message,
    AdbConnection       *conn,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)conn->dconn;
    int32_t             ecode;
    char                ebuf[ADB_OCI_EBUF_SZ];
    
    if (status == OCI_SUCCESS) {
        return TRUE;
    } else {
        OCIErrorGet(dconn->env, 1, NULL, &ecode, ebuf, 
                    ADB_OCI_EBUF_SZ, OCI_HTYPE_ENV);
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_CONNECT,
                    "Error %s: %s", message, ebuf);
        return FALSE;
    }
}

static gboolean     adb_oci_alloc(
    AdbConnection       *conn,
    GError              **err)
{
    AdbOciConnCtx       *dconn = NULL;

    /* Check for ORACLE_HOME, without which this is not even academic */
    if (!g_getenv("ORACLE_HOME")) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_CONNECT,
                    "Missing ORACLE_HOME environment variable.");
        return FALSE;
    }
    
    /* Allocate an OCI driver connection context */
    conn->dconn = g_new0(AdbOciConnCtx, 1);
    dconn = (AdbOciConnCtx *)conn->dconn;
    
    /* Allocate an OCI environment handle */
    if (!adb_oci_vh(OCIEnvCreate(&(dconn->env), OCI_DEFAULT, 
                                 NULL, NULL, NULL, NULL, 0, NULL),
                    "creating environment handle", conn, err))
        goto err;
        
    /* Allocate an OCI error handle */
    if (!adb_oci_vh(OCIHandleAlloc(dconn->env, (void **)&(dconn->err),
                                   OCI_HTYPE_ERROR, 0, NULL),
                    "creating error handle", conn, err))
        goto err;
    
    /* All done. */
    return TRUE;
    
  err:
    if (dconn) {
        if (dconn->err) OCIHandleFree(dconn->err, OCI_HTYPE_ERROR);
        if (dconn->env) OCIHandleFree(dconn->env, OCI_HTYPE_ENV);
        g_free(dconn);
        conn->dconn = NULL;
    }
    return FALSE;
}

static gboolean     adb_oci_open(
    AdbConnection       *conn,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)conn->dconn;
    
    /* Create service context for connection */
    if (!adb_oci_v(OCILogon(dconn->env, dconn->err, &(dconn->svc),
                            conn->username, strlen(conn->username),
                            conn->password, strlen(conn->password),
                            conn->dbname, strlen(conn->dbname)),
                   "connecting", conn, err))
        return FALSE;
        
    /* Get server handle (for connection restart) */
    if (!adb_oci_v(OCIAttrGet(dconn->svc, OCI_HTYPE_SVCCTX,
                              &(dconn->svr), NULL, OCI_ATTR_SERVER,
                              dconn->err),
                   "retrieving server handle on connect", conn, err)) {
        /* Since we have no server handle, we'll have to manually log off */
        OCILogoff(dconn->svc, dconn->err);
        dconn->svc = NULL;
        dconn->svr = NULL;
        return FALSE;
    }
    
    return TRUE;
}

static gboolean     adb_oci_close(
    AdbConnection       *conn,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)conn->dconn;
    gboolean            ok = TRUE;
    
    /* Lose server handle so we won't try to restart on close */
    dconn->svr = NULL;
    
    /* Close connection */
    ok = adb_oci_v(OCILogoff(dconn->svc, dconn->err), 
                   "disconnecting", conn, err);
    dconn->svc = NULL;
    return ok;
}

static void         adb_oci_free(
    AdbConnection       *conn)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)conn->dconn;

    OCIHandleFree(dconn->err, OCI_HTYPE_ERROR);
    OCIHandleFree(dconn->env, OCI_HTYPE_ENV);
    g_free(dconn);
    conn->dconn = NULL;
}

static gboolean     adb_oci_begin(
    AdbConnection       *conn,
    GError              **err)
{
    /* This is a no-op, because simple local transaction start is implicit. */
    return TRUE;
}

static gboolean     adb_oci_commit(
    AdbConnection       *conn,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)conn->dconn;

    return adb_oci_v(OCITransCommit(dconn->svc, dconn->err,
                                    OCI_DEFAULT),
                     "committing", conn, err);
}

static gboolean     adb_oci_rollback(
    AdbConnection       *conn,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)conn->dconn;

    return adb_oci_v(OCITransRollback(dconn->svc, dconn->err,
                                      OCI_DEFAULT),
                     "rolling back", conn, err);
}

static gboolean     adb_oci_prepare(
    AdbStatement        *stmt,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)stmt->conn->dconn;
    AdbOciStmtCtx       *dstmt = NULL;
    char                *param_ptr;
    uint32_t            i;
        
    /* Allocate statement context */
    stmt->dstmt = g_new0(AdbOciStmtCtx, 1);
    dstmt = (AdbOciStmtCtx *)stmt->dstmt;

    /* Allocate bind handle array */
    dstmt->bha = g_new0(OCIBind *, stmt->param_count);
    
    /* Allocate indicator variable array */
    dstmt->iva = g_new0(uint16_t, stmt->param_count);

    /* Allocate statement handle */
    if (!adb_oci_v(OCIHandleAlloc(dconn->env, (void **)&(dstmt->stmt),
                                  OCI_HTYPE_STMT, 0, NULL),
                   "allocating statement handle", stmt->conn, err)) 
        goto err;

    /* Prepare statement */
    if (!adb_oci_v(OCIStmtPrepare(dstmt->stmt, dconn->err, 
                                  stmt->sql, strlen(stmt->sql),
                                  OCI_NTV_SYNTAX, OCI_DEFAULT),
                   "preparing statement", stmt->conn, err)) 
        goto err;
    
    /* Bind statement parameter buffer locations */
    for (i = 0; i < stmt->param_count; i++) {
        param_ptr = stmt->param_buf + (i * stmt->param_maxlen);
        if (!adb_oci_v(OCIBindByPos(dstmt->stmt, &(dstmt->bha[i]), dconn->err,
                                    i+1, param_ptr, stmt->param_maxlen, 
                                    SQLT_STR, &(dstmt->iva[i]), 
                                    NULL, NULL, 0, 0, OCI_DEFAULT),
                        "binding statement parameter", stmt->conn, err)) 
            goto err;
    }
    
    /* Done. */
    return TRUE;

  err:
    /* Error. Clean up. */
    if (stmt->dstmt) {
        if (dstmt->bha) {
            for (i = 0; i < stmt->param_count; i++) {
                OCIHandleFree(dstmt->bha[i], OCI_HTYPE_BIND);
            }
            g_free(dstmt->bha);
        }
        if (dstmt->iva) g_free(dstmt->iva);
        if (dstmt->stmt) OCIHandleFree(dstmt->stmt, OCI_HTYPE_STMT);
        g_free(stmt->dstmt);
        stmt->dstmt = NULL;
    }
    return FALSE;
}

static void         adb_oci_free_stmt(
    AdbStatement        *stmt)
{
    AdbOciStmtCtx       *dstmt = (AdbOciStmtCtx *)stmt->dstmt;
    uint32_t            i;

    for (i = 0; i < stmt->param_count; i++) {
        OCIHandleFree(dstmt->bha[i], OCI_HTYPE_BIND);
    }
    g_free(dstmt->bha);
    g_free(dstmt->iva);
    OCIHandleFree(dstmt->stmt, OCI_HTYPE_STMT);
    g_free(stmt->dstmt);
    stmt->dstmt = NULL;
}

static gboolean     adb_oci_execute(
    AdbStatement        *stmt,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)stmt->conn->dconn;
    AdbOciStmtCtx       *dstmt = (AdbOciStmtCtx *)stmt->dstmt;
    uint32_t            i;
    
    /* Prepare statement indicator variables */
    for (i = 0; i < stmt->param_count; i++) {
        dstmt->iva[i] = stmt->param_str ? 1 : -1;
    }
    
    /* Execute the statement - we don't care about results */
    return adb_oci_v(OCIStmtExecute(dconn->svc, dstmt->stmt, dconn->err, 
                                    1, 0, NULL, NULL, OCI_DEFAULT),
                     "executing statement", stmt->conn, err);
}

static gboolean     adb_oci_query(
    AdbResultSet        *rs,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)rs->stmt->conn->dconn;
    AdbOciStmtCtx       *dstmt = (AdbOciStmtCtx *)rs->stmt->dstmt;
    AdbOciRsCtx         *drs = NULL;
    uint32_t            i = 0;
    char                *dbufi = NULL;
    
    /* Allocate result set context */
    rs->drs = g_new0(AdbOciRsCtx, 1);
    drs = (AdbOciRsCtx *)rs->drs;

    /* Prepare statement indicator variables */
    for (i = 0; i < rs->stmt->param_count; i++) {
        dstmt->iva[i] = rs->stmt->param_str[i] ? 1 : -1;
    }

    /* Execute the statement */
    if (!adb_oci_v(OCIStmtExecute(dconn->svc, dstmt->stmt, dconn->err, 
                                    0, 0, NULL, NULL, 
                                    OCI_STMT_SCROLLABLE_READONLY),
                   "executing query", rs->stmt->conn, err)) 
        goto err;
    
    /* Get column count */
    if (!adb_oci_v(OCIAttrGet(dstmt->stmt, OCI_HTYPE_STMT, 
                              &(drs->colcount), NULL,
                              OCI_ATTR_PARAM_COUNT, dconn->err),
                   "counting result columns", rs->stmt->conn, err)) 
        goto err;
    
    /* Allocate a bunch of needlessly obtuse OCI crap for magically
       divining the values of result set columns... */
    /* define handle array (define is not an adjectivable noun!) */
    drs->dha = g_new0(OCIDefine *, drs->colcount);
    /* indicator variable array */
    drs->iva = g_new0(int16_t, drs->colcount);
    /* define buffer */
    drs->dbuf = g_new0(char, drs->colcount * rs->stmt->param_maxlen);
    
    /* Define the executed statement */
    for (i = 0; i < drs->colcount; i++) {
        dbufi = drs->dbuf + (i * rs->stmt->param_maxlen);
        if (!adb_oci_v(OCIDefineByPos(dstmt->stmt, &(drs->dha[i]), dconn->err,
                                      i+1, dbufi, rs->stmt->param_maxlen,
                                      SQLT_STR, &(drs->iva[i]), NULL, NULL,
                                      OCI_DEFAULT),
                        "defining result set column", rs->stmt->conn, err)) 
            goto err;
    }
    
    /* Set valid flag */
    drs->row_valid = TRUE;

    /* All done */
    return TRUE;
    
  err:
    /* Clean up after error */
    if (rs->drs) {
        if (drs->dha) {
            for (i = 0; i < drs->colcount; i++) {
                OCIHandleFree(drs->dha[i], OCI_HTYPE_DEFINE);
            }
            g_free(drs->dha);
        }
        if (drs->dbuf) g_free(drs->dbuf);
        if (drs->iva) g_free(drs->iva);
        g_free(rs->drs);
        rs->drs = NULL;
    }
    return FALSE;
}

static void         adb_oci_free_rs(
    AdbResultSet        *rs)
{
    AdbOciRsCtx         *drs = (AdbOciRsCtx *)rs->drs;
    uint32_t            i;
    
    for (i = 0; i < drs->colcount; i++) {
        OCIHandleFree(drs->dha[i], OCI_HTYPE_DEFINE);
    }
    g_free(drs->dha);
    if (drs->dbuf) g_free(drs->dbuf);
    if (drs->iva) g_free(drs->iva);
    g_free(rs->drs);
    rs->drs = NULL;
}

static gboolean     adb_oci_next(
    AdbResultSet        *rs,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)rs->stmt->conn->dconn;
    AdbOciStmtCtx       *dstmt = (AdbOciStmtCtx *)rs->stmt->dstmt;
    AdbOciRsCtx         *drs = (AdbOciRsCtx *)rs->drs;
    gboolean            ok = TRUE;
    
    if (!drs->row_valid) {
        return FALSE;
    }
    
    ok = adb_oci_v(OCIStmtFetch2(dstmt->stmt, dconn->err, 1, 
                                 OCI_FETCH_NEXT, 0, OCI_DEFAULT),
                   "fetching next row", rs->stmt->conn, err);
    
    if (!ok && !(*err)) drs->row_valid = FALSE;
    return ok;
}

static uint32_t     adb_oci_colcount(
    AdbResultSet        *rs,
    GError              **err)
{
    AdbOciRsCtx         *drs = (AdbOciRsCtx *)rs->drs;

    return drs->colcount;
}

static char         *adb_oci_colname(
    AdbResultSet        *rs,
    uint32_t            col,
    GError              **err)
{
    AdbOciConnCtx       *dconn = (AdbOciConnCtx *)rs->stmt->conn->dconn;
    AdbOciStmtCtx       *dstmt = (AdbOciStmtCtx *)rs->stmt->dstmt;
    AdbOciRsCtx         *drs = (AdbOciRsCtx *)rs->drs;
    gboolean            ok = TRUE;
    char                *colname = NULL;
    OCIParam            *dp = NULL;
    
    if (col >= drs->colcount) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "Column %u out of range", col);
        return FALSE;
    }
    
    if (!adb_oci_v(OCIParamGet(dstmt->stmt, OCI_HTYPE_STMT, 
                               dconn->err, (void **)&dp, col+1),
                   "getting column parameter", rs->stmt->conn, err)) {
        ok = FALSE;
        goto end;
    }
    
    if (!adb_oci_v(OCIAttrGet(dp, OCI_DTYPE_PARAM, &colname, NULL, 
                              OCI_ATTR_NAME, dconn->err),
                   "getting column name", rs->stmt->conn, err)) {
        ok = FALSE;
        goto end;
    }
    
  end:
    OCIHandleFree(dp, OCI_HTYPE_DESCRIBE);
    return ok ? colname : NULL;
}

static gboolean     adb_oci_fetch(
    AdbResultSet        *rs,
    uint32_t            col,
    const char          **val,
    GError              **err)
{   
    AdbOciRsCtx         *drs = (AdbOciRsCtx *)rs->drs;

    if (!drs->row_valid) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "At end of result set");
        return FALSE;
    }
    
    if (col >= drs->colcount) {
        g_set_error(err, ADB_ERROR_DOMAIN, ADB_ERROR_RANGE,
                    "Column %u out of range", col);
        return FALSE;
    }
    
    if (drs->iva[col] == -1) {
        *val = NULL; 
    } else {
        *val = drs->dbuf + (col * rs->stmt->param_maxlen);
    }
    return TRUE;
}

static AdbDriver    adb_oci_driver = {
    "oci",
    ":", TRUE,          /* Prepared statement parameters look like :n */
    adb_oci_alloc,
    adb_oci_open,
    adb_oci_close,
    adb_oci_free,
    adb_oci_begin,
    adb_oci_commit,
    adb_oci_rollback,
    adb_oci_prepare,
    adb_oci_free_stmt,
    adb_oci_execute,
    adb_oci_query,
    adb_oci_free_rs,
    adb_oci_next,
    NULL, /* rowcount not yet supported for Oracle */
    adb_oci_colcount,
    NULL, /* field length not yet supported for Oracle */
    adb_oci_colname,
    adb_oci_fetch
};

void adb_oci_register()
{
    adb_driver_register(&adb_oci_driver);
}

#else 

void adb_oci_register()
{
    g_assert_not_reached();
}

#endif
