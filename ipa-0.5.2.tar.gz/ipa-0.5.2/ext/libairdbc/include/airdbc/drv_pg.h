/*
 ** drv_pg.h
 ** AirDBC PostgreSQL driver
 **
 ** ------------------------------------------------------------------------
 ** Copyright (C) 2000-2005 Carnegie Mellon University. All Rights Reserved.
 ** ------------------------------------------------------------------------
 ** Authors: Brian Trammell <bht@cert.org>
 ** ------------------------------------------------------------------------
 ** From libair::db, by Brian Trammell, Roman Danyliw, and Sean Levy.
 ** ------------------------------------------------------------------------
 ** GNU Lesser GPL Rights pursuant to Version 2.1, February 1999 
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
 ** ------------------------------------------------------------------------
 */

#ifndef _ADB_DRV_PG_H_
#define _ADB_DRV_PG_H_

void adb_pg_register();

#endif
