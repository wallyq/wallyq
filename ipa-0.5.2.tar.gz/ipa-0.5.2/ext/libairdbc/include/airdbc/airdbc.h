/*
** airdbc.h
** AirDBC Database Abstraction Layer
**
** ------------------------------------------------------------------------
** Copyright (C) 2000-2005 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Brian Trammell <bht@cert.org>
** ------------------------------------------------------------------------
** From libair::db, by Brian Trammell, Roman Danyliw, and Sean Levy.
** ------------------------------------------------------------------------
** GNU Lesser GPL Rights pursuant to Version 2.1, February 1999
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/

/**
 * @mainpage AirCERT Database Connectivity
 *
 * @section Introduction
 *
 * AirDBC is the AirCERT Database Connectivity abstraction layer for access
 * to multiple RDBMS backends in C. It is designed for use in applications
 * that run a large number of invocations of a relatively small number of
 * statements; to that end, its API supports prepared statements only. It
 * supports both positional and named binding of statement parameters, even
 * on RDBMS backends which do not support named binding.
 *
 * AirDBC ships with support for two RDBMS backends, PostgreSQL
 * (http://www.postgresql.org) 8 via libpq and Oracle (http://www.oracle.com)
 * 9i via the Oracle Call Interface. Applications may provide their own
 * external drivers and register them at runtime, as well.
 *
 * The client API is documented in airdbc.h, while the driver API is
 * documented in airdbc_drv.h.
 *
 * @section Downloading
 *
 * AirDBC is distributed from http://tools.netsa.cert.org/airdbc
 *
 * <a href="http://tools.netsa.cert.org/releases/airdbc-0.2.1.tar.gz">Download
 *AirDBC 0.2.1</a>
 *
 * @section Building
 *
 * AirDBC uses a reasonably standard autotools-based build system.
 * The customary build procedure (<tt>./configure && make
 * && make install</tt>) should work in most environments.
 *
 * AirDBC is linked against its built-in backend drivers at compile time.
 * By default, no backend drivers are built. This is almost definitely not
 * what you want, so you'll have to enable these using configure options.
 * The following options are supported:
 *
 *      - <tt>--with-postgresql[=prefix]</tt>
 *              builds the PostgreSQL driver
 *      - <tt>--with-oci</tt>
 *              builds the OCI driver
 *              (uses <tt>ORACLE_HOME</tt> environment variable)
 *
 * Like many other NetSA products, AirDBC's configure script also supports
 * the <tt>--with-glib-static</tt> option, which allows the use of a static
 * libglib. This is useful in environments using ancient versions of glib
 * (2.4 is common; AirDBC requires glib-2.6.4 or later) where a glib upgrade
 * is not feasible. To use this, install glib-2.6.4 or later to a private
 * prefix, then supply that prefix to <tt>--with-glib-static</tt>.
 *
 * @section Copyright
 *
 * AirDBC is copyright 2005 Carnegie Mellon University, and is released under
 * the GNU Lesser General Public License. See the COPYING file in the
 * distribution for details.
 *
 * AirDBC was developed at the CERT Network Situational Awareness Group
 * by Brian Trammell <bht@cert.org> for use in the NAF tools.
 */

/**
 * @file
 *
 * AirDBC Database Connectivity API. This file provides the client interface
 * for AirDBC applications.
 */

#ifndef _ADB_AIRDBC_H_
#define _ADB_AIRDBC_H_

#include <airdbc/drv_pg.h>
#include <airdbc/drv_oci.h>

/** All AirDBC errors are returned within the ADB_ERROR_DOMAIN. */
#define ADB_ERROR_DOMAIN g_quark_from_string("AirDBCError")

/** An underlying parse or execution error from the driver. */
#define ADB_ERROR_RDBMS 1

/** A connection error. The AdbConnection is closed. */
#define ADB_ERROR_CONNECT 2

/** An argument passed to an AirDBC call had a bad format or value. */
#define ADB_ERROR_ARGUMENT 3

/** An argument passed to an AirDBC call was out of range. */
#define ADB_ERROR_RANGE 4

struct _AdbConnection;
/**
 * An AirDBC connection. Encapsulates a single restartable connection to a
 * single RDBMS instance. Created by adb_conn_create(), and destroyed by
 * adb_conn_free(). AdbConnections are created in disconnected state;
 * adb_conn_open will open the connection. An AdbConnection may be closed
 * by adb_conn_close(), or automatically if the underlying driver detects
 * disconnection.
 */
typedef struct _AdbConnection AdbConnection;

struct _AdbStatement;
/**
 * An AirDBC prepared statement. Encapsulates a single parameterized SQL
 * statement, designed to be used multiple times. Each AdbStatement is
 * scoped to an AdbConnection, which must be open when the statement is
 * created with adb_stmt_prepare(). Statements are destroyed by
 * adb_stmt_free().
 */
typedef struct _AdbStatement AdbStatement;

struct _AdbResultSet;
/**
 * An AirDBC result set. Encapsulates a single result set returned by the
 * execution of an AdbStatement. Created by adb_stmt_query(), and destroyed
 * by adb_rs_free().Some drivers may require that each statement have at
 * most one active AdbResultSet.
 */
typedef struct _AdbResultSet AdbResultSet;

/**
 * Create a new, unopened AdbConnection. Connects to a database specified by
 * a URI of the following format:
 *
 *      driver://username:password@@host:port/dbname/additional
 *
 * where username, password, port, and additional are optional. Supported
 * drivers are "postgresql" (PostgreSQL 8.x+ via libpq 4.x) and
 * "oci" (Oracle 9+ via Oracle Call Interface [libclntsh]). For postgresql
 * URIs, port defaults to 5432. For oci URIs, host must always be localhost
 * and port defaults to 0; because of the way Oracle Net Services works, all
 * database connections are mediated by the local Oracle client software
 * installation.
 *
 * @param uri AirDBC database URI
 * @param err error description
 * @return A new AdbConnection, or NULL on error.
 */

AdbConnection *adb_conn_create(
    const char *uri,
    GError    **err);

/**
 * Ensure that an AdbConnection is open. Opens the connection if it is closed;
 * otherwise, does nothing.
 *
 * @param conn AdbConnection to open
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_conn_open(
    AdbConnection *conn,
    GError       **err);

/**
 * Ensure that an AdbConnection is closed. Closes the connection if it is
 *open;
 * otherwise, does nothing.
 *
 * @param conn AdbConnection to close
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_conn_close(
    AdbConnection *conn,
    GError       **err);

/**
 * Determine the state of a connection.
 *
 * @param conn AdbConnection to check connection state of.
 * @return TRUE if the connection is open, FALSE if closed.
 */

gboolean adb_conn_is_open(
    AdbConnection *conn);

/**
 * Destroy an AdbConnection, and free all storage associated with it.
 * Ensure that all scoped AdbStatements and AdbResultSets have been freed
 * before calling this. If the AdbConnection is open, closes the connection
 * and ignores the result.
 *
 * @param conn an AdbConnection to free
 */

void adb_conn_free(
    AdbConnection *conn);

/**
 * Begin a transaction on a given AdbConnection. If the connection fails or
 * an error occurs before the transaction is committed, all changes within
 * the transaction will be rolled back. Some drivers may not support nested
 * transactions.
 *
 * @param conn AdbConnection to start transaction on
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_transaction_begin(
    AdbConnection *conn,
    GError       **err);

/**
 * Commit the current transaction on a given AdbConnection. Fails if no
 * transaction is currently active.
 *
 * @param conn AdbConnection to commit transaction on
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_transaction_commit(
    AdbConnection *conn,
    GError       **err);

/**
 * Roll back the current transaction on a given AdbConnection. Fails if no
 * transaction is currently active.
 *
 * @param conn AdbConnection to roll back transaction on
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_transaction_rollback(
    AdbConnection *conn,
    GError       **err);

/**
 * Prepare a statement for binding an execution on a given AdbConnection.
 * Bind parameters are specified using Oracle-style syntax (i.e., ":name") and
 * translated into the driver's native positional bind parameter syntax. Since
 * bind parameter buffers must be statically sized for some drivers (i.e.,
 * Oracle), bind parameter lengths are limited to a constant size given in
 * param_maxlen. If param_maxlen is given as 0, the bind parameter buffer
 * size defaults to 64 bytes per parameter.
 *
 * @param conn AdbConnection on which to prepare a statement. Must be open.
 * @param sql Parameterized SQL string to prepare.
 * @param param_maxlen Maximum length of each bind parameter. Defaults to 64.
 * @param err error description
 * @return A new AdbStatement, or NULL on failure.
 */

AdbStatement *adb_stmt_prepare(
    AdbConnection *conn,
    char          *sql,
    uint32_t       param_maxlen,
    GError       **err);

/**
 * Destroy an AdbStatement, and free all storage associated with it.
 *
 * @param stmt an AdbStatement to free
 */

void adb_stmt_free(
    AdbStatement *stmt);

/**
 * Bind a parameter value to a given AdbStatement by parameter position.
 * This parameter will copy the string value into the statement, so it is safe
 * to free or reuse values between bind and execute.
 *
 * @param stmt AdbStatement to bind.
 * @param pos zero-indexed parameter position
 * @param val string value to bind (or NULL)
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_stmt_bind(
    AdbStatement *stmt,
    uint32_t      pos,
    const char   *val,
    GError      **err);

/**
 * Bind a parameter value to a given AdbStatement by parameter name.
 * This parameter will copy the string value into the statement, so it is safe
 * to free or reuse values between bind and execute. If a given bind name
 * appears multiple times in the statement, this will bind the given value to
 * each such position.
 *
 * @param stmt AdbStatement to bind.
 * @param name parameter name
 * @param val string value to bind (or NULL)
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_stmt_bind_named(
    AdbStatement *stmt,
    const char   *name,
    const char   *val,
    GError      **err);

/**
 * Execute an AdbStatement that does not return an AdbResultSet. This is
 * intended for use with data manipulation or data definition statements,
 * though it can be used for queries as well, to ignore the resulting result
 * set.
 *
 * @param stmt AdbStatement to execute.
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_stmt_execute(
    AdbStatement *stmt,
    GError      **err);

/**
 * Execute an AdbStatement that returns an AdbResultSet. The result set's
 * cursor will be positioned before the first row, so a call to adb_rs_next()
 * is required before the first call to adb_rs_fetch().
 *
 * Note that some drivers require only one AdbResultSet at once per
 * AdbStatement to be active, so this call may fail if a previous AdbResultSet
 * has not yet been freed.
 *
 * @param stmt AdbStatement to execute.
 * @param err error description
 * @return a new AdbResultSet, or NULL on failure.
 */

AdbResultSet *adb_stmt_query(
    AdbStatement *stmt,
    GError      **err);

/**
 * Destroy an AdbResultSet, and free all storage associated with it.
 *
 * @param rs an AdbResultSet to free
 */

void adb_rs_free(
    AdbResultSet *rs);

/**
 * Advance a given AdbResultSet's cursor to the next row. Must be called
 * after a successful adb_stmt_query() to start fetching data. Returns FALSE
 * and sets *err to NULL at the end of the result set. Designed to be called
 * as follows:
 *
 * @code
 *      rs = adb_stmt_query(stmt, &err);
 *      if (!rs) {
 *          ... handle adb_stmt_query() error ...
 *      }
 *      while (adb_rs_next(rs, &err) {
 *          ... fetch and process row ...
 *      }
 *      if (err) {
 *          ... handle adb_rs_next() error ...
 *      }
 * @endcode
 *
 * @param rs AdbResultSet to advance cursor on
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */

gboolean adb_rs_next(
    AdbResultSet *rs,
    GError      **err);


/**
 * Return the number of rows in a given AdbResultSet.
 *
 * @param rs AdbResultSet to get row count from
 * @param err error description
 * @return row count, or 0 on error
 */
uint32_t adb_rs_row_count(
    AdbResultSet *rs,
    GError      **err);


/**
 * Return the number of columns in a given AdbResultSet.
 *
 * @param rs AdbResultSet to get column count from
 * @param err error description
 * @return column count, or 0 on error
 */
uint32_t adb_rs_column_count(
    AdbResultSet *rs,
    GError      **err);

/**
 * Return the number of characters required to represent the field's contents.
 *
 * @param rs AdbResultSet being queried
 * @param row row number
 * @param col column number
 * @param err error description
 * @return field width, or 0 on error
 */
uint32_t adb_rs_field_width(
    AdbResultSet *rs,
    uint32_t      row,
    uint32_t      col,
    GError      **err);

/**
 * Return the name of a given column in an AdbResultSet. The name's storage
 * is managed by the AdbResultSet, and must be copied if intended to be used
 * after the AdbResultSet is freed.
 *
 * @param rs AdbResultSet to get column name from
 * @param col zero-indexed column number to name
 * @param err error description
 * @return the column name, or NULL on error.
 */

char *adb_rs_column_name(
    AdbResultSet *rs,
    uint32_t      col,
    GError      **err);

/**
 * Fetch a value from a given column of the current row of an AdbResultSet.
 * Not valid on a newly executed query until adb_rs_next() has been called.
 * The returned value's storage is managed by the AdbResultSet and scoped
 * to the current row, and must be copied if intended to be used after the
 * row cursor is advanced using adb_rs_next().
 *
 * @param rs AdbResultSet to get value from
 * @param col zero-indexed column number to fetch
 * @param val fetched value (out-parameter)
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */
gboolean adb_rs_fetch(
    AdbResultSet *rs,
    uint32_t      col,
    const char  **val,
    GError      **err);



/**
 * Fetch a value from a given column of the current row of an AdbResultSet,
 * placing the result in a buffer provided by the caller.
 * Not valid on a newly executed query until adb_rs_next() has been called.
 *
 * @param rs AdbResultSet to get value from
 * @param col zero-indexed column number to fetch
 * @param buf (out) buffer in which to place the value
 * @param len length of the output buffer
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */
gboolean adb_rs_fetch_buf(
    AdbResultSet *rs,
    uint32_t      col,
    const char   *buf,
    size_t        len,
    GError      **err);

/**
 * Fetch a value from a named column of the current row of an AdbResultSet.
 * Not valid on a newly executed query until adb_rs_next() has been called.
 * The returned value's storage is managed by the AdbResultSet and scoped
 * to the current row, and must be copied if intended to be used after the
 * row cursor is advanced using adb_rs_next().
 *
 * @param rs AdbResultSet to get value from
 * @param name name of column to fetch
 * @param val fetched value (out-parameter)
 * @param err error description
 * @return TRUE on success, FALSE otherwise
 */


gboolean adb_rs_fetch_named(
    AdbResultSet *rs,
    const char   *name,
    const char  **val,
    GError      **err);

#endif
