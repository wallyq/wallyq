## ------------------------------------------------------------------------
## python-info.py
## helper script for getting Python configuration
## ------------------------------------------------------------------------
## Copyright (C) 2008 Carnegie Mellon University. All Rights Reserved.
## ------------------------------------------------------------------------
## GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
## Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
## ------------------------------------------------------------------------

#######################################################################
# $Id:  $
#######################################################################

from distutils.sysconfig import *
import sys
import os
import re

default_min_version = "2.4"
default_max_version = "3.0"

def version_to_hexversion(version):
    ver = map(int, string.split(version, '.')) + [0, 0, 0]
    hexver = 0
    for i in xrange(0, 4): hexver = (hexver << 8) + ver[i]
    return hexver

if len(sys.argv) > 1 and sys.argv[1] == "--check-version":
    min_hexver = version_to_hexversion(default_min_version)
    max_hexver = version_to_hexversion(default_max_version)
    
    if (len(sys.argv) > 2):
        min_hexver = version_to_hexversion(sys.argv[2])

    if (len(sys.argv) > 3):
        max_hexver = version_to_hexversion(sys.argv[3])    

    # See if we are python version >= min and < max
    version_ok = (min_hexver <= sys.hexversion < max_hexver)
    if version_ok:
        sys.exit(0)
    else:
        sys.exit(1)

if len(sys.argv) == 1 or sys.argv[1] != "--filename":
    sys.exit("Usage: %s {--check-version | --filename [filename]}" %
             sys.argv[0])

outfile = sys.argv[2]
python_prefix = os.getenv('PYTHONPREFIX')
python_site = os.getenv('PYTHONSITEDIR')
python_default_site = ""
version = ""
package_dest = ""
error_string = ""
include_dir = ""
ldflags = ""
cppflags = ""
libdir = ""
libname = ""
ldflags_embedded = ""

try:
    version = sys.version.split()[0]

    # Get the Python interpreter's prefix (sys.prefix).  We give this value to
    # autotools so we know where distutils installed stuff.    
    python_sys_prefix = sys.prefix
    # Stash the config vars
    config_vars = get_config_vars()

    # Where should we install packages?
    python_default_site = get_python_lib(1,0)
    if python_site:
        package_dest = python_site
    else:
        if not python_prefix:
            package_dest = python_default_site
        elif python_default_site != get_python_lib(1,0,"BOGUS"):
            # prefix argument works
            package_dest = get_python_lib(1,0,python_prefix)
        else:
            # prefix argument does not work (Mac OS-X, some versions)
            error_string = "--with-python-prefix is broken on this version of Python.  Please specify a different interpreter using the --with-python= switch, or run again without the --with-python-prefix switch to use the default Python package directory for this interpreter."

    # Python include path
    include_dir = get_python_inc()

    # Python library location
    libdir = config_vars['LIBDIR']

    # Python library
    library = config_vars['LIBRARY']
    if not library:
        library = config_vars['LDLIBRARY']

    # Figure out the shortname of the library
    if library:
        libname = library[3:library.rfind('.')]

    # Needed for linking embedded python
    linkforshared = config_vars['LINKFORSHARED']
    localmodlibs = config_vars['LOCALMODLIBS']
    libs = config_vars['LIBS']
    ldflags_embedded = ' '.join([linkforshared, localmodlibs, libs]).strip(' ')


    # Hack for the mac
    # Changes "-u _PyMac_Error Python.framework/Versions/2.4/Python" to
    # "-u _PyMac_Error -framework Python"
    ldflags_embedded = re.sub(r'(\A| )Python\.framework/[^ ]*',
                              ' -framework Python', ldflags_embedded)


    ### Build the output flags
    if include_dir:
        cppflags = "-I " + include_dir

    if libdir:
        ldflags = "-L" + libdir

    if libname:
        ldflags += " -l" + libname

    ldflags_embedded = ldflags + " " + ldflags_embedded

except:
    error_string = sys.exc_info()[1]
    pass

try:
    out = os.open(outfile, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
except os.error, e:
    sys.exit("error: Cannot create %s: %s" % (outfile, e[1]))

os.write(out, 'PYTHON_VERSION="%s"\n' % version)
os.write(out, 'PYTHON_LIBDIR="%s"\n' % libdir)
os.write(out, 'PYTHON_LIBNAME="%s"\n' % libname)
os.write(out, 'PYTHON_SITE_PKG="%s"\n' % package_dest)
os.write(out, 'PYTHON_DEFAULT_SITE_PKG="%s"\n' % python_default_site)
os.write(out, 'PYTHON_CPPFLAGS="%s"\n' % cppflags)
os.write(out, 'PYTHON_LDFLAGS="%s"\n' % ldflags)
os.write(out, 'PYTHON_LDFLAGS_EMBEDDED="%s"\n' % ldflags_embedded)
os.write(out, 'PYTHON_ERROR="%s"\n' % error_string)
os.write(out, 'PYTHON_SYS_PREFIX="%s"\n' % python_sys_prefix)
os.close(out)
