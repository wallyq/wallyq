/*
** ipautils.c
** IP Association Library Utility Header
**
** ------------------------------------------------------------------------
** Copyright (C) 2006-2010 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov  <tonyc@cert.org>
**          Brian Trammell <bht@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/


/**
 * @page ipautils ipa-utils
 *
 * The IPA suite provides several command-line utilities for managing and
 * getting information about data in an IPA data store.
 *
 * These utilities are installed for you as part of the main IPA install, and
 * all use @ref libipa to access the IPA data store.
 *
 * @section ipautils_manpage_sec Manual Pages
 *
 * <ul>
 * <li><a href="ipaimport.html">ipaimport</a> - import delimited data into an
 * IPA catalog
 * <li><a href="ipaexport.html">ipaexport</a> - export delimited data from an
 * IPA catalog
 * <li><a href="ipaquery.html">ipaquery</a> - get information about IPA
 * catalogs and datasets
 * </ul>
 *
 *
 */

/**
 * @file
 *
 * ipa-utils shared functions.
 */

#ifndef _IPA_IPAUTILS_H_
#define _IPA_IPAUTILS_H_

#include <ipa/ipa.h>
#include <unistd.h>
#include <time.h>

extern gboolean version_flag;

void ipautils_add_shared_options(
    GOptionContext *octx,
    const char     *name);

gboolean ipautils_handle_shared_options(
    GOptionContext *octx);

gboolean ipautils_scan_addr(
    GScanner *scanner,
    uint32_t *addr);

gboolean ipautils_scan_range(
    GScanner *scanner,
    uint32_t *a,
    uint32_t *b);

/* FIXME:  In the library? */
gboolean ipautils_ntop(
    int      family,
    uint32_t addr,
    GString *str);

#ifndef HAVE_TIMEGM
time_t timegm(
    struct tm *tm);
#endif /* !HAVE_TIMEGM */

#endif
