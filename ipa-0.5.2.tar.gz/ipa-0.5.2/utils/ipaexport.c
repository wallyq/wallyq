/*
** ipaexport.c
** IP Association Library Import Utility
**
** ------------------------------------------------------------------------
** Copyright (C) 2006-2010 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov  <tonyc@cert.org>
**          Brian Trammell <bht@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/

#include "ipautils.h"

static char *RCSID __attribute__ ((unused)) =
    "$Id: ipaexport.c 14644 2009-07-23 15:17:22Z tonyc $";

static char *catalog_name = NULL;
static char *time_str     = NULL;
static char *delim        = NULL;
static char *ipa_db_uri   = NULL;

static GOptionEntry ipaexport_optentries[] = {
    { "catalog",   'c', 0, G_OPTION_ARG_STRING, &catalog_name,
      "name of the catalog to import data into (will be created if necessary)",
      "file" },
    { "time",        0, 0, G_OPTION_ARG_STRING, &time_str,
      "beginning of validity interval in YYYY/MM/DD[:HH[:MM[:SS]]] format",
      "time" },
    { "delimiter", 'd', 0, G_OPTION_ARG_STRING, &delim,
      "character(s) delimiting fields in input (default: whitespace)",
      "character(s)" },
    { "db",          0, 0, G_OPTION_ARG_STRING, &ipa_db_uri,
      "URI of the IPA relational database to connect to", "URI" },
    { NULL }
};

static gboolean ipaexport_opt_parse(
    int   *argc,
    char **argv[]) {

    GOptionContext *octx = NULL;
    GError         *oerr = NULL;

    octx = g_option_context_new("...");
    g_option_context_add_main_entries(octx, ipaexport_optentries, NULL);

    ipautils_add_shared_options(octx, "ipaexport");

    g_option_context_parse(octx, argc, argv, &oerr);

    if (oerr) {
        g_critical("Couldn't parse command line: %s\nUse --help for usage.",
                   oerr->message);
    }

    if (ipautils_handle_shared_options(octx) ) {
        return FALSE;
    }

    g_option_context_free(octx);
    return TRUE;
} /* ipaexport_opt_parse */

gboolean ipaexport_export_dataset(
    IPAContext    *ipa,
    GIOChannel    *out,
    IPACatalogType cat_type)
{
    GError  *err  = NULL;
    GString *line = NULL;
    gsize    written;
    IPAAssoc assoc;

    line = g_string_new("");

/*    while (!ipa_get_range(ipa, &range, &label, &value)) { */
    while (!ipa_get_assoc(ipa, &assoc)) {
        switch (cat_type) {
          case IPA_CAT_SET:
            g_string_printf(line, "%s\n", assoc.range);
            break;
          case IPA_CAT_BAG:
            g_string_printf(line, "%s%s%s\n", assoc.range,
                            (delim ? delim : " "),
                            assoc.value);
            break;
          case IPA_CAT_PMAP:
            g_string_printf(line, "%s%s%s%s\n", assoc.range,
                            ( ( strchr(assoc.range,
                                       '/') || strchr(assoc.range, '-'))
                              ? "" : "/32"),
                            (delim ? delim : " "), assoc.label);
            break;
          case IPA_CAT_MMAP:
            g_string_printf(line, "%s%s%s%s%s%s\n", assoc.range,
                            ( ( strchr(assoc.range,
                                       '/') || strchr(assoc.range, '-'))
                              ? "" : "/32"),
                            (delim ? delim : " "), assoc.label,
                            (delim ? delim : " "), assoc.value);
            break;
          default:
            g_critical("unsupported catalog type (%d)", cat_type);
            goto END;
        } /* switch */
        g_io_channel_write_chars(out, line->str, strlen(line->str),
                                 &written, &err);
        if (err) {
            g_critical("Error writing to output file: %s",
                       err->message);
            return FALSE;
        }
    }


  END:
    return TRUE;
} /* ipaexport_export_dataset */

int main(
    int   argc,
    char *argv[])
{
    GIOChannel *out;
    GError     *err = NULL;
    int rv          = 0;
    char *filename  = NULL;
    IPAContext *ipa = NULL;

    if (ipaexport_opt_parse(&argc, &argv)) {
        rv = -1;
        goto END;
    }

    if (catalog_name == NULL) {
        g_critical("You must supply a catalog name to export from");
        rv = -1;
        goto END;
    }

    if (ipa_create_context(&ipa, ipa_db_uri, NULL) != IPA_OK) {
        g_critical("couldn't create IPA context");
        rv = -1;
        goto END;
    }

    if (argc >= 1) {
        filename = argv[1];
    }
    if (!filename || !strcmp(filename, "")) {
        out = g_io_channel_unix_new(STDOUT_FILENO);
    } else {
        out = g_io_channel_new_file(filename, "w", &err);
    }
    if (err != NULL) {
        g_critical("couldn't open output file: %s", err->message);
        rv = -1;
        goto END;
    }

    rv = ipa_get_dataset(ipa, catalog_name, time_str);
    switch (rv) {
      case IPA_OK:
        break;
      case IPA_ERR_NOTFOUND:
        g_critical("dataset not found for given name and time");
        goto END;
      default:
        g_critical("IPA error retrieving dataset");
        goto END;
    }

    switch (ipa->cat_type) {
      case IPA_CAT_SET:
      case IPA_CAT_BAG:
      case IPA_CAT_PMAP:
      case IPA_CAT_MMAP:
        rv = ipaexport_export_dataset(ipa, out, ipa->cat_type);
        break;
      default:
        g_critical("unsupported catalog type (%d)", ipa->cat_type);
        rv = -1;
        goto END;
    } /* switch */
    g_io_channel_shutdown(out, TRUE, &err);

  END:
    if (ipa != NULL)
        ipa_destroy_context(&ipa);
    return rv;
} /* main */
