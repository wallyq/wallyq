/*
** ipqauery.c
** IP Association Library Query Utility
**
** ------------------------------------------------------------------------
** Copyright (C) 2006-2011 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov <tonyc@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/

#include "ipautils.h"

static char *RCSID __attribute__ ((unused)) =
    "$Id: ipaquery.c 15339 2010-02-18 23:34:02Z tonyc $";

/*char *query_string = NULL;*/
GString *query_string = NULL;
char   **query_args   = NULL;

static char *ipa_db_uri         = NULL;
static char *delim              = " ";
static gboolean verbose         = FALSE;
static guint    max_cat_width   = 0;
static guint    max_label_width = 0;
static gboolean no_columns      = FALSE;
static gboolean csv             = FALSE;

static GOptionEntry ipaquery_optentries[] = {
    { "db",                   0,
      0,
      G_OPTION_ARG_STRING,
      &ipa_db_uri,
      "URI of the IPA relational database to connect to", "URI" },
    { "delimiter",            0,
      0, G_OPTION_ARG_STRING,
      &delim,
      "delimiter for fields (default: ' ')", "URI" },
    { "no-columns",        'n',
      0, G_OPTION_ARG_NONE,
      &no_columns,
      "Disable columnar output", NULL },
    { "csv",               'c',
      0, G_OPTION_ARG_NONE,
      &csv,
      "Use comma-separated values (CSV) output", NULL },
    { "max-catalog-width",    0,
      0, G_OPTION_ARG_INT,
      &max_cat_width,
      "truncate catalog column at this number of characters", "num" },
    { "max-label-width",      0,
      0, G_OPTION_ARG_INT,
      &max_label_width,
      "truncate label column at this number of characters", "num" },
    { "verbose",           'v',
      0, G_OPTION_ARG_NONE,
      &verbose,
      "show debug messages", NULL },
    { G_OPTION_REMAINING,  '\0',
      0, G_OPTION_ARG_STRING_ARRAY,
      &query_args,
      NULL, NULL },
    { NULL }
};




int ipaquery_dump_catalogs(
    IPAContext *ipa,
    int         order,
    char       *prefix,
    char       *delim,
    gboolean    fixed_width
    )
{
    GError *err         = NULL;
    const char *val     = NULL;
    char       *orderby = NULL;
    GString    *where   = NULL;
    GString    *filter   = NULL;
    int typeid = IPA_CAT_NONE;
    const char *type = NULL;
    GArray *columns  = g_array_new(FALSE, TRUE, sizeof(IPAColumn));



    filter = g_string_new("");

    if(prefix)
    {
        g_string_printf(filter, "catalog_path ~* '%s'", prefix);
    }
    else
    {
        g_string_printf(filter, "TRUE");
    }

    switch (order) {
      case IPA_ORDER_DEFAULT:
      default: {
          orderby = "name";
      } break;
      case IPA_ORDER_CTIME: {
          orderby = "ctime";
      } break;
      case IPA_ORDER_MTIME: {
          orderby = "mtime";
      } break;
    } /* switch */

    g_string_printf(ipa->sql,
                    "SELECT catalog_id, catalog_path AS name, "
                    "CASE when catalog_type=1 THEN 'set' "
                    "WHEN catalog_type=2 THEN 'bag' "
                    "WHEN catalog_type=3 THEN 'pmap' "
                    "WHEN catalog_type=4 THEN 'mmap' "
                    "ELSE 'unknown' END, "
                    "description AS desc, "
                    "TO_CHAR(ctime, 'YYYY/MM/DD:HH24:MI:SS'),"
                    "TO_CHAR(mtime, 'YYYY/MM/DD:HH24:MI:SS'),"
                    "(SELECT COUNT(*) FROM dataset d WHERE d.catalog_id=cv.catalog_id) AS sets "
                    "FROM catalog_view cv "
                    "WHERE %s "
                    "ORDER BY %s;",
                    filter->str, orderby);

    ipa_statement_query(ipa);
    IPA_CHECK_ERR(err, "error doing catalog query", IPA_ERR_SQL);

    IPA_ADD_COLUMN(columns, "id", 0, FALSE);
    IPA_ADD_COLUMN(columns, "name", 0, TRUE);
    IPA_ADD_COLUMN(columns, "type", 0, TRUE);
    IPA_ADD_COLUMN(columns, "desc", 0, TRUE);
    IPA_ADD_COLUMN(columns, "ctime", 19, FALSE);
    IPA_ADD_COLUMN(columns, "mtime", 19, FALSE);
    IPA_ADD_COLUMN(columns, "sets", 0, FALSE);

    ipa_print_result_set(ipa, columns, delim, fixed_width);

    g_array_free(columns, FALSE);

    g_string_free(filter, TRUE);
    return IPA_OK;

} /* ipaquery_dump_catalogs */

int ipaquery_dump_datasets(
    IPAContext *ipa,
    int         order,
    char       *catname,
    char       *delim,
    gboolean    fixed_width
    )

{
    GError *err         = NULL;
    const char *val     = NULL;
    char       *orderby = NULL;
    GString    *where   = NULL;
    GArray     *columns = g_array_new(FALSE, TRUE, sizeof(IPAColumn));

    where = g_string_new("");

    switch (order) {
      case IPA_ORDER_DEFAULT:
      default: {
          orderby = "t_end DESC";
      } break;
      case IPA_ORDER_CTIME: {
          orderby = "ctime";
      } break;
      case IPA_ORDER_MTIME: {
          orderby = "mtime";
      } break;
    } /* switch */

#if 1
    g_string_printf(
        ipa->sql,
        "SELECT dataset_id, "
        "TO_CHAR(t_begin, 'YYYY/MM/DD:HH24:MI:SS'),"
        "TO_CHAR(t_end, 'YYYY/MM/DD:HH24:MI:SS'),"
        "TO_CHAR(ctime, 'YYYY/MM/DD:HH24:MI:SS'),"
        "TO_CHAR(mtime, 'YYYY/MM/DD:HH24:MI:SS'),"
        "assoc_count, "
        "ip_count "
        "FROM dataset_view "
        "WHERE catalog_path ~* '%s' "
        "ORDER BY %s;",
        catname,
        orderby);

#else
    g_string_printf(
        ipa->sql,
        "SELECT d.dataset_id, "
        "TO_CHAR(d.t_begin, 'YYYY/MM/DD:HH24:MI:SS'),"
        "TO_CHAR(d.t_end, 'YYYY/MM/DD:HH24:MI:SS'),"
        "TO_CHAR(d.ctime, 'YYYY/MM/DD:HH24:MI:SS'),"
        "TO_CHAR(d.mtime, 'YYYY/MM/DD:HH24:MI:SS'),"
        "d.assoc_count, "
        "d.ip_count "
        "FROM dataset  d "
        "WHERE d.dataset_id IN  "
        "( SELECT d.dataset_id FROM catalog c JOIN dataset d ON "
        "c.catalog_id=d.catalog_id WHERE c.name='%s' ) "
        "ORDER BY %s;",
        catname,
        orderby);
#endif
    ipa_statement_query(ipa);
    IPA_CHECK_ERR(err, "error doing catalog query", IPA_ERR_SQL);

    IPA_ADD_COLUMN(columns, "id", 0, FALSE);
    IPA_ADD_COLUMN(columns, "begin", 19, TRUE);
    IPA_ADD_COLUMN(columns, "end", 19, TRUE);
    IPA_ADD_COLUMN(columns, "ctime", 19, FALSE);
    IPA_ADD_COLUMN(columns, "mtime", 19, FALSE);
    IPA_ADD_COLUMN(columns, "assoc", 0, FALSE);
    IPA_ADD_COLUMN(columns, "ips", 0, FALSE);
    /* ipa_get_column_widths(ipa, columns); */
    ipa_print_result_set(ipa, columns, delim, fixed_width);

    g_array_free(columns, FALSE);
    return IPA_OK;

} /* ipaquery_dump_datasets */

#if 0
int ipa_do_find_query(
    IPAContext *ipa,
    GString    *catalog,
    GString    *range,
    GString    *label,
    GString    *value,
    GString    *t1,
    GString    *t2,
    int displayfields)
{
    GError *err     = NULL;
    const char *val = NULL;
    int rv          = IPA_ERR_UNKNOWN;

    GArray *columns = g_array_new(FALSE, TRUE, sizeof(IPAColumn));
    g_assert(ipa);

    g_print("ipa_do_find_query\n");

    if (ipa_do_assoc_query(ipa, (catalog ? catalog->str : NULL),
                           (range ? range->str : NULL),
                           (label ? label->str : NULL),
                           (value ? value->str : NULL),
                           (t1 ? t1->str : NULL),
                           (t2 ? t2->str : NULL),
                           displayfields
                           )
        )
    {
        return IPA_ERR_SQL;
    }

    if (displayfields & IPA_COL_CATALOG)
    {
        IPA_ADD_COLUMN(columns, "catalog", ipa->cat_width, TRUE);
    }
    if (displayfields & IPA_COL_START)
    {
        IPA_ADD_COLUMN(columns, "start", 19, FALSE);
    }
    if (displayfields & IPA_COL_END)
    {
        IPA_ADD_COLUMN(columns, "end", 19, FALSE);
    }
    if (displayfields & IPA_COL_RANGE)
    {
        IPA_ADD_COLUMN(columns, "range", 0, TRUE);
    }
    if (displayfields & IPA_COL_LABEL)
    {
        IPA_ADD_COLUMN(columns, "label", ipa->label_width, TRUE);
    }
    if (displayfields & IPA_COL_VALUE)
    {
        IPA_ADD_COLUMN(columns, "value", 0, FALSE);
    }
    /* FIXME */
    ipa_print_result_set(ipa, columns, " ", TRUE);

    g_array_free(columns, TRUE);

    return IPA_OK;
} /* ipaquery_print_find_query */
#endif


static gboolean ipaquery_handle_query(
    IPAContext *ipa,
    GString    *query)

{
    GError *err = NULL;
    int rv = FALSE;
    GIOStatus status;
    guint symbol;
    GScanner *scanner = ipa->scanner;
    GArray *columns = g_array_new(FALSE, TRUE, sizeof(IPAColumn));

    g_scanner_input_text(scanner, query->str, query->len);

    g_scanner_get_next_token(scanner);

    symbol = scanner->token;
/*    printf("%s: %d\n", query->str, symbol);*/


    switch (symbol) {
      case IPAQUERY_CATLIST:
      {
          GString *catalog = NULL;
          ipaquery_scan_string(scanner, &catalog);
          if (catalog) {
              rv = ipaquery_dump_catalogs(ipa, 0, catalog->str, delim, !no_columns);
              g_string_free(catalog, TRUE);
          } else {
              ipaquery_dump_catalogs(ipa, 0, NULL, delim, !no_columns);
          }
          break;
          break;
      }
      case IPAQUERY_SETLIST:
      {
          GString *catalog = NULL;
          if (!ipaquery_scan_string(scanner, &catalog)) goto err;
          ipaquery_dump_datasets(ipa, 0, catalog->str, delim, !no_columns);
          g_string_free(catalog, TRUE);
          break;
      }
      case IPAQUERY_FIND:
      {
          if (ipa_parse_query(ipa, NULL) != IPA_OK)
              return FALSE;
          /* FIXME: more elegant way of dealing with columns */
          if (ipa->displayfields & IPA_COL_CATALOG)
          {
              IPA_ADD_COLUMN(columns, "catalog", ipa->cat_width, TRUE);
          }
          if (ipa->displayfields & IPA_COL_START)
          {
              IPA_ADD_COLUMN(columns, "start", 19, FALSE);
          }
          if (ipa->displayfields & IPA_COL_END)
          {
              IPA_ADD_COLUMN(columns, "end", 19, FALSE);
          }
          if (ipa->displayfields & IPA_COL_RANGE)
          {
              IPA_ADD_COLUMN(columns, "range", 0, TRUE);
          }
          if (ipa->displayfields & IPA_COL_LABEL)
          {
              IPA_ADD_COLUMN(columns, "label", ipa->label_width, TRUE);
          }
          if (ipa->displayfields & IPA_COL_VALUE)
          {
              IPA_ADD_COLUMN(columns, "value", 0, FALSE);
          }
          ipa_print_result_set(ipa, columns, delim, !no_columns);
          break;
      } /* case IPAQUERY_FIND */
      default:
        g_print("unknown symbol\n");
        goto err;

    } /* switch */

    rv = TRUE;
    goto END;

  err:
    g_scanner_error(scanner, "Scanner error");
    rv = FALSE;

  END:
    return rv;
} /* ipaquery_handle_query */


static gboolean ipaquery_opt_parse(
    int   *argc,
    char **argv[]) {

    GOptionContext *octx = NULL;
    GError         *oerr = NULL;
    gboolean        rv   = FALSE;

    octx = g_option_context_new(
        "command\n"
        "\n"
        "\tDisplay information about data in an IPA data store\n"
        "\n"
        "\tValid commands are:\n"
        "\t\tcatlist [prefix] - list catalogs matching [prefix] (default: all)\n"
        "\t\tsetlist [catname] - list datasets in [catname]\n"
        );

    g_option_context_add_main_entries(octx, ipaquery_optentries, NULL);

    ipautils_add_shared_options(octx, "ipaquery");

    g_option_context_parse(octx, argc, argv, &oerr);

    if (oerr) {
        g_critical("Couldn't parse command line: %s\nUse --help for usage.",
                   oerr->message);
    }

    if (csv) {
        delim      = g_strdup(",");
        no_columns = TRUE;
    }

    rv = !ipautils_handle_shared_options(octx);

    g_option_context_free(octx);
    return rv;
} /* ipaquery_opt_parse */


int main(
    int   argc,
    char *argv[])
{
    int rv          = 0;
    char *opstr     = NULL;
    char *argument  = NULL;
    int   op        = 0;
    IPAContext *ipa = NULL;
    int i           = 0;

    query_string = g_string_new("");

    if (ipaquery_opt_parse(&argc, &argv)) {
        rv = -1;
        goto END;
    }

    if (!query_args) {
        g_critical("no ipaquery command was specified");
        rv = -1;
        goto END;
    }

    for (i = 0; i < g_strv_length(query_args); i++) {
        if (i > 0) {
            g_string_append_printf(query_string, " ");
        }
        if (strstr(query_args[i], " ")) {
            g_string_append_printf(query_string, "\"%s\"", query_args[i]);
        } else {
            g_string_append_printf(query_string, "%s", query_args[i]);
        }
    }

    if (verbose) g_debug("query: %s\n", query_string->str);

    if (argc >= 1) {
        opstr = argv[1];
    }
    if (argc >= 2) {
        argument = argv[2];
    }

    if (ipa_create_context(&ipa, ipa_db_uri, NULL) != IPA_OK) {
        g_critical("couldn't create IPA context");
        rv = -1;
        goto END;
    }
    ipa->verbose     = verbose;
    ipa->cat_width   = max_cat_width;
    ipa->label_width = max_label_width;

    ipaquery_handle_query(ipa, query_string);
  END:
    if (ipa != NULL)
        ipa_destroy_context(&ipa);
    if (query_string) g_string_free(query_string, TRUE);
    return rv;
} /* main */
