/*
** ipaexport.c
** IP Association Library Import Utility
**
** ------------------------------------------------------------------------
** Copyright (C) 2006-2010 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov  <tonyc@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/

#include "ipautils.h"

gboolean version_flag      = FALSE;
static const char *appname = "unknown";

static GOptionEntry ipautils_shared_options[] = {
    { "version", 'V', 0, G_OPTION_ARG_NONE, &version_flag,
      "Print application version and exit", NULL },
    { NULL }
};

static void ipautils_print_version() {
    fprintf(stderr,
            "%s: part of %s %s (c) 2006-2008 Carnegie Mellon University.\n",
            appname,
            PACKAGE_NAME,
            PACKAGE_VERSION);
    fprintf(stderr, "GNU General Public License (GPL) Rights "
                    "pursuant to Version 2, June 1991\n");
    fprintf(stderr, "Some included library code covered by LGPL 2.1; "
                    "see source for details.\n");
    fprintf(stderr, "Government Purpose License Rights (GPLR) "
                    "pursuant to DFARS 252.225-7013\n");
} /* ipautils_print_version */

void ipautils_add_shared_options(
    GOptionContext *octx,
    const char     *name)
{
    g_option_context_add_main_entries(octx, ipautils_shared_options, NULL);
    appname = name;
} /* ipautils_add_shared_options */

gboolean ipautils_handle_shared_options(
    GOptionContext *octx)
{
    if (version_flag) {
        ipautils_print_version();
        return FALSE;
    }
    return TRUE;
} /* ipautils_handle_shared_options */

gboolean ipautils_scan_range(
    GScanner *scanner,
    uint32_t *a,
    uint32_t *b)
{
    uint32_t mask = 0;

    if (!ipautils_scan_addr(scanner, a)) {
        return FALSE;
    }

    /* EOA for first address. Peek for next token. */
    g_scanner_peek_next_token(scanner);
    /* Slash means CIDR, dash means explicit inclusive range. */
    if (scanner->next_token == '/') {
        /* This range is CIDRized. Eat the slash. */
        g_scanner_get_next_token(scanner);
        /* Calculate A and B from CIDR notation. */
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 32) return FALSE;
        mask = ipa_mask_from_prefix(scanner->value.v_int);
        *a  &= mask;
        *b   = *a | (~mask);
    } else if (scanner->next_token == '-') {
        /* Explicit range. Eat the dash. */
        g_scanner_get_next_token(scanner);
        if (!ipautils_scan_addr(scanner, b)) {
            return FALSE;
        }
    } else {
        /* Presume single address in range. */
        *b = *a;
    }

    return TRUE;
} /* ipautils_scan_range */


gboolean ipautils_scan_addr(
    GScanner *scanner,
    uint32_t *addr)
{

    if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;

    if (g_scanner_peek_next_token(scanner) == '.') {
        /* The begin address is specified as a dotted quad */
        if (scanner->value.v_int > 255) return FALSE;
        *addr = ((scanner->value.v_int & 0x000000FF) << 24);
        if (g_scanner_get_next_token(scanner) != '.') return FALSE;
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 255) return FALSE;
        *addr |= ((scanner->value.v_int & 0x000000FF) << 16);
        if (g_scanner_get_next_token(scanner) != '.') return FALSE;
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 255) return FALSE;
        *addr |= ((scanner->value.v_int & 0x000000FF) << 8);
        if (g_scanner_get_next_token(scanner) != '.') return FALSE;
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 255) return FALSE;
        *addr |= (scanner->value.v_int & 0x000000FF);
    } else {
        /* The begin address is specified as an integer */
        *addr = scanner->value.v_int;
    }

    return TRUE;
} /* ipautils_scan_addr */


#ifndef HAVE_TIMEGM
/* Inverse of gmtime(); convert a struct tm to time_t. */
time_t timegm(
    struct tm *tm)
{
    time_t t_offset, t_2offset;
    struct tm tm_offset;

    /* compute time_t with the timezone offset */
    t_offset = mktime(tm);
    if (t_offset == -1) {
        /* see if adjusting the hour allows mktime() to work */
        tm->tm_hour--;
        t_offset = mktime(tm);
        if (t_offset == -1) {
            return -1;
        }
        /* adjusting hour worked; add back that time */
        t_offset += 3600;
    }

    /* compute a second value with another timezone offset */
    gmtime_r(&t_offset, &tm_offset);
    tm_offset.tm_isdst = 0;
    t_2offset          = mktime(&tm_offset);
    if (t_2offset == -1) {
        tm_offset.tm_hour--;
        t_2offset = mktime(&tm_offset);
        if (t_2offset == -1) {
            return -1;
        }
        t_2offset += 3600;
    }

    /* difference in the two time_t's is one TZ offset */
    return (t_offset - (t_2offset - t_offset));
} /* timegm */
#endif /* !HAVE_TIMEGM */
