/*
** ipaimport.c
** IP Association Library Import Utility
**
** ------------------------------------------------------------------------
** Copyright (C) 2006-2010 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov  <tonyc@cert.org>
**          Brian Trammell <bht@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/

#include "ipautils.h"

static char *RCSID __attribute__ ((unused)) =
    "$Id: ipaimport.c 15293 2010-02-11 22:48:11Z tonyc $";

static char *catalog_name      = NULL;
static char *catalog_desc      = NULL;
static char *start_time_str    = NULL;
static char *end_time_str      = NULL;
static char *delim             = "\t ";
static char *ipa_db_uri        = NULL;
static int   progress_interval = 0;
static gboolean append         = FALSE;

static IPACatalogType catalog_type = IPA_CAT_NONE;


gboolean parse_type(
    const gchar *option_name,
    const gchar *value,
    gpointer     data,
    GError     **error)
{
    if (!g_ascii_strcasecmp(value, "set")) {
        catalog_type = IPA_CAT_SET;
    } else if (!g_ascii_strcasecmp(value, "bag")) {
        catalog_type = IPA_CAT_BAG;
    } else if (!g_ascii_strcasecmp(value, "pmap")) {
        catalog_type = IPA_CAT_PMAP;
    } else if (!g_ascii_strcasecmp(value, "mmap")) {
        catalog_type = IPA_CAT_MMAP;
    } else {
        g_critical("couldn't parse %s value %s", option_name, value);
        return FALSE;
    }
    return TRUE;
} /* parse_type */

static GOptionEntry ipaimport_optentries[] = {
    { "catalog",     'c', 0, G_OPTION_ARG_STRING,
      &catalog_name,
      "name of the catalog to import data into (will be created if necessary)",
      "name" },
    { "type",        't', 0, G_OPTION_ARG_CALLBACK,
      parse_type,
      "type of catalog to import (set, bag, pmap, or mmap)", "type" },
    { "description", 'D', 0, G_OPTION_ARG_STRING,
      &catalog_desc,
      "for new catalogs, a brief description of the catalog's contents",
      "description" },
    { "delimiter",   'd', 0, G_OPTION_ARG_STRING,
      &delim,
      "character(s) delimiting fields in input (default: whitespace)",
      "character(s)" },
    { "start",         0, 0, G_OPTION_ARG_STRING,
      &start_time_str,
      "beginning of validity interval in YYYY/MM/DD[:HH[:MM[:SS]]] format",
      "time" },
    { "end",           0, 0, G_OPTION_ARG_STRING,
      &end_time_str,
      "end of validity interval in YYYY/MM/DD[:HH[:MM[:SS]]] format", "time" },
    { "append",        0, 0, G_OPTION_ARG_NONE,
      &append,
      "Append records to an existing dataset", NULL },
    { "db",            0, 0, G_OPTION_ARG_STRING,
      &ipa_db_uri,
      "URI of the IPA relational database to connect to", "URI" },
    { "progress",      0, 0, G_OPTION_ARG_INT,
      &progress_interval,
      "print a progress indicator every [num] records imported", "num" },
    { NULL }
};

static gboolean ipaimport_opt_parse(
    int   *argc,
    char **argv[]) {

    GOptionContext *octx = NULL;
    GError         *oerr = NULL;

    octx = g_option_context_new("input_file");
    g_option_context_add_main_entries(octx, ipaimport_optentries, NULL);

    ipautils_add_shared_options(octx, "ipaimport");

    g_option_context_parse(octx, argc, argv, &oerr);

    if (oerr) {
        g_critical("Couldn't parse command line: %s\nUse --help for usage.",
                   oerr->message);
        return FALSE;
    }

    if (ipautils_handle_shared_options(octx) ) {
        return FALSE;
    }

    g_option_context_free(octx);
    return TRUE;
} /* ipaimport_opt_parse */

static void ipaimport_msg(
    GScanner *scanner,
    char     *message,
    gboolean  error)
{
    if (error) {
        g_critical("Error at line %u, position %u in expression: %s.",
                   scanner->line, scanner->position, message);
    } else {
        g_warning("Warning at line %u, position %u in expression: %s.",
                  scanner->line, scanner->position, message);
    }
} /* ipaimport_msg */

int ipaimport_scan_line(
    IPAContext *ipa,
    GScanner   *scanner,
    GString    *line)
{
    uint32_t a            = 0;
    uint32_t b            = 0;
    int i                 = 0;
    char *label           = NULL;
    uint64_t value        = 0;
    static gboolean found = FALSE;
    gboolean dotted       = FALSE;
    gchar  **vec          = NULL;
    int rv                = FALSE;

    g_scanner_input_text(scanner, line->str, strlen(line->str));

    if (!ipautils_scan_range(scanner, &a, &b)) {
        goto err;
    }

    switch (ipa->cat_type) {
      case IPA_CAT_NONE:
        g_critical("invalid catalog type");
        goto err;
        break;
      case IPA_CAT_SET:
        return ipa_add_assoc(ipa, a, b, NULL, 0);
      case IPA_CAT_BAG:
        if (g_scanner_peek_next_token(scanner) == G_TOKEN_EOF) {
            g_critical("end of line while parsing bag value");
            goto err;
        }
        /* Erase what we've read so far */
        line = g_string_erase(line, 0, g_scanner_cur_position(scanner));

        vec = g_strsplit_set(line->str, delim, 0);
        for (i = 0; vec && vec[i] != NULL; i++) {
            g_strchug(vec[i]);
            g_strchomp(vec[i]);
            if (strlen(vec[i]) >= 1) {
                found = TRUE;
                break;
            }
        }

        if (!found) {
            g_critical("parse error finding bag value");
            goto err;
        }
        value = strtoll(vec[i], NULL, 10);
        return ipa_add_assoc(ipa, a, b, NULL, value);
      case IPA_CAT_PMAP:
        if (g_scanner_peek_next_token(scanner) == G_TOKEN_EOF) {
            g_critical("end of line while parsing pmap label");
            goto err;
        }
        /* Erase what we've read so far */
        line = g_string_erase(line, 0, g_scanner_cur_position(scanner));

        vec = g_strsplit_set(line->str, delim, 0);
        for (i = 0; vec && vec[i] != NULL; i++) {
            g_strchug(vec[i]);
            g_strchomp(vec[i]);
            if (strlen(vec[i]) >= 1) {
                found = TRUE;
                break;
            }
        }
        if (!found) {
            g_critical("parse error finding pmap label");
            goto err;
        }
        return ipa_add_assoc(ipa, a, b, vec[i], 0);
      case IPA_CAT_MMAP:
        if (g_scanner_peek_next_token(scanner) == G_TOKEN_EOF) {
            g_critical("end of line while parsing pmap/mmap value");
            goto err;
        }
        /* Erase what we've read so far */
        line = g_string_erase(line, 0, g_scanner_cur_position(scanner));

        vec = g_strsplit_set(line->str, delim, 0);
        for (i = 0; vec && vec[i] != NULL; i++) {
            g_strchug(vec[i]);
            g_strchomp(vec[i]);
            if (strlen(vec[i]) >= 1) {
                label = vec[i];
                break;
            }
        }
        if (!label) {
            g_critical("parse error finding mmap label");
            goto err;
        }
        i++;
        found = FALSE;

        for (; vec && vec[i] != NULL; i++) {
            g_strchug(vec[i]);
            g_strchomp(vec[i]);
            if (strlen(vec[i]) >= 1) {
                found = TRUE;
                break;
            }
        }
        if (!found) {
            g_critical("parse error finding mmap value");
            goto err;
        }
        value = strtoll(vec[i], NULL, 10);
        return ipa_add_assoc(ipa, a, b, label, value);
      default:
        g_critical("unknown catalog type");
        goto err;
    } /* switch */

    rv = TRUE;
    goto done;

  err:
    g_scanner_error(scanner, "Scanner error");
    rv = FALSE;

  done:
    if (vec) g_strfreev(vec);
    return rv;
    
} /* ipaimport_scan_line */

/*
 * accepts ranges in any of the following formats (ignores whitespace):
 * single dotted quad address: 192.168.1.0
 * single integer address:     3232235776
 * dotted quad address range:  192.168.1.0 - 192.168.1.255
 * class C range:              192.168.1.0-255
 * integer address range:      3232235776 - 3232236031
 * CIDR block:                 192.168.1.0 / 24
 * CIDR block with int addr:   3232235776 / 24
 */
gboolean ipaimport_process_file(
    IPAContext *ipa,
    GIOChannel *in)
{
    GString  *line = NULL;
    GError   *err  = NULL;
    GScanner *scanner;
    gboolean  rv = TRUE;
    GIOStatus status;
    int records          = 0;
    GTimer *import_timer = NULL;
    gdouble elapsed_time;

    GScannerConfig scancfg;

    /* configure scanner */
    scancfg.cset_skip_characters  = " \t\r\n";
    scancfg.cset_identifier_first = G_CSET_a_2_z
                                    G_CSET_A_2_Z
                                    "_";

    scancfg.cset_identifier_nth = G_CSET_a_2_z
                                  G_CSET_A_2_Z
                                  G_CSET_LATINS
                                  G_CSET_LATINC
                                  "_0123456789";
    scancfg.cpair_comment_single  = "#\n";
    scancfg.case_sensitive        = 0;
    scancfg.skip_comment_multi    = 1;
    scancfg.skip_comment_single   = 1;
    scancfg.scan_comment_multi    = 0;
    scancfg.scan_identifier       = 1;
    scancfg.scan_identifier_1char = 0;
    scancfg.scan_identifier_NULL  = 0;
    scancfg.scan_symbols          = 1;
    scancfg.scan_binary           = 0;
    scancfg.scan_octal            = 0;
    scancfg.scan_float            = 0;
    scancfg.scan_hex              = 1;
    scancfg.scan_hex_dollar       = 0;
    scancfg.scan_string_sq        = 0;
    scancfg.scan_string_dq        = 0;
    scancfg.numbers_2_int         = 1;
    scancfg.int_2_float           = 0;
    scancfg.identifier_2_string   = 0;
    scancfg.char_2_token          = 1;
    scancfg.symbol_2_token        = 1;
    scancfg.scope_0_fallback      = 0;
    scancfg.store_int64           = 1;

    /* create scanner */
    scanner = g_scanner_new(&scancfg);

    /* set error handler */
    scanner->msg_handler = ipaimport_msg;

    line = g_string_new("");

    import_timer = g_timer_new();

    ipa_begin(ipa);

    if (append) {
        if (ipa_get_dataset(ipa, catalog_name,
                            start_time_str) != IPA_OK)
        {
            g_critical(
                "cannot append -- dataset not found for given start time");
            rv = FALSE;
            goto END;
        }
        /* FIXME: control this with command line switch? */
        ipa_extend_dataset(ipa, end_time_str);

    } else {
        if (ipa_add_dataset(ipa, catalog_name, catalog_desc, catalog_type,
                            start_time_str, end_time_str) != IPA_OK)
        {
            /* Error has already been printed */
            rv = FALSE;
            goto END;
        }
    }


    while ( (status = g_io_channel_read_line_string(in, line, NULL,
                                                    &err) ))
    {
        switch (status) {
          case G_IO_STATUS_ERROR:
            g_error("read error while importing");
            return FALSE;
          case G_IO_STATUS_EOF:
            if (records > 0)
            {
                ipa_commit(ipa);
            }
            else
            {
                ipa_rollback(ipa);
                g_critical("no records imported\n");
            }
            rv = TRUE;
            goto END;
          default:
            break;
        } /* switch */
        g_strstrip(line->str);
        if (strlen(line->str) == 0)
            continue;
        if (ipaimport_scan_line(ipa, scanner, line) ) {
            g_critical("error importing line %d\n", records);
            ipa_rollback(ipa);
            records = 0;
            rv      = FALSE;
            goto END;
        }
        records++;
        if (progress_interval && !(records % progress_interval)) {
            elapsed_time = g_timer_elapsed(import_timer, NULL);
            printf("%u (%f/s)\n", records, records/elapsed_time);
        }
    }

  END:

    if (scanner) g_scanner_destroy(scanner);
    g_timer_stop(import_timer);
    elapsed_time = g_timer_elapsed(import_timer, NULL);

    printf("%d records imported in %fs (%f/s)\n", records, elapsed_time,
           records/elapsed_time);

    return rv;
} /* ipaimport_process_file */


int main(
    int   argc,
    char *argv[])
{
    GIOChannel *in;
    GError     *err = NULL;
    int rv          = 0;
    char *filename  = NULL;
    IPAContext *ipa = NULL;

    if (ipaimport_opt_parse(&argc, &argv)) {
        rv = -1;
        goto END;
    }
    if (catalog_type == IPA_CAT_NONE && !append) {
        g_critical("You must specifiy a valid catalog type");
        rv = -1;
        goto END;
    }

    if ( (start_time_str == NULL) ^ (end_time_str == NULL)  ) {
        g_critical(
            "Incomplete time range specified.  You must specify\n"
            "start and end timestamps for the imported dataset.");
        rv = -1;
        goto END;
    }

    if (catalog_name == NULL) {
        g_critical("You must supply a catalog name to import into");
        rv = -1;
        goto END;
    }

    if (ipa_create_context(&ipa, ipa_db_uri, NULL) != IPA_OK) {
        g_critical("couldn't create IPA context");
        rv = -1;
        goto END;
    }
    /* ipa->verbose = TRUE; */

    if (argc >= 1) {
        filename = argv[1];
    }
    if (!filename || !strcmp(filename, "")) {
        in = g_io_channel_unix_new(STDIN_FILENO);
    } else {
        in = g_io_channel_new_file(filename, "r", &err);
    }
    if (err != NULL) {
        g_critical("couldn't open input file: %s", err->message);
        rv = -1;
        goto END;
    }

    if (g_io_channel_set_encoding(in, NULL,
                                  NULL) != G_IO_STATUS_NORMAL)
    {
        g_error("could not set encoding for infile");
    }

    ipaimport_process_file(ipa, in);

    g_io_channel_shutdown(in, TRUE, &err);

  END:
    if (ipa != NULL)
        ipa_destroy_context(&ipa);
    return rv;
} /* main */
