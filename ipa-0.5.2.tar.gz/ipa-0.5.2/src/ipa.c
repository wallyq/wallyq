/*
** ipa.c
** IP Association Library Implementation
**
** ------------------------------------------------------------------------
** Copyright (C) 2006-2010 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov <tonyc@cert.org>
**          Brian Trammell <bht@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.225-7013
** ------------------------------------------------------------------------
*/

#include <stdlib.h>
#include <limits.h>

#include <ipa/ipa.h>

static char *RCSID __attribute__ ((unused)) =
    "$Id: ipa.c 15339 2010-02-18 23:34:02Z tonyc $";


GScannerConfig scancfg;
static void ipaquery_msg(
    GScanner *scanner,
    char     *message,
    gboolean  error)
{
    if (error) {
        g_critical("Error at line %u, position %u in expression: %s.",
                   scanner->line, scanner->position, message);
    } else {
        g_warning("Warning at line %u, position %u in expression: %s.",
                  scanner->line, scanner->position, message);
    }
} /* ipaquery_msg */


uint32_t ipa_mask_from_prefix(
    uint32_t pfx)
{
    uint32_t mask = 0;
    uint32_t i    = 0;

    for (i = 0; i < pfx; i++) {
        mask >>= 1;
        mask  |= 0x80000000U;
    }

    return mask;
} /* ipa_mask_from_prefix */

int ipa_create_context(
    IPAContext **ipa,
    char        *db_uri,
    char        *uname)
{
    GError *err = NULL;
    AdbStatement *stmt;
    /* configure scanner */
    scancfg.cset_skip_characters  = " \t\r\n";
    scancfg.cset_identifier_first = G_CSET_a_2_z
        G_CSET_A_2_Z
        G_CSET_LATINS
        G_CSET_LATINC
        "_=^";

    scancfg.cset_identifier_nth = G_CSET_a_2_z
        G_CSET_A_2_Z
        G_CSET_LATINS
        G_CSET_LATINC
        G_CSET_DIGITS
        "=_.,|^$*[]+\\";
    scancfg.cpair_comment_single  = "#\n";
    scancfg.case_sensitive        = 0;
    scancfg.skip_comment_multi    = 1;
    scancfg.skip_comment_single   = 1;
    scancfg.scan_comment_multi    = 0;
    scancfg.scan_identifier       = 1;
    scancfg.scan_identifier_1char = 1;
    scancfg.scan_identifier_NULL  = 0;
    scancfg.scan_symbols          = 1;
    scancfg.scan_binary           = 0;
    scancfg.scan_octal            = 0;
    scancfg.scan_float            = 0;
    scancfg.scan_hex              = 1;
    scancfg.scan_hex_dollar       = 0;
    scancfg.scan_string_sq        = 1;
    scancfg.scan_string_dq        = 1;
    scancfg.numbers_2_int         = 0;
    scancfg.int_2_float           = 0;
    scancfg.identifier_2_string   = 1;
    scancfg.char_2_token          = 1;
    scancfg.symbol_2_token        = 1;
    scancfg.scope_0_fallback      = 0;
    scancfg.store_int64           = 1;

    /* If the caller passes in NULL, look in the environment */
    if (db_uri == NULL) {
        db_uri = getenv(ENV_IPA_DB_URI);
    }
    /* If it's still NULL, no can do */
    if (db_uri == NULL) {
        g_critical("no IPA database specified");
        return IPA_ERR_INVALID;
    }

    *ipa = g_new0(IPAContext, 1);

    (*ipa)->db_uri = strdup(db_uri);
    /* create connection */
    if (!( (*ipa)->conn = adb_conn_create(db_uri, &err))) {
        IPA_CHECK_ERR(err, "error in SQL connection create", IPA_ERR_SQL);
    }

    /* Open it */
    if (!adb_conn_open((*ipa)->conn, &err)) {
        IPA_CHECK_ERR(err, "error in SQL connection open", IPA_ERR_SQL);
    }
    stmt = adb_stmt_prepare((*ipa)->conn,
                            "SET search_path TO ipa, public;", 0, &err);
    adb_stmt_execute(stmt, &err);
    adb_stmt_free(stmt);


    (*ipa)->sql     = g_string_new("");
    (*ipa)->scanner = g_scanner_new(&scancfg);
    (*ipa)->state   = IPA_STATE_INITIAL;
    (*ipa)->verbose = FALSE;
    (*ipa)->stmt    = NULL;

    if (uname)
    {
        (*ipa)->uname   = g_strdup(uname);
    }
    else
    {
        struct passwd *pwd;
        pwd = getpwuid(getuid());
        (*ipa)->uname = g_strdup(pwd->pw_name);
    }

    /* set error handler */
    (*ipa)->scanner->msg_handler = ipaquery_msg;


    /* load symbols into the scanner */
    while (symbols_main_p->symbol_name) {
        g_scanner_scope_add_symbol((*ipa)->scanner, 0,
                                   symbols_main_p->symbol_name,
                                   GINT_TO_POINTER(symbols_main_p->
                                                   symbol_token));
        symbols_main_p++;
    }

    while (symbols_find_p->symbol_name) {
        g_scanner_scope_add_symbol((*ipa)->scanner, IPAQUERY_FIND,
                                   symbols_find_p->symbol_name,
                                   GINT_TO_POINTER(symbols_find_p->
                                                   symbol_token));
        symbols_find_p++;
    }

    while (symbols_none_p->symbol_name) {
        g_scanner_scope_add_symbol((*ipa)->scanner, IPAQUERY_NONE,
                                   symbols_find_p->symbol_name,
                                   GINT_TO_POINTER(symbols_none_p->
                                                   symbol_token));
        symbols_none_p++;
    }


    return IPA_OK;
} /* ipa_create_context */

void ipa_destroy_context(
    IPAContext **ipa)
{
    g_assert(ipa);
    if ((*ipa)->stmt) {
        adb_stmt_free((*ipa)->stmt);
        (*ipa)->stmt = NULL;
    }
    if ((*ipa)->conn) {
        adb_conn_close( (*ipa)->conn, NULL);
        (*ipa)->conn = NULL;
    }
    if ((*ipa)->db_uri) {
        free((*ipa)->db_uri);
        (*ipa)->db_uri = NULL;
    }
    if ((*ipa)->scanner) {
        g_scanner_destroy((*ipa)->scanner);
        (*ipa)->scanner = NULL;
    }

    if (*ipa) free(*ipa);
    *ipa = NULL;
} /* ipa_destroy_context */


int ipa_statement_execute(
    IPAContext *ipa)
{
    GError *err = NULL;
    /* Prepare the statement */
    if (ipa->sql == NULL) {
        g_error("error: sql string is empty");
        return IPA_ERR_UNKNOWN;
    }
    if (!(ipa->stmt = adb_stmt_prepare(ipa->conn,
                                       ipa->sql->str, 0, &err)))
    {
        IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
    }
    adb_stmt_execute(ipa->stmt, &err);
    IPA_CHECK_ERR(err, "error in SQL statement execute", IPA_ERR_SQL);
#if 0
    if (ipa->stmt) {
        adb_stmt_free(ipa->stmt);
        ipa->stmt = NULL;
    }
#endif /* if 0 */
    return IPA_OK;
} /* ipa_statement_execute */

int ipa_statement_query(
    IPAContext *ipa)
{
    GError *err = NULL;
    /* Prepare the statement */
    if (!(ipa->stmt = adb_stmt_prepare(ipa->conn, ipa->sql->str, 0, &err))) {
        IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
    }

    ipa->rs = adb_stmt_query(ipa->stmt, &err);
    IPA_CHECK_ERR(err, "error in SQL query", IPA_ERR_SQL);
#if 0
    if (ipa->stmt) {
        adb_stmt_free(ipa->stmt);
        ipa->stmt = NULL;
    }
#endif /* if 0 */
    return IPA_OK;
} /* ipa_statement_query */

#define IPA_ADD_DATASET_SQL \
    "SELECT add_dataset(:catname, :type, :catdesc, :begin, :end, :uname)"

#define IPA_ADD_ASSOC_SQL \
    "SELECT add_assoc(:dataset, :addr1::bigint::ip4, :addr2::bigint::ip4, :label, :value, :uname)"


int ipa_add_dataset(
    IPAContext    *ipa,
    const char    *catname,
    const char    *catdesc,
    IPACatalogType type,
    const char    *begin,
    const char    *end)
{
    GError *err     = NULL;
    const char *val = NULL;
    int rc          = IPA_OK;
    GString *str    = NULL;
    char    *param  = NULL;


    str = g_string_new("");

    if (!catname || !strlen(catname)
        || strlen(catname) >= IPA_CAT_LEN)
    {
        g_critical("IPA catalog names must be less than %u characters long",
                   IPA_CAT_LEN);
        rc = IPA_ERR_INVALID;
        goto end;
    }

    if (!(ipa->stmt = adb_stmt_prepare(ipa->conn,
                                       IPA_ADD_DATASET_SQL, 0, &err)))
    {
        IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
    }

    if (!adb_stmt_bind_named(ipa->stmt, "catname", catname, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (!adb_stmt_bind_named(ipa->stmt, "catdesc", catdesc, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    g_string_printf(str, "%u", type);
    if (!adb_stmt_bind_named(ipa->stmt, "type", str->str, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (begin == NULL) {
        g_critical("missing begin timestamp for dataset");
        rc = IPA_ERR_INVALID;
        goto end;
    }
    g_string_printf(str, "%s", begin);
    param = str->str;
    if (!adb_stmt_bind_named(ipa->stmt, "begin", param, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (begin == NULL) {
        g_critical("missing end timestamp for dataset");
        rc = IPA_ERR_INVALID;
        goto end;
    }
    g_string_printf(str, "%s", end);
    param = str->str;
    if (!adb_stmt_bind_named(ipa->stmt, "end", param, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (!adb_stmt_bind_named(ipa->stmt, "uname", ipa->uname, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    ipa->rs = adb_stmt_query(ipa->stmt, &err);
    IPA_CHECK_ERR(err, "error in add dataset query", IPA_ERR_SQL);

    adb_rs_next(ipa->rs, &err);
    IPA_CHECK_ERR(err, "error getting next record", IPA_ERR_SQL);

    adb_rs_fetch(ipa->rs, 0, &val, &err);
    IPA_CHECK_ERR(err, "error fetching from SQL result set", IPA_ERR_SQL);

    ipa->ds_id    = strtoll(val, (char **) NULL, 10);
    ipa->cat_type = type;

  end:

    g_string_free(str, TRUE);
    return rc;

} /* ipa_add_dataset */

#define IPA_EXTEND_DATASET_SQL \
    "UPDATE dataset SET t_end=:end WHERE dataset_id=:dataset;"

int ipa_extend_dataset(
    IPAContext *ipa,
    const char *end)
{
    GError *err     = NULL;
    const char *val = NULL;
    int rc          = IPA_OK;
    GString *str    = NULL;
    char    *param  = NULL;

    str = g_string_new("");

    if (!(ipa->stmt = adb_stmt_prepare(ipa->conn,
                                       IPA_EXTEND_DATASET_SQL, 0, &err)))
    {
        IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
    }


    g_string_printf(str, "%" PRIu64, ipa->ds_id);
    if (!adb_stmt_bind_named(ipa->stmt, "dataset", str->str, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (!adb_stmt_bind_named(ipa->stmt, "end", end, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    ipa->rs = adb_stmt_query(ipa->stmt, &err);
    IPA_CHECK_ERR(err, "error in extend dataset query", IPA_ERR_SQL);

  end:

    g_string_free(str, TRUE);
    return rc;

} /* ipa_extend_dataset */

int ipa_add_assoc(
    IPAContext *ipa,
    uint32_t    addr1,
    uint32_t    addr2,
    char       *label,
    uint64_t    value)
{
    int rc         = IPA_OK;
    GError  *err   = NULL;
    GString *str   = NULL;
    char    *param = NULL;

    g_assert(ipa);

    str = g_string_new("");

    if (ipa->state != IPA_STATE_IMPORT) {
        /* Prepare add range statement */

        g_string_printf(ipa->sql, "SELECT start_bulkload_assoc_count();");

        if (!(ipa->stmt = adb_stmt_prepare(ipa->conn,
                                           ipa->sql->str, 0, &err)))
        {
            IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
        }

        if (!adb_stmt_execute(ipa->stmt, &err) ) {
            IPA_CHECK_ERR(err, "error in SQL statement execute", IPA_ERR_SQL);
        }

        adb_stmt_free(ipa->stmt);

        if (!(ipa->stmt = adb_stmt_prepare(ipa->conn,
                                           IPA_ADD_ASSOC_SQL, 0, &err)))
        {
            IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
        }

        ipa->state = IPA_STATE_IMPORT;
    }

    g_string_printf(str, "%" PRIu64, ipa->ds_id);
    if (!adb_stmt_bind_named(ipa->stmt, "dataset", str->str, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    g_string_printf(str, "%" PRIu32, addr1);
    if (!adb_stmt_bind_named(ipa->stmt, "addr1", str->str, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    g_string_printf(str, "%" PRIu32, addr2);
    if (!adb_stmt_bind_named(ipa->stmt, "addr2", str->str, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (ipa->cat_type == IPA_CAT_SET || ipa->cat_type == IPA_CAT_BAG) {
        param = NULL;
    } else {
        g_string_printf(str, "%s", label);
        param = str->str;
    }

    if (!adb_stmt_bind_named(ipa->stmt, "label", param, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (ipa->cat_type == IPA_CAT_BAG || ipa->cat_type == IPA_CAT_MMAP) {
        g_string_printf(str, "%" PRIu64, value);
        param = str->str;
    } else {
        param = NULL;
    }

    if (!adb_stmt_bind_named(ipa->stmt, "value", param, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    if (!adb_stmt_bind_named(ipa->stmt, "uname", ipa->uname, &err)) {
        rc = IPA_ERR_SQL;
        goto end;
    }

    adb_stmt_execute(ipa->stmt, &err);

    IPA_CHECK_ERR(err, "error in SQL statement execute", IPA_ERR_SQL);

  end:

    g_string_free(str, TRUE);
    return rc;


} /* ipa_add_assoc */

int ipa_add_cidr(
    IPAContext *ipa,
    uint32_t    addr,
    uint32_t    prefix,
    char       *label,
    uint64_t    value)
{
    uint32_t addr2, mask;

    mask  = ipa_mask_from_prefix(prefix);
    addr &= mask;
    addr2 = addr | (~mask);

    return ipa_add_assoc(ipa, addr, addr2, label, value);

} /* ipa_add_cidr */

void ipa_begin(
    IPAContext *ipa)
{
    GError *err = NULL;

    /* Start the transaction */
    if (!adb_transaction_begin(ipa->conn, &err))
        g_error("%s", err->message);
} /* ipa_begin */

void ipa_commit(
    IPAContext *ipa)
{
    GError *err = NULL;
    if (ipa->state == IPA_STATE_IMPORT) {
        g_string_printf(ipa->sql, "SELECT end_bulkload_assoc_count();");

        ipa->stmt = adb_stmt_prepare(ipa->conn,
                                     ipa->sql->str, 0, &err);
        adb_stmt_execute(ipa->stmt, &err);
    }

    adb_transaction_commit(ipa->conn, &err);
    if (ipa->stmt) {
        adb_stmt_free(ipa->stmt);
        ipa->stmt = NULL;
    }
    ipa->ds_id    = 0;
    ipa->cat_type = IPA_CAT_NONE;

} /* ipa_commit */

void ipa_rollback(
    IPAContext *ipa)
{
    GError *err = NULL;
    adb_transaction_rollback(ipa->conn, &err);
    ipa->ds_id    = 0;
    ipa->cat_type = IPA_CAT_NONE;
} /* ipa_rollback */

int ipa_get_dataset(
    IPAContext *ipa,
    const char *catalog_name,
    const char *dataset_time)
{
    int rc            = IPA_OK;
    GError *err       = NULL;
    const char *val   = NULL;
    GString    *str   = NULL;
    char       *param = NULL;

    GTimeVal current_time;
    char *current_time_str;

    char *catalog_path = NULL;

    g_assert(ipa);

    g_get_current_time(&current_time);

    current_time_str = g_time_val_to_iso8601(&current_time);

    str = g_string_new("");

    g_string_printf
        (ipa->sql,
         "SELECT dataset_id, catalog_type "
         "FROM dataset_view "
         "WHERE TRUE "
         );

#if 0
    if (catalog_name) {
        if (catalog_name[0] == '=')
        {
            /* Literal match */
            g_string_append_printf(ipa->sql, "AND dataset_path LIKE '%s/%%'\n", catalog_name+1);
        }
        else
        {
            /* Regular expression match */
            g_string_append_printf(ipa->sql, "AND dataset_path ~* '%s'\n", catalog_name);
        }
    }
#else
    g_string_append_printf(ipa->sql, "AND dataset_path LIKE '%s/%%'\n", catalog_name);
#endif

    g_string_append_printf(ipa->sql, 
                           "AND (:time::timestamp, :time::timestamp) "
                           "OVERLAPS (t_begin, t_end)"
                           );


    if (!(ipa->stmt = adb_stmt_prepare(ipa->conn,
                                       ipa->sql->str, 0, &err)))
    {
        IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
    }

    if (dataset_time == NULL) {
        param = current_time_str;
    } else {
        g_string_printf(str, "%s", dataset_time);
        param = str->str;
    }

    if (!adb_stmt_bind_named(ipa->stmt, "time", param, &err)) {
        g_critical("couldn't bind time");
        rc = IPA_ERR_SQL;
        goto end;
    }

    ipa->rs = adb_stmt_query(ipa->stmt, &err);

    IPA_CHECK_ERR(err, "error retrieving dataset", IPA_ERR_SQL);

    if (!adb_rs_next(ipa->rs, &err)) {
        IPA_CHECK_ERR(err, "error fetching from SQL result set", IPA_ERR_SQL);
        return IPA_ERR_NOTFOUND;
    }

    adb_rs_fetch(ipa->rs, 0, &val, &err);
    IPA_CHECK_ERR(err, "error fetching from SQL result set", IPA_ERR_SQL);

    ipa->ds_id = strtoll(val, NULL, 10);

    adb_rs_fetch(ipa->rs, 1, &val, &err);
    IPA_CHECK_ERR(err, "error fetching from SQL result set", IPA_ERR_SQL);

    ipa->cat_type = (IPACatalogType) strtol(val, NULL, 10);

  end:
    g_string_free(str, TRUE);

    return rc;
} /* ipa_get_dataset */

int ipa_get_assoc(
    IPAContext *ipa,
    IPAAssoc   *assoc)
{
    GError *err     = NULL;
    const char *val = NULL;

    g_assert(ipa);

    if (ipa->state != IPA_STATE_EXPORT) {
        g_string_printf(ipa->sql,
                        "SELECT a.range, "
                        "lower(a.range)::bigint AS begin, "
                        "upper(a.range)::bigint AS end, "
                        "l.name, a.value "
                        "FROM assoc a "
                        "LEFT JOIN label l ON a.label_id=l.label_id "
                        "WHERE a.dataset_id=%" PRIu64 ";",
                        ipa->ds_id);

        ipa_statement_query(ipa);
        IPA_CHECK_ERR(err, "error retrieving range dataset", IPA_ERR_SQL);

        ipa->state = IPA_STATE_EXPORT;
    }

    if (!adb_rs_next(ipa->rs, &err)) {
        IPA_CHECK_ERR(err, "error fetching range record", IPA_ERR_SQL);
        return -1;
    }
    adb_rs_fetch_buf(ipa->rs, 0, assoc->range, IPA_RANGE_LEN, &err);
    IPA_CHECK_ERR(err, "error fetching range", IPA_ERR_SQL);

    adb_rs_fetch(ipa->rs, 1, &val, &err);
    IPA_CHECK_ERR(err, "error fetching begin", IPA_ERR_SQL);
    assoc->begin = strtoll(val, NULL, 10);

    adb_rs_fetch(ipa->rs, 2, &val, &err);
    IPA_CHECK_ERR(err, "error fetching end", IPA_ERR_SQL);
    assoc->end = strtoll(val, NULL, 10);

    adb_rs_fetch_buf(ipa->rs, 3, assoc->label, IPA_LABEL_LEN, &err);
    IPA_CHECK_ERR(err, "error fetching label", IPA_ERR_SQL);

    adb_rs_fetch_buf(ipa->rs, 4, assoc->value, IPA_VALUE_LEN, &err);
    IPA_CHECK_ERR(err, "error fetching value", IPA_ERR_SQL);
    return IPA_OK;
} /* ipa_get_assoc */

void ipa_get_column_widths(
    IPAContext *ipa,
    GArray     *columns
    )
{
    int i = 0, j = 0, rows = 0, cols = 0, len = 0, min_width = 0;
    IPAColumn *column;
    GError    *err = NULL;
    g_assert(ipa->rs);
    g_assert(columns);

    rows = adb_rs_row_count(ipa->rs, &err);
    cols = columns->len;

    for (i = 0; i < cols; i++) {
        column    = &g_array_index(columns, IPAColumn, i);
        min_width = strlen(column->label);
        if (column->width) {
            if (column->width < min_width) {
                column->width = min_width;
            }
            continue;
        }

        column->width = min_width;
        for (j = 0; j < rows; j++) {
            len = adb_rs_field_width(ipa->rs, j, i, &err);
            if (len > column->width) {
                column->width = len;
            }
        }
    }
} /* ipa_get_column_widths */


int ipa_do_assoc_query(
    IPAContext *ipa,
    const char *catalog,
    const char *range,
    const char *label,
    const char *value,
    const char *t1,
    const char *t2,
    int displayfields
    )
{
    GError  *err         = NULL;
    GString *catalog_sql = NULL, *dataset_sql = NULL, *addr_sql = NULL;
    GString *fields_sql  = NULL, *label_sql = NULL, *value_sql = NULL;
    gchar **vec = NULL;
    int i;

    int rv = IPA_ERR_UNKNOWN;

    fields_sql = g_string_new("");

    if (displayfields & IPA_COL_CATALOG)
    {
        if (fields_sql->len > 0)  g_string_append(fields_sql, ",\n");
        g_string_append(fields_sql, "dv.catalog_path");
    }

    if (displayfields & IPA_COL_START)
    {
        if (fields_sql->len > 0)  g_string_append(fields_sql, ",\n");
        g_string_append(fields_sql,
                        "(SELECT TO_CHAR(t_begin, 'YYYY/MM/DD:HH24:MI:SS')) AS t_begin"
                        );
    }

    if (displayfields & IPA_COL_END)
    {
        if (fields_sql->len > 0)  g_string_append(fields_sql, ",\n");
        g_string_append(fields_sql,
                        "(SELECT TO_CHAR(t_end, 'YYYY/MM/DD:HH24:MI:SS')) AS t_end"
                        );
    }

    if (displayfields & IPA_COL_RANGE)
    {
        if (fields_sql->len > 0)  g_string_append(fields_sql, ",\n");
        g_string_append(fields_sql, "range");
    }

    if (displayfields & IPA_COL_LABEL)
    {
        if (fields_sql->len > 0)  g_string_append(fields_sql, ",\n");
        g_string_append(fields_sql, "(SELECT name FROM label l WHERE l.label_id=a.label_id) AS label");
    }

    if (displayfields & IPA_COL_VALUE)
    {
        if (fields_sql->len > 0)  g_string_append(fields_sql, ",\n");
        g_string_append(fields_sql, "value");
    }

    g_string_append(fields_sql, "\n");

    catalog_sql = g_string_new("");
    dataset_sql = g_string_new("");
    addr_sql    = g_string_new("");
    label_sql   = g_string_new("");
    value_sql   = g_string_new("");

    g_string_printf(
        ipa->sql,
        "SELECT %s\n"
        "FROM assoc a "
        "LEFT JOIN label l ON a.label_id=l.label_id "
        "JOIN dataset_view dv "
        "ON a.dataset_id=dv.dataset_id "
        "WHERE true\n", fields_sql->str);


    if (catalog) {
#if 1
        g_string_append_printf(ipa->sql, "AND dv.catalog_path ~* ANY (ARRAY[\n");
        vec = g_strsplit(catalog, " ", 0);

        for (i = 0; vec && vec[i] != NULL; i++) {
            if (i > 0) g_string_append(ipa->sql, ",");
            if (vec[i][0] == '/')
            {
                int len = strlen(vec[i]);
                if (vec[i][len-1] == '/')
                {
                    vec[i][len-1] = '\0';
                    g_string_append_printf(ipa->sql, "'%s'", vec[i]+1);
                    vec[i][len-1] = '/';
                }
                else
                {
                    g_critical("parse error in catalog argument");
                }
            }
            else
            {
                g_string_append_printf(ipa->sql, "'^%s$'", vec[i]);
            }
        }
        if (vec) {
            g_strfreev(vec);
            vec = NULL;
        }
        g_string_append_printf(ipa->sql, "])\n");
#else
        if (catalog[0] == '=')
        {
            /* Literal match */
            g_string_append_printf(ipa->sql, "AND dv.catalog_path ~* '^%s$'\n", catalog+1);
        }
        else
        {
            /* Regular expression match */
            g_string_append_printf(ipa->sql, "AND dv.catalog_path ~* '%s'\n", catalog);
        }
#endif
    }

    if (t1 || t2) {
        g_string_append_printf(ipa->sql, "AND ('%s'::timestamp, '%s'::timestamp) OVERLAPS (t_begin, t_end)\n",
                               t1, (t2 ? t2 : t1));
                               //                               (t1 ? t1 : '-infinity'), (t2 ? t2 : 'infinity'));
    }

    if (range) {
        g_string_append_printf(ipa->sql, "AND '%s' && range\n", range);
    }

    if (label) {

        int i = 0;

        g_string_printf(
            label_sql,
            "\tAND l.name IN ( ");

        vec = g_strsplit(label, ",", 0);
        for (i = 0; vec && vec[i] != NULL; i++) {
            if (i > 0) g_string_append(label_sql, ",");
            g_string_append_printf(label_sql, "'%s'", vec[i]);
        }

        g_string_append(label_sql, "\t)\n\n");

        g_string_append(ipa->sql, label_sql->str);

        if (vec) {
            g_strfreev(vec);
            vec = NULL;
        }

    }

    if (value) {
        uint32_t val = 0;
        
        if (strstr(value, "-"))
        {
            /* Value range query */
            vec = g_strsplit(value, "-", 0);
            val = strtoll(vec[0], NULL, 10);
            if (errno) {
                rv = IPA_ERR_INVALID;
                goto done;
            }

            /* Lower bound */
            g_string_printf(value_sql, "\nAND a.value >= %d", val);

            if (vec[1] != NULL)
            {
                val = strtoll(vec[1], NULL, 10);
                if (errno) {
                    rv = IPA_ERR_INVALID;
                    goto done;
                }
                /* Upper bound */
                g_string_append_printf(value_sql, "\nAND a.value <= %d", val);
            }    
        }
        else
        {
            /* Simple equality query */
            val = strtoll(value, NULL, 10);
            if (errno) {
                rv = IPA_ERR_INVALID;
                goto done;
            }

            g_string_printf(value_sql, "\nAND a.value = %d", val);
        }
        
        if (vec) {
            g_strfreev(vec);
            vec = NULL;
        }
        g_string_append(ipa->sql, value_sql->str);
    }



    if (ipa->verbose) g_printerr("%s", ipa->sql->str);

    if (!(ipa->stmt = adb_stmt_prepare(ipa->conn,
                                       ipa->sql->str, 0, &err)))
    {
        IPA_CHECK_ERR(err, "error in SQL statement prepare", IPA_ERR_SQL);
    }

    ipa_statement_query(ipa);
    IPA_CHECK_ERR(err, "error in SQL query", IPA_ERR_SQL);
    rv = IPA_OK;

  done:
    g_string_free(catalog_sql, TRUE);
    g_string_free(dataset_sql, TRUE);
    g_string_free(addr_sql, TRUE);
    g_string_free(label_sql, TRUE);
    g_string_free(value_sql, TRUE);
    
    ipa->state = IPA_STATE_QUERY;
    rv = IPA_OK;
    return rv;
} /* ipa_do_assoc_query */



int ipa_get_next_assoc(
    IPAContext *ipa,
    IPAAssoc   *assoc)
{
    int i           = 0;
    GError *err     = NULL;
    const char *val = NULL;

    g_assert(ipa->rs);

    if (!adb_rs_next(ipa->rs, &err)) {
        IPA_CHECK_ERR(err, "error fetching range record", IPA_ERR_SQL);
        return IPA_ERR_NOTFOUND;
    }

    adb_rs_fetch_buf(ipa->rs, 0, assoc->catalog, IPA_CAT_LEN, &err);
    IPA_CHECK_ERR(err, "error fetching range", IPA_ERR_SQL);

    /* FIXME: do we need to fill in t1 and t2 here? */

    adb_rs_fetch_buf(ipa->rs, 3, assoc->range, IPA_RANGE_LEN, &err);
    IPA_CHECK_ERR(err, "error fetching range", IPA_ERR_SQL);

    adb_rs_fetch_buf(ipa->rs, 4, assoc->label, IPA_LABEL_LEN, &err);
    IPA_CHECK_ERR(err, "error fetching label", IPA_ERR_SQL);

    adb_rs_fetch_buf(ipa->rs, 5, assoc->value, IPA_VALUE_LEN, &err);
    IPA_CHECK_ERR(err, "error fetching value", IPA_ERR_SQL);
    return IPA_OK;

}


int ipa_print_result_set(
    IPAContext *ipa,
    GArray     *columns,
    gchar      *delim,
    gboolean    fixed_width)
{
    int i           = 0;
    GError *err     = NULL;
    const char *val = NULL;
    IPAColumn  *column;
    //GArray *columns = g_array_new(FALSE, TRUE, sizeof(IPAColumn));

    g_assert(ipa->rs);
    /*
    if (ipa->displayfields & IPA_COL_CATALOG)
    {
        IPA_ADD_COLUMN(columns, "catalog", ipa->cat_width, TRUE);
    }
    if (ipa->displayfields & IPA_COL_START)
    {
        IPA_ADD_COLUMN(columns, "start", 19, FALSE);
    }
    if (ipa->displayfields & IPA_COL_END)
    {
        IPA_ADD_COLUMN(columns, "end", 19, FALSE);
    }
    if (ipa->displayfields & IPA_COL_RANGE)
    {
        IPA_ADD_COLUMN(columns, "range", 0, TRUE);
    }
    if (ipa->displayfields & IPA_COL_LABEL)
    {
        IPA_ADD_COLUMN(columns, "label", ipa->label_width, TRUE);
    }
    if (ipa->displayfields & IPA_COL_VALUE)
    {
        IPA_ADD_COLUMN(columns, "value", 0, FALSE);
    }
    */
    ipa_get_column_widths(ipa, columns);

    if (columns->len != adb_rs_column_count(ipa->rs, &err)) {
        g_critical("label count must match result set column count");
        return IPA_ERR_INVALID;
    }

    for (i = 0; i < columns->len; i++) {
        int bufsize;
        if (i != 0) g_print("%s", delim); ;
        column      = &g_array_index(columns, IPAColumn, i);
        bufsize     = column->width;
        column->val = g_malloc0(bufsize);
        if (fixed_width) {
            g_print("%*s", -(column->width), column->label);
        } else {
            g_print("%s", column->label);
        }
    }
    g_print("\n");

    while (adb_rs_next(ipa->rs, &err)) {
        for (i = 0; i < columns->len; i++) {
            column = &g_array_index(columns, IPAColumn, i);
            /* adb_rs_fetch(ipa->rs, i, &val, &err); */
            adb_rs_fetch_buf(ipa->rs, i, column->val, column->width+1, &err);
            IPA_CHECK_ERR(err, "error fetching column", IPA_ERR_SQL);
            if (i != 0) g_print("%s", delim);
            if (fixed_width) {
                if (column->align_left) {
                    g_print("%-*s", column->width, column->val);
                } else {
                    g_print("%*s", column->width, column->val);
                }
            } else {
                g_print("%s", column->val);
            }
        }
        g_print("\n");
    }
    for (i = 0; i < columns->len; i++) {
        column = &g_array_index(columns, IPAColumn, i);
        g_free(column->val);
    }

    g_array_free(columns, TRUE);

    return IPA_OK;

} /* ipa_print_result_set */


#if 0
int ipa_do_find_query(
    IPAContext *ipa,
    GString    *catalog,
    GString    *range,
    GString    *label,
    GString    *value,
    GString    *t1,
    GString    *t2,
    int displayfields)
{
    GError *err     = NULL;
    const char *val = NULL;
    int rv          = IPA_ERR_UNKNOWN;

    GArray *columns = g_array_new(FALSE, TRUE, sizeof(IPAColumn));
    g_assert(ipa);

    if (ipa_do_assoc_query(ipa, (catalog ? catalog->str : NULL),
                           (range ? range->str : NULL),
                           (label ? label->str : NULL),
                           (value ? value->str : NULL),
                           (t1 ? t1->str : NULL),
                           (t2 ? t2->str : NULL),
                           displayfields
                           )
        )
    {
        return IPA_ERR_SQL;
    }

    if (displayfields & IPA_COL_CATALOG)
    {
        IPA_ADD_COLUMN(columns, "catalog", ipa->cat_width, TRUE);
    }
    if (displayfields & IPA_COL_START)
    {
        IPA_ADD_COLUMN(columns, "start", 19, FALSE);
    }
    if (displayfields & IPA_COL_END)
    {
        IPA_ADD_COLUMN(columns, "end", 19, FALSE);
    }
    if (displayfields & IPA_COL_RANGE)
    {
        IPA_ADD_COLUMN(columns, "range", 0, TRUE);
    }
    if (displayfields & IPA_COL_LABEL)
    {
        IPA_ADD_COLUMN(columns, "label", ipa->label_width, TRUE);
    }
    if (displayfields & IPA_COL_VALUE)
    {
        IPA_ADD_COLUMN(columns, "value", 0, FALSE);
    }
    /* FIXME */
    ipa_print_result_set(ipa, columns, " ", TRUE);

    g_array_free(columns, TRUE);

    return IPA_OK;
} /* ipaquery_print_find_query */
#endif

int ipa_parse_query(
    IPAContext *ipa,
    char *query)
{
    int rv = IPA_ERR_UNKNOWN;

    GString *t1             = NULL, *t2 = NULL;
    GString *range          = NULL;
    GString *catalog        = NULL, *label = NULL;
    GString *value          = NULL;
    GString *show           = NULL;
    GString *sql            = NULL;
    gboolean time_specified = FALSE;
    GScanner * scanner = ipa->scanner;
    g_assert(ipa);

    ipa->displayfields = 0;

    /* g_printerr("ipa_parse_query: foo\n"); */

    if (query)
    {
        g_scanner_input_text(scanner, query, strlen(query));
    }

    g_scanner_set_scope(scanner, IPAQUERY_FIND);

    /* g_printerr("ipa_parse_query: bar\n"); */


    do {
        switch (g_scanner_get_next_token(scanner)) {
          case IPAQUERY_ADDR:
          {
              uint32_t a1, a2;
              GString *addr1 = NULL, *addr2 = NULL;

              addr1 = g_string_new("");
              addr2 = g_string_new("");

              if (!ipa_scan_range(scanner, &a1, &a2)) {
                  goto err;
              }

              if (!ipa_ntop(AF_INET, a1, addr1)) {
                  goto err;
              }
              if (!ipa_ntop(AF_INET, a2, addr2)) {
                  goto err;
              }
              range = g_string_new("");
              g_string_printf(range, "%s-%s", addr1->str, addr2->str);
              g_string_free(addr1, TRUE);
              g_string_free(addr2, TRUE);
              break;

          }
          case IPAQUERY_LABEL:
          {
              if (!ipaquery_scan_string(scanner, &label)) goto err;
              break;
          }
          case IPAQUERY_VALUE:
          {
              if (!ipaquery_scan_int_range(scanner, &value)) goto err;
              break;
          }
          case IPAQUERY_IN:
          {
              if (!ipaquery_scan_string(scanner, &catalog)) goto err;
              break;
          }
          case IPAQUERY_AT:
          {
              if (time_specified) goto err;
              if (!ipaquery_scan_datetime(scanner, &t1)) goto err;
              time_specified = TRUE;
              break;
          }
          case IPAQUERY_BEFORE:
          {
              if (time_specified) goto err;
              t1 = g_string_new("-infinity");
              if (!ipaquery_scan_datetime(scanner, &t2)) goto err;
              time_specified = TRUE;
              break;
          }
          case IPAQUERY_AFTER:
          {
              if (time_specified) goto err;
              if (!ipaquery_scan_datetime(scanner, &t1)) goto err;
              t2             = g_string_new("infinity");
              time_specified = TRUE;
              break;
          }
          case IPAQUERY_BETWEEN:
          {
              if (time_specified) goto err;
              if (!ipaquery_scan_datetime(scanner, &t1)) goto err;

              switch (g_scanner_get_next_token(scanner)) {
                case IPAQUERY_AND: {
                } break;
                default:
                  g_scanner_unexp_token(scanner, IPAQUERY_AND, NULL,
                                        NULL, NULL,
                                        "unknown token in time range",
                                        FALSE);
                  goto err;
              } /* switch */
              if (!ipaquery_scan_datetime(scanner, &t2)) goto err;

              time_specified = TRUE;
              break;

          }
          case IPAQUERY_SHOW:
          {
              if (!ipaquery_scan_string(scanner, &show)) goto err;
              
              if (show)
              {
                  if (strstr(show->str, "catalog"))
                  {
                      ipa->displayfields |= IPA_COL_CATALOG;
                  }
                  if (strstr(show->str, "start"))
                  {
                      ipa->displayfields |= IPA_COL_START;
                  }
                  if (strstr(show->str, "end"))
                  {
                      ipa->displayfields |= IPA_COL_END;
                  }
                  if (strstr(show->str, "range"))
                  {
                      ipa->displayfields |= IPA_COL_RANGE;
                  }
                  if (strstr(show->str, "label"))
                  {
                      ipa->displayfields |= IPA_COL_LABEL;
                  }
                  if (strstr(show->str, "value"))
                  {
                      ipa->displayfields |= IPA_COL_VALUE;
                  }
              }
              
              break;
          }
          default:
          {
              g_critical("unknown token: %d\n", scanner->token);
              g_scanner_unexp_token(scanner, G_TOKEN_STRING, NULL, NULL,
                                    NULL, "unknown token in find",
                                    FALSE);
              goto err;

          }
        } /* switch g_scanner_get_next_token(scanner) */
        g_scanner_peek_next_token(scanner);
    } while (scanner->next_token != G_TOKEN_EOF
             && scanner->next_token != G_TOKEN_ERROR) ;

    if (! ipa->displayfields) ipa->displayfields = IPA_COL_ALL;

    /* g_printerr("ipa_parse_query: baz\n"); */
    //ipa_do_find_query(ipa, catalog, range, label, value, t1, t2, displayfields);
    if (ipa_do_assoc_query(ipa, (catalog ? catalog->str : NULL),
                           (range ? range->str : NULL),
                           (label ? label->str : NULL),
                           (value ? value->str : NULL),
                           (t1 ? t1->str : NULL),
                           (t2 ? t2->str : NULL),
                           ipa->displayfields
                           )
        )
    {
        return IPA_ERR_SQL;
    }

    /* FIXME */
    //ipa_print_result_set(ipa, columns, " ", TRUE);

    if (t1) g_string_free(t1, TRUE);
    if (t2) g_string_free(t2, TRUE);
    if (catalog) g_string_free(catalog, TRUE);
    if (range) g_string_free(range, TRUE);
    if (show) g_string_free(show, TRUE);

    /* g_printerr("ipa_parse_query: qux\n"); */


    rv = IPA_OK; goto END;

  err:
    g_scanner_error(scanner, "Scanner error");
    rv = IPA_ERR_INVALID;

  END:
    return rv;
} /* ipaquery_handle_find */


gboolean ipaquery_scan_string(
    GScanner *scanner,
    GString **string
    )
{
    unsigned int old_scope = scanner->scope_id;
    int rv = FALSE;
    g_scanner_set_scope(scanner, IPAQUERY_NONE);

    switch (g_scanner_get_next_token(scanner)) {
      case G_TOKEN_STRING: {
          *string = g_string_new(scanner->value.v_string);
          rv = TRUE;
          break;
      } case G_TOKEN_INT: { /* An integer that we want to read as a string */
          *string = g_string_new("");
          g_string_printf(*string, "%d", scanner->value.v_int);
          rv = TRUE;
          break;
        }
      case G_TOKEN_EOF: {
          *string = NULL;
          rv = TRUE;
          break;
      }
      default:
        g_print("unknown: %d\n", g_scanner_get_next_token(scanner));
        *string = NULL;
        rv = FALSE;
        break;
    } /* switch */

  done:
    g_scanner_set_scope(scanner, old_scope);
    return rv;
}     /* ipaquery_scan_string */

gboolean ipaquery_scan_int_range(
    GScanner *scanner,
    GString **string
    )
{
    char *errdesc = NULL;

    /* grab the first date */
    if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
        errdesc = "invalid value"; goto err;
    }

    *string = g_string_new("");
    g_string_printf(*string, "%d", scanner->value.v_int);

    switch (g_scanner_get_next_token(scanner)) {
      case G_TOKEN_EOF: { /* single value */
          return TRUE;
      } 
      case '-':
        g_string_append(*string, "-");
        break;
      default:
        errdesc = "invalid value"; goto err;
    } /* switch */

    if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
        errdesc = "invalid value"; goto err;
    }
    g_string_append_printf(*string, "%d", scanner->value.v_int);
    return TRUE;

  err:
    g_scanner_error(scanner, "Malformed integer range (%s)", errdesc);
    return FALSE;
} /* ipaquery_scan_int_range */

/** Scan and parse a date and optional time value. */
gboolean ipaquery_scan_datetime(
    GScanner *scanner,
    GString **time)
{
    char *errdesc = NULL;
    int   year, month, day, hour, min, sec;

    /* grab the first date */
    if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
        errdesc = "missing year"; goto err;
    }
    if ((scanner->value.v_int < 1970) || (scanner->value.v_int > 2038)) {
        errdesc = "year out of range"; goto err;
    }
    year = scanner->value.v_int;
    switch (g_scanner_get_next_token(scanner)) {
      case '/':
      case '-':
          break;
      default:
        errdesc = "missing /"; goto err;
    } /* switch */
    if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
        errdesc = "missing month"; goto err;
    }
    if (scanner->value.v_int < 1 || scanner->value.v_int > 12) {
        errdesc = "month out of range"; goto err;
    }
    month = scanner->value.v_int;
    switch (g_scanner_get_next_token(scanner)) {
      case '/':
      case '-':
        break;
      default:
        errdesc = "missing /"; goto err;
    } /* switch */
    if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
        errdesc = "missing day"; goto err;
    }
    if (scanner->value.v_int < 1 || scanner->value.v_int > 31) {
        errdesc = "day out of range"; goto err;
    }
    day = scanner->value.v_int;

    if (g_scanner_peek_next_token(scanner) == ':') {
        g_scanner_get_next_token(scanner); /* eat the : */
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
            errdesc = "missing hour"; goto err;
        }

        if (scanner->value.v_int < 0 || scanner->value.v_int > 23) {
            errdesc = "hour out of range"; goto err;
        }
        hour = scanner->value.v_int;
        switch (g_scanner_get_next_token(scanner)) {
          case G_TOKEN_EOF: {
              min = 0;
              sec = 0;
              goto done;
          } case ':': {
          } break;
          default:
            errdesc = "missing :"; goto err;
        } /* switch */
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
            errdesc = "missing minute"; goto err;
        }
        if (scanner->value.v_int < 0 || scanner->value.v_int > 59) {
            errdesc = "minute out of range"; goto err;
        }
        min = scanner->value.v_int;
        switch (g_scanner_get_next_token(scanner)) {
          case G_TOKEN_EOF: {
              sec = 0;
              goto done;
          } case ':': {
          } break;
          default:
            errdesc = "missing :"; goto err;
        } /* switch */
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) {
            errdesc = "missing second"; goto err;
        }
        if (scanner->value.v_int < 0 || scanner->value.v_int > 59) {
            errdesc = "second out of range"; goto err;
        }
        sec = scanner->value.v_int;
    } else {
        /* nope - start at beginning of day */
        hour = min = sec = 0;
    }

  done:
    *time = g_string_new("");
    g_string_printf(*time, "%04u/%02u/%02u %02u:%02u:%02u", year, month, day,
                    hour, min,
                    sec);
    return TRUE;

  err:
    g_scanner_error(scanner, "Malformed time range (%s)", errdesc);
    return FALSE;
} /* ipaquery_scan_datetime */



gboolean ipa_scan_range(
    GScanner *scanner,
    uint32_t *a,
    uint32_t *b)
{
    uint32_t mask = 0;

    if (!ipa_scan_addr(scanner, a)) {
        return FALSE;
    }

    /* EOA for first address. Peek for next token. */
    g_scanner_peek_next_token(scanner);
    /* Slash means CIDR, dash means explicit inclusive range. */
    if (scanner->next_token == '/') {
        /* This range is CIDRized. Eat the slash. */
        g_scanner_get_next_token(scanner);
        /* Calculate A and B from CIDR notation. */
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 32) return FALSE;
        mask = ipa_mask_from_prefix(scanner->value.v_int);
        *a  &= mask;
        *b   = *a | (~mask);
    } else if (scanner->next_token == '-') {
        /* Explicit range. Eat the dash. */
        g_scanner_get_next_token(scanner);
        if (!ipa_scan_addr(scanner, b)) {
            return FALSE;
        }
    } else {
        /* Presume single address in range. */
        *b = *a;
    }

    return TRUE;
} /* ipa_scan_range */


gboolean ipa_scan_addr(
    GScanner *scanner,
    uint32_t *addr)
{

    if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;

    if (g_scanner_peek_next_token(scanner) == '.') {
        /* The begin address is specified as a dotted quad */
        if (scanner->value.v_int > 255) return FALSE;
        *addr = ((scanner->value.v_int & 0x000000FF) << 24);
        if (g_scanner_get_next_token(scanner) != '.') return FALSE;
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 255) return FALSE;
        *addr |= ((scanner->value.v_int & 0x000000FF) << 16);
        if (g_scanner_get_next_token(scanner) != '.') return FALSE;
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 255) return FALSE;
        *addr |= ((scanner->value.v_int & 0x000000FF) << 8);
        if (g_scanner_get_next_token(scanner) != '.') return FALSE;
        if (g_scanner_get_next_token(scanner) != G_TOKEN_INT) return FALSE;
        if (scanner->value.v_int > 255) return FALSE;
        *addr |= (scanner->value.v_int & 0x000000FF);
    } else {
        /* The begin address is specified as an integer */
        *addr = scanner->value.v_int;
    }

    return TRUE;
} /* ipa_scan_addr */

/* inet_ntop isn't available on some platforms, so we'll use our own */
gboolean ipa_ntop(
    int      family,
    uint32_t addr,
    GString *str)
{
    g_assert(str != NULL);

    if (family != AF_INET) {
        errno = EAFNOSUPPORT;
        return FALSE;
    }
    g_string_printf(str, "%u.%u.%u.%u",
                    ((addr >> 24) & 0xFF), ((addr >> 16) & 0xFF),
                    ((addr >> 8) & 0xFF), (addr & 0xFF));

    return TRUE;
} /* ipa_ntop */
