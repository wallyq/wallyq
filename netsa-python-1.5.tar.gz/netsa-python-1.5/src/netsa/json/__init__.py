# Copyright 2008-2016 by Carnegie Mellon University
# See license information in LICENSE-OPENSOURCE.txt

# This module is a legacy wrapper for the system-provided json
from json import *
