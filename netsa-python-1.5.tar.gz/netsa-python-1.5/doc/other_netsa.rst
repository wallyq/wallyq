Internal Facilities
===================

The following features are meant primarily for internal NetSA use.  If
you do make use of them, do so with the understanding that their
interfaces are much more likely to change than other APIs in this
document.

.. toctree::
    :maxdepth: 1

    netsa_dist.rst
