# -*- coding: utf-8 -*-

from netsa_sphinx_config import *

add_static_path("static_html")
